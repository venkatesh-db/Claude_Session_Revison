import pytest

from todo.core import TodoList, TaskNotFoundError, EmptyDescriptionError


def test_add_assigns_incrementing_ids():
    todos = TodoList()
    first = todos.add("write tests")
    second = todos.add("ship it")
    assert first.id == 1
    assert second.id == 2
    assert first.done is False


def test_add_rejects_empty_description():
    todos = TodoList()
    with pytest.raises(EmptyDescriptionError):
        todos.add("   ")


def test_complete_and_uncomplete():
    todos = TodoList()
    task = todos.add("write tests")
    todos.complete(task.id)
    assert todos.get(task.id).done is True
    todos.uncomplete(task.id)
    assert todos.get(task.id).done is False


def test_remove_deletes_task():
    todos = TodoList()
    task = todos.add("write tests")
    removed = todos.remove(task.id)
    assert removed.id == task.id
    with pytest.raises(TaskNotFoundError):
        todos.get(task.id)


def test_operations_on_missing_id_raise_task_not_found():
    todos = TodoList()
    with pytest.raises(TaskNotFoundError):
        todos.complete(999)
    with pytest.raises(TaskNotFoundError):
        todos.uncomplete(999)
    with pytest.raises(TaskNotFoundError):
        todos.remove(999)
    with pytest.raises(TaskNotFoundError):
        todos.get(999)


def test_list_is_sorted_by_id():
    todos = TodoList()
    todos.add("first")
    todos.add("second")
    ids = [t.id for t in todos.list()]
    assert ids == sorted(ids)


def test_ids_are_not_reused_after_removal():
    todos = TodoList()
    a = todos.add("a")
    todos.remove(a.id)
    b = todos.add("b")
    assert b.id != a.id
