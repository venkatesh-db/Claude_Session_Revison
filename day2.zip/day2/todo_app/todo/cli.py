"""Thin CLI shell over todo.core. All I/O lives here; no logic does."""

from todo.core import TodoList, TodoError

HELP = """\
Commands:
  add <description>   Add a new task
  done <id>            Mark a task complete
  undone <id>          Mark a task incomplete
  remove <id>          Remove a task
  list                 Show all tasks
  help                 Show this message
  quit                 Exit
"""


def format_task(task) -> str:
    mark = "x" if task.done else " "
    return f"[{mark}] {task.id}: {task.description}"


def main():
    todos = TodoList()
    print("Todo App. Type 'help' for commands.")
    while True:
        try:
            raw = input("> ").strip()
        except EOFError:
            break
        if not raw:
            continue

        command, _, rest = raw.partition(" ")
        command = command.lower()
        rest = rest.strip()

        try:
            if command == "add":
                task = todos.add(rest)
                print(f"Added: {format_task(task)}")
            elif command == "done":
                task = todos.complete(int(rest))
                print(f"Completed: {format_task(task)}")
            elif command == "undone":
                task = todos.uncomplete(int(rest))
                print(f"Reopened: {format_task(task)}")
            elif command == "remove":
                task = todos.remove(int(rest))
                print(f"Removed: {format_task(task)}")
            elif command == "list":
                tasks = todos.list()
                if not tasks:
                    print("(no tasks)")
                for task in tasks:
                    print(format_task(task))
            elif command == "help":
                print(HELP)
            elif command in ("quit", "exit"):
                break
            else:
                print(f"Unknown command: {command!r}. Type 'help' for commands.")
        except ValueError:
            print("Expected a numeric task id.")
        except TodoError as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
