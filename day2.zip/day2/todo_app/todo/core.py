"""Core todo-list logic: pure data operations, no I/O.

Kept in-memory only (no persistence) and single-user (no concurrency) by
deliberate choice, not oversight:
  - trigger for adding persistence: data must survive process restart.
  - trigger for adding concurrency control: more than one process/thread
    mutates the same TodoList at once.
Until one of those fires, a plain list-backed class is the cheapest correct
shape and keeps the CLI layer trivial to test against.
"""

from dataclasses import dataclass, field


class TodoError(Exception):
    """Base class for all todo-list errors."""


class TaskNotFoundError(TodoError):
    def __init__(self, task_id: int):
        super().__init__(f"No task with id {task_id}")
        self.task_id = task_id


class EmptyDescriptionError(TodoError):
    def __init__(self):
        super().__init__("Task description cannot be empty")


@dataclass
class Task:
    id: int
    description: str
    done: bool = False


@dataclass
class TodoList:
    _tasks: dict = field(default_factory=dict)
    _next_id: int = 1

    def add(self, description: str) -> Task:
        description = description.strip()
        if not description:
            raise EmptyDescriptionError()
        task = Task(id=self._next_id, description=description)
        self._tasks[task.id] = task
        self._next_id += 1
        return task

    def remove(self, task_id: int) -> Task:
        try:
            return self._tasks.pop(task_id)
        except KeyError:
            raise TaskNotFoundError(task_id)

    def complete(self, task_id: int) -> Task:
        task = self._get(task_id)
        task.done = True
        return task

    def uncomplete(self, task_id: int) -> Task:
        task = self._get(task_id)
        task.done = False
        return task

    def get(self, task_id: int) -> Task:
        return self._get(task_id)

    def list(self) -> list:
        return sorted(self._tasks.values(), key=lambda t: t.id)

    def _get(self, task_id: int) -> Task:
        try:
            return self._tasks[task_id]
        except KeyError:
            raise TaskNotFoundError(task_id)
