def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(a, b):
    return a * b


def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


def calculate(a, op, b):
    operations = {
        "+": add,
        "-": subtract,
        "*": multiply,
        "/": divide,
    }
    if op not in operations:
        raise ValueError(f"Unsupported operator: {op}")
    return operations[op](a, b)


def main():
    print("Simple Calculator")
    print("Operators: + - * /")
    print("Type 'q' to quit\n")

    while True:
        expr = input("Enter expression (e.g. 3 + 4): ").strip()
        if expr.lower() == "q":
            print("Goodbye!")
            break

        parts = expr.split()
        if len(parts) != 3:
            print("Invalid format. Use: number operator number\n")
            continue

        a_str, op, b_str = parts
        try:
            a = float(a_str)
            b = float(b_str)
            result = calculate(a, op, b)
            print(f"Result: {result}\n")
        except ValueError as e:
            print(f"Error: {e}\n")


if __name__ == "__main__":
    main()
