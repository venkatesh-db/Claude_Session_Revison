# Generation Prompt: "RxFlow" Lab Repository

> **Usage:** Hand this prompt to a coding agent (e.g. Claude Code) that has
> already loaded `AGENT_ROLE_THINKING.md` as its operating persona/checklist
> for this task. Run it with write access to a fresh empty folder, e.g.
> `rxflow/`. Do not run it inside an existing project.

---

## Task

Generate a complete, runnable Python backend repository named **RxFlow** —
a retail order-management service — inside a new folder called `rxflow/`.
The repository must be **realistic and undocumented** (no README explaining
architecture, no inline "why" comments, no ADRs) but must be **fully
functional**: installable, runnable, testable, lintable, and type-checkable
with real commands that actually work.

This repo is the target artifact for a 90-minute hands-on lab
("Hands-on Lab 1: RxFlow Repository X-Ray") in which participants use a
read-only AI coding assistant to reverse-engineer it from scratch and
produce an evidence-cited intelligence report. Generate accordingly: the
repo must reward careful investigation and punish guessing.

---

## 1. Stack & Structure

Use:
- **Python 3.11**, **FastAPI** (or Flask — pick one and be consistent) for
  the HTTP layer
- **SQLAlchemy** ORM + **Alembic** for migrations, backed by **PostgreSQL**
  (use `psycopg2`/`asyncpg` as appropriate; SQLite fallback for local
  tests is acceptable if clearly wired via config)
- **Redis** for caching and as the **Celery** broker/result backend
- **Celery** for background/async task processing
- **Pydantic** for request/response schemas
- **pytest** for tests, **ruff** (or flake8) for lint, **mypy** for type
  checking
- Dependency management via `pyproject.toml` (Poetry or plain
  `pip`/`requirements.txt` — pick one, be consistent)
- A `Makefile` or `tox.ini` exposing at minimum: `make install`,
  `make test`, `make lint`, `make typecheck`, `make run`

Suggested module layout (adapt naturally, don't over-engineer to match this
exactly — some organic inconsistency is expected per the role framework):

```
rxflow/
  pyproject.toml / requirements.txt
  Makefile
  alembic.ini
  migrations/
    versions/  (3+ real migrations, one with intentional drift vs models)
  app/
    main.py                 # FastAPI app factory / route registration
    config.py                # settings, env vars, timeout/retry config
    api/
      orders.py              # POST /orders and related routes
      customers.py
      products.py
      auth.py                 # login/token endpoints
    services/
      order_service.py        # core order creation orchestration
      payment_service.py       # calls external payment gateway (mocked)
      inventory_service.py     # stock checks/reservation
      notification_service.py  # email/SMS triggers
    models/                    # SQLAlchemy models
      order.py, customer.py, product.py, inventory.py, payment.py
    schemas/                   # Pydantic request/response models
    repositories/               # DB access layer (or fold into services —
                                 # pick ONE pattern and apply it inconsistently
                                 # in exactly one older module, per realism)
    tasks/
      celery_app.py
      order_tasks.py            # confirmation email, inventory sync, etc.
    core/
      security.py               # JWT/session auth, password hashing
      permissions.py             # role checks (customer vs staff/admin)
      cache.py                   # Redis client wrapper
      http_client.py             # shared outbound HTTP client w/ timeout config
    clients/
      payment_gateway_client.py
      shipping_client.py
      email_client.py
  tests/
    unit/
    integration/
  scripts/
    seed_db.py
```

---

## 2. `POST /orders` Request Path (must be fully traceable)

Implement a genuine multi-hop path, for example:

1. `app/api/orders.py` — route handler, auth dependency injected, request
   validated via Pydantic schema.
2. `app/core/security.py` / `permissions.py` — resolves current user,
   checks customer-vs-staff role where relevant.
3. `app/services/order_service.py` — orchestrates: validates cart items,
   calls `inventory_service` to check/reserve stock, calls
   `payment_service` to authorize payment, persists `Order` +
   `OrderItem` rows via SQLAlchemy, enqueues at least one Celery task
   (e.g. `send_order_confirmation`), returns response schema.
4. `app/services/inventory_service.py` — reads/writes inventory,
   optionally touches Redis cache for product data with a plausible
   caching bug (e.g. stale cache not invalidated on stock decrement —
   a legitimate finding, not called out anywhere in comments).
5. `app/services/payment_service.py` — calls
   `clients/payment_gateway_client.py`, which wraps
   `core/http_client.py` with a specific timeout/retry policy.
6. `app/tasks/order_tasks.py` — Celery task consumes the enqueued job,
   calls `clients/email_client.py`, logs order details (this is one of
   your deliberate PII-in-logs points — decide precisely which fields
   leak here).

Make sure every hop above is real code that runs, not a stub returning a
hardcoded value.

---

## 3. Redis & Celery — Real, Distinct Uses

- Redis: at least one **cache** use (e.g. product catalog lookups,
  keyed with a TTL) and optionally a rate-limiter or idempotency-key store
  on `POST /orders`.
- Celery: at least two distinct tasks (e.g. `send_order_confirmation`,
  `sync_inventory_levels` or `reconcile_payment_webhook`), each with
  different retry/backoff configuration — vary them so comparing tasks is
  a genuine exercise, not a copy-paste of identical decorators.
- Wire `celery_app.py` to actually point at the same Redis instance
  configured in `config.py` — no dangling/unused config keys that look
  load-bearing but aren't.

---

## 4. Outbound Calls & Timeout Behavior

Create at least 4 distinct outbound integration points (payment gateway,
shipping/label API, email provider, and one more — e.g. SMS or a
tax-calculation service). For each:
- Give it its own client wrapper class/function.
- Set an explicit timeout (connect + read, if using `httpx`/`requests`).
- Vary retry policy across them: one with exponential backoff + 3
  retries, one with no retry at all, one with a suspiciously long
  timeout (e.g. 30s) that would be a real production risk, one using a
  shared default from `config.py` that the others silently ignore
  (inconsistency = real finding).
- Mock/stub the actual network call (return canned success/failure) but
  keep the timeout/retry code paths real and exercised by at least one
  test.

---

## 5. Database Schema & Migration State

- Core tables: `customers`, `orders`, `order_items`, `products`,
  `inventory`, `payments`, and one more supporting table of your choice
  (e.g. `audit_log` or `webhook_events`).
- At least 3 Alembic migrations showing evolution over time (e.g. initial
  schema, then an added column, then an added index or table).
- Introduce **one deliberate drift**: a column present in the live schema
  (added via a raw migration) that is missing from, or renamed
  differently in, the SQLAlchemy model — something an engineer would only
  catch by comparing migration files against `models/`.

---

## 6. Authentication & Authorization

- Customer-facing auth: JWT-based login (`app/api/auth.py`,
  `core/security.py`), password hashing via `passlib`/`bcrypt`.
- Roles: at least `customer` and `staff`/`admin`. Staff-only endpoints
  (e.g. order cancellation, refund, inventory override) must check role
  via `core/permissions.py`.
- Introduce **one real, subtle authorization gap** — e.g. an endpoint that
  checks authentication but not the ownership/role condition it should
  (a customer able to fetch another customer's order by ID because the
  handler queries by order ID alone without a customer_id filter), or a
  staff-only route reachable because a dependency was copy-pasted from a
  public route and the role check silently omitted. Make this a genuine,
  findable bug — not a comment-flagged one.

---

## 7. PII in Logs — Deliberate, Varied Severity

Distribute across 2-3 files, at varying severity:
- **Low severity**: a log line that includes a customer email at INFO
  level during order confirmation.
- **Medium severity**: a log line in an error handler that dumps the full
  request payload (including shipping address) at ERROR level on
  validation failure.
- **Higher severity**: a DEBUG-level log statement left in
  `payment_service.py` or the payment gateway client that logs the full
  outbound payment request payload (e.g. cardholder name, last4, billing
  address) — framed as "temporary debug logging" a real engineer would
  plausibly have forgotten to remove, but with no comment saying so.

Do not use SQL/NoSQL log sinks or structured-logging redaction anywhere —
keep it plain `logging`/`print`-based so it's `grep`-able.

---

## 8. Tooling You Must Verify Actually Works

Before finishing, confirm (by running, not assuming, if you have shell
access; otherwise by careful manual trace):
- `pip install -r requirements.txt` or Poetry install succeeds with
  compatible pinned versions.
- `pytest` runs and the large majority of tests pass (a small number of
  genuinely informative failing/skipped tests is fine if it reflects
  real repo decay — e.g. one integration test that requires a live DB and
  is skipped by default).
- Lint (`ruff check .` / `flake8`) runs and produces a believable, small
  set of findings — not zero (real repos have lint debt) and not
  overwhelming.
- `mypy app/` runs; it's acceptable and realistic for it to surface a
  handful of real type issues, especially in the older/legacy module.
- `make run` (or equivalent) actually boots the FastAPI/Flask app
  locally (DB/Redis can be assumed available via docker-compose — include
  a working `docker-compose.yml` with `db` and `redis` services).

Include a `docker-compose.yml` so participants (or the lab environment)
can bring up Postgres + Redis to actually exercise the app if needed.

---

## 9. Explicitly Do NOT Include

- No README.md explaining architecture, module map, or request flows.
- No ADRs, no `/docs` folder with design docs.
- No comments that name or flag risks, TODOs like `# FIXME: security
  issue`, or docstrings that explain the "why" behind a decision.
- No obviously fake/placeholder code (`# TODO: implement later` stubs) in
  the core `POST /orders` path — that path must be complete and real.

A minimal `.gitignore` and a bare one-paragraph `README.md` (project name
and a single "internal service" sentence, nothing else) is fine and in
fact appropriately realistic.

---

## 10. Self-Check Before Declaring Done

Produce, for your own use only (save as `rxflow/SEED_NOTES.md`, gitignored
or clearly marked internal — this is the **answer key**, not something
participants should be handed), a private accounting of:

1. Module map you actually built (so it can be checked against later).
2. The exact file:line path of the `POST /orders` flow.
3. The verified (actually-run) output of install/test/lint/typecheck.
4. Schema + migration list, and where the drift lives.
5. Where Redis and Celery are used, and their config.
6. Every outbound call, its file, and its timeout/retry setting.
7. The authz gap you planted, and its file:line.
8. Every PII-in-logs instance, its file:line, and severity.
9. Your own ranked "five highest-risk files" with justification.
10. Two to four genuinely ambiguous design points you left unresolved,
    for the "unknowns and recommended investigation order" section of the
    lab.

This file is what the lab facilitator uses to grade participants' reports
— it must be accurate and match the generated code exactly.
