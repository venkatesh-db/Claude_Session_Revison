# Senior Software Engineer Review: Simple Calculator

## Reference
This document sits *between* [`calculator_report.md`](calculator_report.md)
(the implementation agent's task-local reasoning) and
[`calculator_architect_review.md`](calculator_architect_review.md) (the
principal architect's system-level, boundary-questioning reasoning). It
represents the **senior software engineer** role: the translator who takes
architectural judgment and turns it into concrete, buildable, still-pragmatic
engineering decisions — without either agent's blind spots.

## Where the Dev Agent and the Architect Leave a Gap

| | Dev Agent | Principal Architect | **Gap left unfilled** |
|---|---|---|---|
| Concern | "Does this work?" | "Is this the right thing to build, and what could go wrong at scale?" | "**How exactly** do I build it so today's toy survives becoming tomorrow's real thing, without over-building today?" |
| Output | Working code | A judgment framework + conditions | No actual refactor, no code, no test — architecture doesn't ship |
| Risk | Under-thinks consequences | Correctly refuses to gold-plate, but stops at "here's what *would* change the decision" | Doesn't decide *how* to structure code so that trigger conditions are cheap to act on later |

The architect's report is right that adding CI/tests/`Decimal`/API-layering
*now* would be over-engineering. But it leaves an engineering question open:
**can the code be shaped today, at near-zero extra cost, so that crossing
any of those trigger conditions later is a small diff instead of a rewrite?**
That's the senior engineer's job — creative, structural thinking that buys
future optionality cheaply, not adding future features early.

## Senior Engineer Thinking Process

### 1. Translate architectural risk into a "cost of change later" question
For each gap the architect flagged, ask: *if this trigger condition fires in
6 months, how expensive is the fix, and can I make it cheaper today for
near-zero cost?*

- **Logic coupled to CLI (`main()`)** → cheap to fix now (just move functions
  to a module), expensive to fix later if callers already depend on the CLI
  shape. **Fix now.**
- **`float` vs `Decimal`** → expensive to change later (every call site,
  every stored value, every test assumption about precision would need
  re-auditing). **Don't switch now** (no evidence of money-handling use),
  but **isolate the arithmetic behind the dispatch function** so swapping the
  numeric type later touches one place, not the whole codebase.
- **Error taxonomy** → cheap to fix now (define one extra exception class),
  expensive later (once callers start catching bare `ValueError` all over).
  **Fix now, minimally.**
- **Tests** → cheap now because functions are already small and pure (the
  dev agent's structure directly enables this). **Add now** — this isn't
  gold-plating, it's proportional to effort already spent making functions
  testable; leaving them untested wastes that investment.
- **CI/packaging/versioning** → genuinely expensive to justify without a
  second consumer or deployment target. **Correctly deferred**, matching the
  architect's call.

### 2. Creative reframing: decouple *shape* from *scope*
The dev agent conflated "keep it simple" with "keep it a single file with a
CLI loop." A senior engineer's creative move is recognizing these are
independent: you can keep the *scope* simple (still four operations, still
no persistence) while changing the *shape* (module + thin CLI entrypoint) so
the same simple scope is reusable. This is the kind of restructuring an
architect names as a category ("separate logic from interface") but doesn't
execute — a senior engineer's contribution is realizing shape changes are
usually free if done early, and doing them.

### 3. Pick the minimum viable safety net, not the maximum
Rather than architect-level "add a test suite as a gate" in the abstract, a
senior engineer decides *specifically*:
- Unit tests for the four pure functions plus `calculate()`'s dispatch and
  error paths — nothing about the CLI loop itself (I/O testing has much
  lower ROI here and is legitimately deferrable).
- One property worth testing precisely because the architect flagged it:
  `0.1 + 0.2` style float-precision behavior, asserted and documented as
  *known and intentional*, so it's never mistaken for a bug later.

### 4. Resolve the tension the architect left as an open question
The architect said: "validate with the requester whether this is a toy or a
seed." A senior engineer's creative answer, when that validation isn't
available, is to **build for the ambiguous middle** — structure the code so
it works either way, deferring the actual expensive commitment (`Decimal`,
API framework, auth) until the real answer is known, rather than blocking on
an answer that may never come.

### 5. Concrete engineering plan (what actually gets built)
1. Split `calculator.py` into:
   - `calculator/core.py` — `add/subtract/multiply/divide/calculate`, plus a
     new `CalculatorError` base and `UnsupportedOperatorError`,
     `DivisionByZeroError` subclasses.
   - `calculator/cli.py` — `main()`, the input loop, all I/O.
2. Add `tests/test_core.py` with `pytest` covering all four operations, the
   dispatch table, both error paths, and one documented float-precision case.
3. Leave `Decimal`, packaging, CI, and logging **explicitly out**, each with
   a one-line comment/doc note on the trigger condition that would bring
   them back in scope (mirroring the architect's conditions, so the decision
   trail is unbroken from architect → engineer → code).

## Summary: what the senior engineer role adds
The dev agent asks "does it work." The architect asks "should we worry, and
under what conditions." The senior engineer asks a third, distinct question:
**"how do I shape this right now, cheaply, so that the architect's future
conditions are easy to act on instead of a rewrite?"** The gap between
architect and agent isn't more judgment — it's **converting judgment into a
concrete, minimal, reversible structural decision**, made creatively by
separating "simple scope" from "single-file shape," and applied only where
the cost-of-change-later math favors acting now.
