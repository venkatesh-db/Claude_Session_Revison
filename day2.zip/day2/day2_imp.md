# day2_imp — Conversation Summary

Summary of the chat session covering onboarding to the `rxflow` project.
Kept as a quick-recall log, not a substitute for `rxflow/KT.md` (the living
reference) or `rxflow/diagrams.html` (the visual reference).

## Context

Working directory `c:\Users\Administrator\day2\` contains several unrelated
things: `rxflow/` (the real project — FastAPI order-management service),
`rxflow-lab-generator/` (docs about generating a training lab), `todo_app/`,
and a standalone `calculator.py` with review notes. The user asked for KT to
get onboarded to `rxflow` faster and write code faster with AI assistance.

**Important caveat surfaced early**: `rxflow/SEED_NOTES.md` is marked
"INTERNAL ANSWER KEY (not for participants)" — the repo originated as a
training lab ("RxFlow Repository X-Ray") with deliberately planted issues.
The user confirmed they own `rxflow` as a real codebase to work on (not
solving it as a lab exercise), so all KT below was built by reading the
actual source directly rather than copying that answer-key file.

## What was produced

1. **Initial verbal KT** (in-chat) — stack, module map, the `POST /orders`
   flow traced through `api/orders.py` → `order_service.py` →
   `inventory_service.py` / `payment_service.py` → Celery → `notification_service.py`,
   plus flagged risk areas (authorization inconsistency across
   `orders.py`, PII in logs, cache-invalidation gap, migration drift,
   HTTP-client timeout inconsistency, unused `tax_client.py`).

2. **`rxflow/KT.md`** — the reusable, durable knowledge-transfer document.
   Covers: what the service is, how to run it locally (`make
   install/run/test/lint/typecheck`, docker-compose), the full module map,
   the `POST /orders` call chain with file references, the three different
   authorization patterns across `orders.py`, Redis/Celery/HTTP-client
   usage and their inconsistencies, migration drift
   (`inventory.reorder_threshold` not on the model), PII-in-logs spots,
   open design ambiguities (repository vs. direct ORM, where caching
   should live, unused `tax_client.py`), and a "how to work fast here with
   AI assistance" section. This file is meant to be handed to a new
   session (or teammate) to restore context instantly.
   Note: since being written, `KT.md` has been updated on disk (new
   `GET /orders` list route, `PATCH /products/{id}/stock` staff endpoint,
   and a cache-invalidation fix via `update_stock()` — the cache gap now
   applies only to `reserve_stock()`, not the whole system).

3. **`rxflow/diagrams.html`** — published as an Artifact ("Order Pipeline
   Diagrams"). Three hand-drawn SVG diagrams built by reading source
   directly:
   - **Codeflow** — module-to-module data flow across API/service/client
     layers and the two stores (Postgres, Redis), including the missing
     `cache_delete()` call as a dashed "should exist, doesn't" arrow.
   - **Decision logic** — the branch structure inside `create_order()`:
     empty-cart check, per-item stock check, payment-gateway retry loop,
     then commit — every exit point before `db.commit()`.
   - **Sequence** — the exact call order for one `POST /orders` request,
     split into what happens inside the HTTP request/response cycle vs.
     what runs later, asynchronously, on the Celery worker.

## Standing questions / offers not yet acted on

- Offered to create `rxflow/CLAUDE.md` (auto-loaded by Claude Code at the
  start of every session in that directory) that references `KT.md` and
  `diagrams.html` plus the `make` commands, so future sessions get full
  context with zero manual step. Not yet built — user has not confirmed.
- Clarified that this assistant's cross-session memory only stores
  explicit durable *preferences/corrections*, not project facts or full
  transcripts — persistence of project knowledge is via files
  (`KT.md`, `diagrams.html`, this summary), not the memory system.

## How to resume from this file

Point a new session at this file plus `rxflow/KT.md` and
`rxflow/diagrams.html` (or just say "read `day2_imp.md`") to restore full
context on where onboarding stood and what's been built so far.
