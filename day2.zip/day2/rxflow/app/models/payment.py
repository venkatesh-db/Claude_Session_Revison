import datetime

from sqlalchemy import DateTime, ForeignKey, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), unique=True)
    amount_cents: Mapped[int] = mapped_column(Numeric(10, 0))
    status: Mapped[str] = mapped_column(String(32), default="authorized")
    gateway_reference: Mapped[str] = mapped_column(String(128), nullable=True)
    card_last4: Mapped[str] = mapped_column(String(4), nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )

    order = relationship("Order", back_populates="payment")
