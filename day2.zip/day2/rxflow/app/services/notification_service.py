import logging

from app.clients.email_client import send_email

logger = logging.getLogger(__name__)


def send_order_confirmation_email(customer_email: str, order_id: int, total_cents: int) -> bool:
    logger.info(
        "Sending order confirmation for order %s to %s (total=%s)",
        order_id,
        customer_email,
        total_cents,
    )
    subject = f"Your RxFlow order #{order_id} is confirmed"
    body = f"Thanks for your order! Total: ${total_cents / 100:.2f}"
    return send_email(customer_email, subject, body)
