from sqlalchemy.orm import Session

from app.core.cache import cache_delete, cache_get_json, cache_set_json
from app.models.inventory import Inventory
from app.models.product import Product

_PRODUCT_CACHE_KEY_FMT = "product:{product_id}"


class InsufficientStockError(Exception):
    pass


class ProductNotFoundError(Exception):
    pass


def get_product_cached(db: Session, product_id: int) -> dict | None:
    key = _PRODUCT_CACHE_KEY_FMT.format(product_id=product_id)
    cached = cache_get_json(key)
    if cached is not None:
        return cached

    product = db.get(Product, product_id)
    if product is None:
        return None

    data = {
        "id": product.id,
        "sku": product.sku,
        "name": product.name,
        "price_cents": int(product.price_cents),
    }
    cache_set_json(key, data)
    return data


def reserve_stock(db: Session, product_id: int, quantity: int) -> None:
    inventory = db.query(Inventory).filter(Inventory.product_id == product_id).with_for_update().first()
    if inventory is None or inventory.quantity_on_hand - inventory.quantity_reserved < quantity:
        raise InsufficientStockError(f"insufficient stock for product {product_id}")

    inventory.quantity_reserved += quantity
    db.add(inventory)


def update_stock(db: Session, product_id: int, quantity_on_hand: int) -> Inventory:
    inventory = db.query(Inventory).filter(Inventory.product_id == product_id).with_for_update().first()
    if inventory is None:
        raise ProductNotFoundError(f"no inventory record for product {product_id}")

    inventory.quantity_on_hand = quantity_on_hand
    db.add(inventory)
    db.commit()
    db.refresh(inventory)

    cache_delete(_PRODUCT_CACHE_KEY_FMT.format(product_id=product_id))
    return inventory


def decrement_stock_on_fulfillment(db: Session, product_id: int, quantity: int) -> None:
    inventory = db.query(Inventory).filter(Inventory.product_id == product_id).first()
    if inventory is None:
        return
    inventory.quantity_on_hand -= quantity
    inventory.quantity_reserved = max(0, inventory.quantity_reserved - quantity)
    db.add(inventory)
