import logging

from sqlalchemy.orm import Session

from app.clients.payment_gateway_client import authorize_payment
from app.models.payment import Payment

logger = logging.getLogger(__name__)


def authorize_and_record_payment(
    db: Session,
    order_id: int,
    amount_cents: int,
    card_number: str,
    card_last4: str,
) -> Payment:
    result = authorize_payment(order_id, amount_cents, card_number, card_last4)

    payment = Payment(
        order_id=order_id,
        amount_cents=amount_cents,
        status=result["status"],
        gateway_reference=result["gateway_reference"],
        card_last4=card_last4,
    )
    db.add(payment)
    return payment
