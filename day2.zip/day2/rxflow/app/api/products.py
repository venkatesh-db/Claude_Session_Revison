from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.permissions import require_staff
from app.db import get_db
from app.models.customer import Customer
from app.models.inventory import Inventory
from app.models.product import Product
from app.schemas.product import InventoryOut, ProductOut, StockUpdate
from app.services.inventory_service import ProductNotFoundError, update_stock

router = APIRouter(prefix="/products", tags=["products"])


@router.get("", response_model=list[ProductOut])
def list_products(db: Session = Depends(get_db)) -> list[Product]:
    return db.query(Product).all()


@router.get("/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db)) -> Product:
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="product not found")
    return product


@router.patch("/{product_id}/stock", response_model=InventoryOut)
def update_product_stock(
    product_id: int,
    payload: StockUpdate,
    db: Session = Depends(get_db),
    _staff: Customer = Depends(require_staff),
) -> Inventory:
    try:
        return update_stock(db, product_id=product_id, quantity_on_hand=payload.quantity_on_hand)
    except ProductNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
