from fastapi import APIRouter, Depends

from app.core.security import get_current_customer
from app.models.customer import Customer
from app.schemas.customer import CustomerOut

router = APIRouter(prefix="/customers", tags=["customers"])


@router.get("/me", response_model=CustomerOut)
def get_me(current_customer: Customer = Depends(get_current_customer)) -> Customer:
    return current_customer
