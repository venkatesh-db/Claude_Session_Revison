import os

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = os.environ.get(
        "DATABASE_URL", "sqlite:///./rxflow.db"
    )
    redis_url: str = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    celery_broker_url: str = os.environ.get(
        "CELERY_BROKER_URL", "redis://localhost:6379/0"
    )
    celery_result_backend: str = os.environ.get(
        "CELERY_RESULT_BACKEND", "redis://localhost:6379/1"
    )

    jwt_secret: str = os.environ.get("JWT_SECRET", "dev-secret-change-me")
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60

    # Shared default timeout used by clients that don't set their own.
    default_http_timeout_seconds: float = 5.0

    product_cache_ttl_seconds: int = 300

    environment: str = os.environ.get("RXFLOW_ENV", "development")

    class Config:
        env_file = ".env"


settings = Settings()
