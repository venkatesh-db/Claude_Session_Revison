from pydantic import BaseModel


class OrderItemCreate(BaseModel):
    product_id: int
    quantity: int


class OrderCreate(BaseModel):
    items: list[OrderItemCreate]
    shipping_address: str
    card_number: str
    card_last4: str | None = None


class OrderItemOut(BaseModel):
    product_id: int
    quantity: int
    unit_price_cents: int

    class Config:
        from_attributes = True


class OrderOut(BaseModel):
    id: int
    status: str
    total_cents: int
    shipping_address: str
    items: list[OrderItemOut]

    class Config:
        from_attributes = True
