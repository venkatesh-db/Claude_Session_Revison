from pydantic import BaseModel, Field


class ProductOut(BaseModel):
    id: int
    sku: str
    name: str
    price_cents: int

    class Config:
        from_attributes = True


class StockUpdate(BaseModel):
    quantity_on_hand: int = Field(ge=0)


class InventoryOut(BaseModel):
    product_id: int
    quantity_on_hand: int
    quantity_reserved: int

    class Config:
        from_attributes = True
