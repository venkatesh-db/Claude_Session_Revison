"""Older data-access module predating the services/ layer.

Unlike the rest of the codebase (which queries the ORM directly from
services), this module wraps customer lookups in a small repository class.
It was never retrofitted onto orders/products/inventory, so it's the only
place this pattern appears.
"""

from sqlalchemy.orm import Session

from app.models.customer import Customer


class CustomerRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, customer_id: int) -> Customer | None:
        return self.db.get(Customer, customer_id)

    def get_by_email(self, email: str) -> Customer | None:
        return self.db.query(Customer).filter(Customer.email == email).first()

    def create(self, email: str, hashed_password: str, full_name: str, phone: str | None = None) -> Customer:
        customer = Customer(
            email=email,
            hashed_password=hashed_password,
            full_name=full_name,
            phone=phone,
        )
        self.db.add(customer)
        self.db.flush()
        return customer
