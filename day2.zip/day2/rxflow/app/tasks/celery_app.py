from celery import Celery

from app.config import settings

celery_app = Celery(
    "rxflow",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.task_default_queue = "rxflow"
celery_app.conf.timezone = "UTC"

if settings.environment == "test":
    celery_app.conf.task_always_eager = True
    celery_app.conf.task_eager_propagates = True
