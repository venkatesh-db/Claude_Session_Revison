from app.core.http_client import build_client

_TAX_API_URL = "https://tax.example-taxservice.internal/v1/calculate"


def calculate_tax(shipping_address: str, subtotal_cents: int) -> int:
    client = build_client()
    return _call_tax_service(client, shipping_address, subtotal_cents)


def _call_tax_service(client, shipping_address: str, subtotal_cents: int) -> int:
    # Mocked flat-rate calculation for this lab environment.
    return int(subtotal_cents * 0.08)
