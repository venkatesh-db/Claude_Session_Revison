from app.core.http_client import build_client

_SHIPPING_URL = "https://shipping.example-carrier.internal/v2/labels"

_CONNECT_TIMEOUT_SECONDS = 5.0
_READ_TIMEOUT_SECONDS = 30.0


def create_shipping_label(order_id: int, shipping_address: str) -> dict:
    client = build_client(
        connect_timeout=_CONNECT_TIMEOUT_SECONDS, read_timeout=_READ_TIMEOUT_SECONDS
    )
    return _call_carrier(client, order_id, shipping_address)


def _call_carrier(client, order_id: int, shipping_address: str) -> dict:
    # Mocked: no live network call in this lab environment.
    return {"label_id": f"LBL-{order_id}", "tracking_number": f"TRACK{order_id:08d}"}
