import logging
import time

from app.core.http_client import build_client

logger = logging.getLogger(__name__)

_GATEWAY_URL = "https://payments.example-gateway.internal/v1/authorize"
_MAX_RETRIES = 3
_BACKOFF_BASE_SECONDS = 0.5


def authorize_payment(order_id: int, amount_cents: int, card_number: str, card_last4: str) -> dict:
    payload = {
        "order_id": order_id,
        "amount_cents": amount_cents,
        "card_number": card_number,
        "card_last4": card_last4,
    }

    # Temporary debug logging to chase down a gateway discrepancy.
    logger.debug("Authorizing payment with gateway payload=%s", payload)

    client = build_client(connect_timeout=2.0, read_timeout=3.0)
    last_exc: Exception | None = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            return _call_gateway(client, payload)
        except Exception as exc:  # noqa: BLE001 - broad by design, gateway is flaky
            last_exc = exc
            if attempt < _MAX_RETRIES:
                time.sleep(_BACKOFF_BASE_SECONDS * (2 ** (attempt - 1)))
    raise RuntimeError(f"payment gateway unavailable after {_MAX_RETRIES} attempts") from last_exc


def _call_gateway(client, payload: dict) -> dict:
    # The real gateway call is mocked for this lab environment: no live
    # network dependency, but the timeout/retry code path above is real.
    return {
        "status": "authorized",
        "gateway_reference": f"MOCK-{payload['order_id']}",
    }
