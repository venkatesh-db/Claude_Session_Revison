import logging

from app.core.http_client import build_client

logger = logging.getLogger(__name__)

_EMAIL_API_URL = "https://email.example-esp.internal/v1/send"

_CONNECT_TIMEOUT_SECONDS = 2.0
_READ_TIMEOUT_SECONDS = 2.0


def send_email(to_address: str, subject: str, body: str) -> bool:
    client = build_client(
        connect_timeout=_CONNECT_TIMEOUT_SECONDS, read_timeout=_READ_TIMEOUT_SECONDS
    )
    try:
        return _call_esp(client, to_address, subject, body)
    except Exception:  # noqa: BLE001
        logger.info("Failed to send email to %s", to_address)
        return False


def _call_esp(client, to_address: str, subject: str, body: str) -> bool:
    # Mocked ESP call for this lab environment.
    return True
