from fastapi import Depends, HTTPException, status

from app.core.security import get_current_customer
from app.models.customer import Customer


def require_staff(current_customer: Customer = Depends(get_current_customer)) -> Customer:
    if current_customer.role not in ("staff", "admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Staff role required",
        )
    return current_customer


def require_admin(current_customer: Customer = Depends(get_current_customer)) -> Customer:
    if current_customer.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )
    return current_customer
