import json
from typing import Any

import redis

from app.config import settings

_client: "redis.Redis | None" = None


def get_redis() -> "redis.Redis":
    global _client
    if _client is None:
        _client = redis.Redis.from_url(settings.redis_url, decode_responses=True)
    return _client


def cache_get_json(key: str) -> Any | None:
    try:
        raw = get_redis().get(key)
    except redis.RedisError:
        return None
    if raw is None:
        return None
    return json.loads(raw)


def cache_set_json(key: str, value: Any, ttl_seconds: int = settings.product_cache_ttl_seconds) -> None:
    try:
        get_redis().set(key, json.dumps(value), ex=ttl_seconds)
    except redis.RedisError:
        pass


def cache_delete(key: str) -> None:
    try:
        get_redis().delete(key)
    except redis.RedisError:
        pass
