import httpx

from app.config import settings


def build_client(
    connect_timeout: float | None = None,
    read_timeout: float | None = None,
) -> httpx.Client:
    """Shared factory for outbound HTTP clients.

    Callers may pass explicit connect/read timeouts. If omitted, falls back
    to `settings.default_http_timeout_seconds` for both.
    """
    connect = connect_timeout if connect_timeout is not None else settings.default_http_timeout_seconds
    read = read_timeout if read_timeout is not None else settings.default_http_timeout_seconds
    timeout = httpx.Timeout(connect=connect, read=read, write=read, pool=connect)
    return httpx.Client(timeout=timeout)
