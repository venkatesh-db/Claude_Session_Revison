from fastapi import FastAPI

from app.api import auth, customers, orders, products


def create_app() -> FastAPI:
    application = FastAPI(title="RxFlow")
    application.include_router(auth.router)
    application.include_router(customers.router)
    application.include_router(products.router)
    application.include_router(orders.router)
    return application


app = create_app()


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
