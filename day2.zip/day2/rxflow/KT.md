# RxFlow — Knowledge Transfer

Living reference for onboarding onto this codebase. Update it whenever
behavior described here changes — treat drift between this doc and the code
as a bug in the doc.

## 1. What it is

Internal order-management service: customers register/login, browse
products, place orders, cancel/refund them. Orders trigger stock reservation,
payment authorization, and an async confirmation email.

**Stack**: FastAPI + SQLAlchemy 2.0 (ORM, not Core) + Alembic migrations +
SQLite (dev/test) / Postgres 15 (docker-compose) + Redis (cache + Celery
broker/backend) + Celery (background tasks) + Pydantic v2 (schemas & config)
+ pytest / ruff / mypy.

## 2. Running it locally

```
pip install -r requirements.txt      # make install
make run                             # uvicorn, port 8000, --reload
make test                            # pytest -q
make lint                            # ruff check .
make typecheck                      # mypy app
docker-compose up                    # postgres:5432 + redis:6379
```

Config is env-driven (`app/config.py`, pydantic-settings, reads `.env`).
Defaults fall back to sqlite + local redis, so `make test`/`make run` work
without docker-compose. Set `RXFLOW_ENV=test` to make Celery tasks run
synchronously (`task_always_eager`) — this is why integration tests don't
need a live broker.

## 3. Module map

```
app/
  main.py            FastAPI app factory, mounts 4 routers, GET /health
  config.py          Settings: database_url, redis_url, celery_broker_url/
                      result_backend, jwt_secret/algorithm/expire_minutes,
                      default_http_timeout_seconds (5.0s), product_cache_ttl_seconds (300s)
  db.py               engine / SessionLocal / Base / get_db dependency
  api/
    auth.py            POST /auth/register, /auth/login
    customers.py        GET /customers/me
    products.py          GET /products, /products/{id}, PATCH /products/{id}/stock (staff)
    orders.py            GET /orders (own only), POST /orders, GET /orders/{id}, POST .../cancel, POST .../refund
  services/
    order_service.py      create_order() — the main orchestration function
    payment_service.py     authorize_and_record_payment()
    inventory_service.py    reserve_stock(), get_product_cached(), decrement_stock_on_fulfillment()
    notification_service.py  send_order_confirmation_email()
  models/            customer, product, inventory, order (+OrderItem), payment, webhook_event
  schemas/           auth, customer, order, product (Pydantic request/response)
  repositories/       customer_repository.py — ONLY module using repository pattern
  tasks/
    celery_app.py       Celery app bound to redis broker/backend
    order_tasks.py       send_order_confirmation, sync_inventory_levels, reconcile_payment_webhook
  core/
    security.py          JWT create/decode + bcrypt hashing + get_current_customer dependency
    permissions.py        require_staff, require_admin
    cache.py              Redis JSON get/set/delete wrapper, swallows RedisError silently
    http_client.py         shared httpx.Client factory with a default-timeout fallback
  clients/            payment_gateway_client, shipping_client, email_client, tax_client
                      (all outbound calls are mocked in this environment — no live network)
migrations/versions/  0001_initial_schema, 0002_add_webhook_events,
                      0003_add_reorder_threshold, 0004_add_orders_status_index
tests/
  unit/               test_inventory_service, test_payment_gateway_client, test_security, test_tax_client
  integration/         test_order_flow, test_migrations_apply_live_db
scripts/seed_db.py
```

## 4. Core flow: `POST /orders`

1. `api/orders.py:place_order` — `Depends(get_current_customer)` resolves the
   caller from the JWT; body validated by `OrderCreate` schema.
2. `core/security.py:get_current_customer` — decodes JWT, loads the
   `Customer` row. No role branching here — orders are always
   customer-initiated.
3. `services/order_service.create_order()` — the orchestrator:
   - rejects an empty cart
   - creates the `Order` row, flushes to get an id
   - per item: `inventory_service.reserve_stock()` (row-locked with
     `with_for_update()`, raises `InsufficientStockError` if oversold)
   - `payment_service.authorize_and_record_payment()` →
     `clients/payment_gateway_client.authorize_payment()` (3 retries,
     exponential backoff, mocked gateway call)
   - `db.commit()`
   - `send_order_confirmation.delay(order.id)` — enqueues the Celery task
4. `tasks/order_tasks.send_order_confirmation` — loads Order + Customer,
   calls `notification_service.send_order_confirmation_email()` →
   `clients/email_client.send_email()` (fire-and-forget; exceptions are
   swallowed and logged).

Exercised end-to-end by
`tests/integration/test_order_flow.py::test_place_order_end_to_end`.

## 5. Other routes on `orders.py` — three different auth patterns

- `GET /orders/{id}` — only checks the caller is authenticated; does
  **not** filter by `customer_id`. Any logged-in customer can fetch anyone
  else's order (address, items) by guessing the id.
- `POST /orders/{id}/cancel` — filters `Order.customer_id ==
  current_customer.id` correctly.
- `POST /orders/{id}/refund` — uses `require_staff` (role check) instead of
  ownership, which is correct for a staff-only action.

Three shapes, one file. Before adding a new order route, decide which
pattern it should follow rather than copying whichever one is nearby —
`core/permissions.py` (`require_staff`/`require_admin`) is the only shared
dependency; ownership checks are otherwise done ad hoc inline.

`GET /orders` (list) follows the correct ownership-filter pattern (same as
`cancel_order`). `PATCH /products/{id}/stock` follows the staff-only
pattern (same as `refund_order`) since stock adjustment is an
inventory-management action, not a customer action.

## 6. Redis usage

- **Cache**: `core/cache.py` wraps `redis-py` with JSON get/set/delete,
  used by `inventory_service.get_product_cached()`, key
  `product:{product_id}`, TTL from `settings.product_cache_ttl_seconds`.
  `reserve_stock()` mutates `quantity_reserved` but never invalidates the
  cached product blob — it only clears via TTL expiry. `update_stock()`
  (used by `PATCH /products/{id}/stock`, see §5) does call `cache_delete()`
  on the same key — `reserve_stock()` is still the one open gap.
- **Celery broker/backend**: same Redis instance, different DB indices (0
  broker, 1 backend) — see `config.py` / `tasks/celery_app.py`.
- Redis errors in `cache.py` are caught and swallowed with no logging —
  a cache outage degrades silently rather than alerting.

## 7. Celery tasks — inconsistent retry policy

| Task | Retry config |
|---|---|
| `send_order_confirmation` | `max_retries=5, default_retry_delay=10` |
| `sync_inventory_levels` | `max_retries=1, default_retry_delay=60` |
| `reconcile_payment_webhook` | none — a transient failure drops the job silently, no alert path |

## 8. Outbound HTTP clients — timeout inconsistency

All four route through `core/http_client.build_client()`, which falls back
to `settings.default_http_timeout_seconds` (5.0s) only when a caller omits
explicit timeouts.

| Client | Connect/Read | Retry |
|---|---|---|
| `payment_gateway_client` | 2.0s / 3.0s (explicit) | 3 attempts, exponential backoff |
| `shipping_client` | 5.0s / **30.0s** (explicit, long) | none |
| `email_client` | 2.0s / 2.0s (explicit) | none — errors swallowed, logged at INFO |
| `tax_client` | none passed → falls back to the 5.0s default | none |

Only `tax_client` actually uses the shared default; the other three
hardcode their own. `tax_client.calculate_tax()` is implemented and tested
but **not called** from `order_service.py` — confirm with the order-service
owner whether that's a gap or an intentionally deferred feature before
assuming it's dead code.

## 9. Schema / migrations

Tables: `customers`, `products`, `inventory`, `orders`, `order_items`,
`payments` (migration 0001), `webhook_events` (0002), plus
`inventory.reorder_threshold` added in 0003.

**Drift to know about**: migration `0003_add_reorder_threshold.py` adds
`inventory.reorder_threshold` (NOT NULL DEFAULT 0) to the live schema, but
`app/models/inventory.py` doesn't declare that attribute — any ORM
read/write of `Inventory` silently ignores that column. If you need that
field, add it to the model first.

Run migrations against a scratch DB before trusting model state:
`alembic upgrade head`.

## 10. Logging — PII exposure to watch for

Grep before adding new log lines: `grep -rn "logger\.\(info\|error\|debug\)" app/`

- `notification_service.py` — logs customer email at INFO (routine).
- `order_service.py` (empty-cart path) — logs full shipping address at
  ERROR.
- `order_tasks.py` (`send_order_confirmation`) — logs customer email *and*
  shipping address at INFO.
- `payment_gateway_client.py` — logs the **entire raw payment payload,
  including full card number**, at DEBUG level, behind an innocuous
  "temporary debug logging" comment. This is the highest-severity one in
  the codebase — treat any change near this file as a chance to remove it.

## 11. Design ambiguities (no single correct answer in the code today)

- **Authorization pattern**: `core/permissions.py` role checks vs. inline
  ownership filters vs. no filter at all — see §5. Pick one before adding
  new protected routes and consider migrating the others.
- **Repository vs. direct ORM in services**: `customer_repository.py` is
  the only repository-pattern file; everything else queries models
  directly from `services/`/`api/`. Nothing dictates which new code should
  use.
- **Where caching belongs**: `get_product_cached()` lives in
  `inventory_service.py` even though it only touches `Product`. There's no
  `product_service.py` to move it to yet.
- **`tax_client.py`**: fully built, tested, unused. Confirm intent before
  wiring it in or deleting it.

## 12. Fastest way to get productive with AI assistance on this repo

- Ask for a walkthrough of one route or one service function at a time —
  point at the file, get the real call chain traced against source (not
  assumptions).
- Before adding an endpoint or a new outbound client, ask "how is
  auth/timeout/logging done elsewhere in this repo" so new code matches an
  existing pattern instead of adding a fourth variant.
- Use `make test` / `make lint` / `make typecheck` as a gate before every
  commit — current baseline: 10 passed / 1 skipped, 9 ruff findings (all in
  `tests/`, mostly import-order), 2 mypy errors (`core/cache.py`, from the
  `Redis | None` narrowing on `get_redis()`).
- When you touch `orders.py`, `order_service.py`, `cache.py`, or
  `payment_gateway_client.py`, re-check this doc's relevant section — they
  carry the highest-risk behavior in the repo.
