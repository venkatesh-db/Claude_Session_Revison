"""Seed the local database with a handful of products and a demo customer.

Usage: python scripts/seed_db.py
"""
from app.core.security import hash_password
from app.db import Base, SessionLocal, engine
from app.models.customer import Customer
from app.models.inventory import Inventory
from app.models.product import Product


def main() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(Product).count() == 0:
            widget = Product(sku="WIDGET-1", name="Standard Widget", price_cents=1999)
            gadget = Product(sku="GADGET-1", name="Deluxe Gadget", price_cents=4999)
            db.add_all([widget, gadget])
            db.flush()
            db.add_all(
                [
                    Inventory(product_id=widget.id, quantity_on_hand=100, quantity_reserved=0),
                    Inventory(product_id=gadget.id, quantity_on_hand=50, quantity_reserved=0),
                ]
            )

        if db.query(Customer).filter(Customer.email == "demo@example.com").first() is None:
            db.add(
                Customer(
                    email="demo@example.com",
                    hashed_password=hash_password("demo-password"),
                    full_name="Demo Customer",
                    role="customer",
                )
            )

        db.commit()
        print("Seed complete.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
