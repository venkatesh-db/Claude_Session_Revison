"""add webhook_events table

Revision ID: 0002
Revises: 0001
Create Date: 2023-08-03 11:30:00

"""
from alembic import op
import sqlalchemy as sa

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "webhook_events",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("source", sa.String(64), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("payload_raw", sa.String(4000), nullable=False),
        sa.Column("processed", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("received_at", sa.DateTime, nullable=False),
    )


def downgrade() -> None:
    op.drop_table("webhook_events")
