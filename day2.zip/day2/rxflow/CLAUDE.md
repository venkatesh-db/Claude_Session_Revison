# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository layout

This directory holds several independent, unrelated projects — there is no shared build system or root-level dependency file. Treat each subdirectory as its own project and `cd` into it before running any commands.

- `rxflow/` — the main project: a FastAPI order-management service. See below.
- `rxflow-lab-generator/` — prompt/notes (`GENERATION_PROMPT.md`, `AGENT_ROLE_THINKING.md`) used to generate the `rxflow` lab exercise. Not application code.
- `todo_app/` — a small standalone CLI todo app (Python stdlib only, no dependencies).
- `calculator.py`, `calculator_report.md`, `calculator_architect_review.md`, `seniorsoftware.md` — standalone script and accompanying review notes at the repo root, unrelated to the other projects.

## rxflow — order-management service

Internal order-management service: customers register/login, browse products, place orders, cancel/refund them. Orders trigger stock reservation, payment authorization, and an async confirmation email.

**A detailed, actively-maintained knowledge-transfer doc already exists at [rxflow/KT.md](rxflow/KT.md) — read it before making non-trivial changes.** It covers the full module map, the `POST /orders` call chain file-by-file, three inconsistent authorization patterns across `orders.py`, Redis cache-invalidation gaps, per-client HTTP timeout/retry inconsistencies, a schema/model drift (`inventory.reorder_threshold` exists in migrations but not in the ORM model), and known PII-in-logs spots. Treat drift between KT.md and the code as a bug in the doc and update it when behavior changes.

**Stack**: FastAPI + SQLAlchemy 2.0 (ORM) + Alembic + SQLite (dev/test) / Postgres 15 (docker-compose) + Redis (cache + Celery broker/backend) + Celery + Pydantic v2 (schemas & config) + pytest / ruff / mypy.

### Commands (run from `rxflow/`)

```
pip install -r requirements.txt      # make install
make run                             # uvicorn app.main:app --reload, port 8000
make test                            # pytest -q
make lint                            # ruff check .
make typecheck                       # mypy app
docker-compose up                    # postgres:5432 + redis:6379
alembic upgrade head                 # apply migrations
```

Single test: `pytest tests/unit/test_inventory_service.py::test_name -q` (standard pytest node-id selection; same pattern under `tests/integration/`).

Config is env-driven (`app/config.py`, pydantic-settings, reads `.env`). Defaults fall back to sqlite + local redis, so `make test`/`make run` work without docker-compose. Set `RXFLOW_ENV=test` to make Celery tasks run synchronously (`task_always_eager`), which is why integration tests don't need a live broker.

### Architecture

```
app/
  main.py        FastAPI app factory, mounts 4 routers, GET /health
  config.py      pydantic-settings Settings (db/redis/celery URLs, JWT, timeouts, cache TTL)
  db.py          engine / SessionLocal / Base / get_db dependency
  api/           auth, customers, products, orders — route handlers
  services/      order_service.create_order() is the main orchestrator (inventory -> payment -> commit -> Celery enqueue)
  models/        customer, product, inventory, order (+OrderItem), payment, webhook_event
  schemas/       Pydantic request/response models
  repositories/  customer_repository.py — the ONLY module using the repository pattern (rest of the code queries models directly from services/api)
  tasks/         celery_app.py + order_tasks.py (send_order_confirmation, sync_inventory_levels, reconcile_payment_webhook)
  core/          security.py (JWT + bcrypt + get_current_customer), permissions.py (require_staff/require_admin), cache.py (Redis JSON wrapper), http_client.py (shared httpx.Client factory)
  clients/       payment_gateway_client, shipping_client, email_client, tax_client — all outbound calls are mocked, no live network
migrations/versions/   0001_initial_schema -> 0002_add_webhook_events -> 0003_add_reorder_threshold -> 0004_add_orders_status_index
```

Key things a future change is likely to trip over (full detail in KT.md):

- **Three different authorization shapes coexist in `api/orders.py`**: `GET /orders/{id}` checks only that the caller is authenticated (no ownership filter — a real gap); `POST /orders/{id}/cancel` filters by `customer_id` correctly; `POST /orders/{id}/refund` uses `require_staff`. Decide which pattern a new route should follow rather than copying whichever is nearby.
- **Cache invalidation**: `inventory_service.reserve_stock()` mutates stock but never calls `cache_delete()` on the `product:{id}` Redis key — the product cache only clears via TTL (300s default).
- **HTTP client timeouts/retries are inconsistent per outbound client** — payment/shipping/email hardcode their own values; only `tax_client` falls back to `settings.default_http_timeout_seconds`. `tax_client.calculate_tax()` is implemented and tested but not called anywhere in `order_service.py`.
- **Model/migration drift**: `inventory.reorder_threshold` was added by migration `0003` but is not declared on the `Inventory` ORM model — reads/writes of that field via the model silently ignore it.
- **PII in logs**: grep `logger\.\(info\|error\|debug\)` in `app/` before adding new log lines — several existing call sites log email/shipping address, and `payment_gateway_client.py` logs a full raw card payload at DEBUG.

## todo_app

Standalone CLI todo app, no external dependencies. `todo/core.py` is pure in-memory logic (deliberately no persistence and no concurrency handling — see the module docstring for the explicit triggers that would justify adding either); `todo/cli.py` is a thin I/O shell over it. Run tests with `pytest` from `todo_app/`.
