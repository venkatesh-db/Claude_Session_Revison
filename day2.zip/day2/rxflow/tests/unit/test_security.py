from app.core.security import create_access_token, hash_password, verify_password
from app.config import settings
from jose import jwt


def test_hash_and_verify_password_roundtrip():
    hashed = hash_password("s3cret!")
    assert hashed != "s3cret!"
    assert verify_password("s3cret!", hashed)
    assert not verify_password("wrong", hashed)


def test_create_access_token_contains_expected_claims():
    token = create_access_token(customer_id=42, role="staff")
    payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    assert payload["sub"] == "42"
    assert payload["role"] == "staff"
