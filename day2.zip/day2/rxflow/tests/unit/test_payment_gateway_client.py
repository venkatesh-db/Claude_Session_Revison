from app.clients.payment_gateway_client import authorize_payment


def test_authorize_payment_returns_mocked_success():
    result = authorize_payment(order_id=1, amount_cents=1999, card_number="4242424242424242", card_last4="4242")
    assert result["status"] == "authorized"
    assert result["gateway_reference"] == "MOCK-1"
