import pytest

from app.models.inventory import Inventory
from app.models.product import Product
from app.services.inventory_service import InsufficientStockError, reserve_stock


def test_reserve_stock_succeeds_when_available(db_session):
    product = Product(sku="SKU-1", name="Thing", price_cents=500)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=10, quantity_reserved=0))
    db_session.commit()

    reserve_stock(db_session, product.id, 3)
    db_session.commit()

    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    assert inventory.quantity_reserved == 3


def test_reserve_stock_raises_when_insufficient(db_session):
    product = Product(sku="SKU-2", name="Thing2", price_cents=500)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=2, quantity_reserved=0))
    db_session.commit()

    with pytest.raises(InsufficientStockError):
        reserve_stock(db_session, product.id, 5)
