from app.clients.tax_client import calculate_tax


def test_calculate_tax_applies_flat_rate():
    assert calculate_tax("123 Main St", 10000) == 800
