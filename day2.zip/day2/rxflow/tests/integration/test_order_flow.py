from app.models.inventory import Inventory
from app.models.product import Product


def _register_and_login(client, email="buyer@example.com"):
    client.post(
        "/auth/register",
        json={"email": email, "password": "hunter2pass", "full_name": "Buyer One"},
    )
    resp = client.post("/auth/login", json={"email": email, "password": "hunter2pass"})
    return resp.json()["access_token"]


def _seed_product(db_session, quantity=10):
    product = Product(sku="SKU-ORDER", name="Orderable Thing", price_cents=1000)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=quantity, quantity_reserved=0))
    db_session.commit()
    return product


def test_place_order_end_to_end(client, db_session):
    token = _register_and_login(client)
    product = _seed_product(db_session)

    resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 2}],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 201
    body = resp.json()
    assert body["status"] == "confirmed"
    assert body["total_cents"] == 2000
    assert len(body["items"]) == 1


def test_place_order_without_items_fails(client, db_session):
    token = _register_and_login(client, email="empty@example.com")

    resp = client.post(
        "/orders",
        json={"items": [], "shipping_address": "1 Test Way", "card_number": "4242424242424242"},
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 400


def test_place_order_insufficient_stock_fails(client, db_session):
    token = _register_and_login(client, email="oversell@example.com")
    product = _seed_product(db_session, quantity=1)

    resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 5}],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 400


def test_customer_can_fetch_another_customers_order_by_id(client, db_session):
    """Documents the known authz gap in GET /orders/{order_id}."""
    token_a = _register_and_login(client, email="a@example.com")
    token_b = _register_and_login(client, email="b@example.com")
    product = _seed_product(db_session)

    create_resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 1}],
            "shipping_address": "A's address",
            "card_number": "4242424242424242",
        },
        headers={"Authorization": f"Bearer {token_a}"},
    )
    order_id = create_resp.json()["id"]

    resp = client.get(f"/orders/{order_id}", headers={"Authorization": f"Bearer {token_b}"})
    assert resp.status_code == 200


def test_list_orders_returns_only_own_orders(client, db_session):
    token_a = _register_and_login(client, email="lister-a@example.com")
    token_b = _register_and_login(client, email="lister-b@example.com")
    product = _seed_product(db_session, quantity=10)

    for _ in range(2):
        client.post(
            "/orders",
            json={
                "items": [{"product_id": product.id, "quantity": 1}],
                "shipping_address": "A's address",
                "card_number": "4242424242424242",
            },
            headers={"Authorization": f"Bearer {token_a}"},
        )
    client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 1}],
            "shipping_address": "B's address",
            "card_number": "4242424242424242",
        },
        headers={"Authorization": f"Bearer {token_b}"},
    )

    resp = client.get("/orders", headers={"Authorization": f"Bearer {token_a}"})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 2
    assert all(order["shipping_address"] == "A's address" for order in body)
