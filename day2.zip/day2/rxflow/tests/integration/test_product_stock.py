from app.core.security import create_access_token
from app.models.customer import Customer
from app.models.inventory import Inventory
from app.models.product import Product


def _register(client, email="stock-buyer@example.com"):
    resp = client.post(
        "/auth/register",
        json={"email": email, "password": "hunter2pass", "full_name": "Buyer"},
    )
    return resp.json()["access_token"]


def _register_staff(client, db_session, email="stock-staff@example.com"):
    client.post(
        "/auth/register",
        json={"email": email, "password": "hunter2pass", "full_name": "Staffer"},
    )
    customer = db_session.query(Customer).filter(Customer.email == email).first()
    customer.role = "staff"
    db_session.commit()
    return create_access_token(customer.id, customer.role)


def _seed_product(db_session, quantity=10):
    product = Product(sku="SKU-STOCK", name="Stockable Thing", price_cents=500)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=quantity, quantity_reserved=0))
    db_session.commit()
    return product


def test_staff_can_update_product_stock(client, db_session):
    staff_token = _register_staff(client, db_session)
    product = _seed_product(db_session, quantity=10)

    resp = client.patch(
        f"/products/{product.id}/stock",
        json={"quantity_on_hand": 42},
        headers={"Authorization": f"Bearer {staff_token}"},
    )

    assert resp.status_code == 200
    body = resp.json()
    assert body["product_id"] == product.id
    assert body["quantity_on_hand"] == 42


def test_non_staff_customer_cannot_update_stock(client, db_session):
    token = _register(client)
    product = _seed_product(db_session, quantity=10)

    resp = client.patch(
        f"/products/{product.id}/stock",
        json={"quantity_on_hand": 42},
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 403


def test_update_stock_for_unknown_product_returns_404(client, db_session):
    staff_token = _register_staff(client, db_session)

    resp = client.patch(
        "/products/999999/stock",
        json={"quantity_on_hand": 42},
        headers={"Authorization": f"Bearer {staff_token}"},
    )

    assert resp.status_code == 404


def test_update_stock_rejects_negative_quantity(client, db_session):
    staff_token = _register_staff(client, db_session)
    product = _seed_product(db_session, quantity=10)

    resp = client.patch(
        f"/products/{product.id}/stock",
        json={"quantity_on_hand": -1},
        headers={"Authorization": f"Bearer {staff_token}"},
    )

    assert resp.status_code == 422
