import os

import pytest

pytestmark = pytest.mark.skipif(
    "RXFLOW_LIVE_DB_URL" not in os.environ,
    reason="requires a live Postgres instance configured via RXFLOW_LIVE_DB_URL",
)


def test_alembic_upgrade_head_against_live_postgres():
    from alembic import command
    from alembic.config import Config

    cfg = Config("alembic.ini")
    cfg.set_main_option("sqlalchemy.url", os.environ["RXFLOW_LIVE_DB_URL"])
    command.upgrade(cfg, "head")
