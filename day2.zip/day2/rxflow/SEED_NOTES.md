# SEED_NOTES.md — INTERNAL ANSWER KEY (not for participants)

Generated for the "RxFlow Repository X-Ray" lab. File:line references below
were re-verified by grepping/reading the actual files after the final edit
pass (which stripped a handful of comments that had accidentally named the
planted issues directly, violating the "no breadcrumbs" rule) and by
re-running the full verification suite against that final state.

Stack actually used: **FastAPI + SQLAlchemy 2.0 + Alembic + SQLite (dev/test)
/ Postgres (docker-compose) + Redis + Celery + Pydantic v2 + pytest + ruff +
mypy**, dependencies pinned in `requirements.txt`.

---

## 1. Module map actually built

```
rxflow/
  requirements.txt, pyproject.toml, Makefile, alembic.ini, docker-compose.yml
  app/
    main.py                 - FastAPI app factory + /health
    config.py                - pydantic-settings Settings
    db.py                     - engine/session/Base/get_db
    api/
      auth.py                 - POST /auth/register, /auth/login
      customers.py             - GET /customers/me
      products.py              - GET /products, /products/{id}
      orders.py                - POST /orders, GET /orders/{id}, POST cancel/refund
    services/
      order_service.py         - create_order() orchestration
      payment_service.py        - authorize_and_record_payment()
      inventory_service.py      - reserve_stock(), get_product_cached(), decrement_stock_on_fulfillment()
      notification_service.py   - send_order_confirmation_email()
    models/
      customer.py, product.py, inventory.py, order.py, payment.py, webhook_event.py
    schemas/
      auth.py, customer.py, order.py, product.py
    repositories/
      customer_repository.py    - the ONLY module using the repository pattern (deliberate inconsistency)
    tasks/
      celery_app.py             - Celery app bound to redis broker/backend from config
      order_tasks.py            - send_order_confirmation, sync_inventory_levels, reconcile_payment_webhook
    core/
      security.py                - JWT + bcrypt hashing + get_current_customer dependency
      permissions.py              - require_staff, require_admin
      cache.py                    - Redis JSON get/set/delete wrapper
      http_client.py               - shared httpx.Client factory w/ default timeout fallback
    clients/
      payment_gateway_client.py, shipping_client.py, email_client.py, tax_client.py
  migrations/versions/0001..0004  - see §4
  tests/unit/*, tests/integration/*
  scripts/seed_db.py
```

The "one more supporting table" called for in the brief is `webhook_events`
(`app/models/webhook_event.py`, migrated in `0002_add_webhook_events.py`),
consumed by `reconcile_payment_webhook` in `app/tasks/order_tasks.py` (see
§5).

---

## 2. POST /orders flow — exact file:line path

1. `app/api/orders.py:15` `place_order()` — route handler; `current_customer`
   resolved via `Depends(get_current_customer)` (line 19), body validated by
   `OrderCreate` schema (`app/schemas/order.py`).
2. `app/core/security.py:33` `get_current_customer()` — decodes JWT (line 42),
   loads the `Customer` row (line 49). No staff/role branching happens on
   this path (orders are customer-initiated).
3. `app/services/order_service.py:19` `create_order()` — orchestrates the
   whole flow:
   - empty-cart validation + error log: lines 27-33 (medium PII leak, see §8)
   - `Order` row created + flushed: lines 36-43
   - per item, `reserve_stock()` called at line 51 →
     `app/services/inventory_service.py:34`
   - payment: `authorize_and_record_payment()` called at line 70 →
     `app/services/payment_service.py:11` → `authorize_payment()` in
     `app/clients/payment_gateway_client.py:13`
   - `db.commit()` at line 79
   - Celery enqueue: `send_order_confirmation.delay(order.id)` at line 82 →
     `app/tasks/order_tasks.py:13`
4. `app/tasks/order_tasks.py:13` `send_order_confirmation()` — loads Order +
   Customer (lines 18-23), logs (line 25, PII, see §8), calls
   `send_order_confirmation_email()` in
   `app/services/notification_service.py:8` → `send_email()` in
   `app/clients/email_client.py:13`.

Every hop above is real, executed code, exercised end-to-end by
`tests/integration/test_order_flow.py::test_place_order_end_to_end`, which
passes.

---

## 3. Verified (actually run) tool output

Environment: `.venv` created with `python -m venv .venv` inside
`rxflow/`, dependencies installed from `requirements.txt`.

- `pip install -r requirements.txt` — **succeeded**, no dependency
  conflicts.
- `python -m pytest -q` — **10 passed, 1 skipped**, 33 warnings (all
  `DeprecationWarning`s from `datetime.utcnow()` / anyio / pydantic
  class-based Config — not failures). The skipped test is the one
  integration test gated on a live database.
- `python -m ruff check .` — **9 findings**, all in `tests/`:
  - `tests/conftest.py` — 7x `E402` + 1x `I001` (environment variables must
    be set before `app.*` modules are imported, so those imports are
    intentionally not at the top of the file).
  - `tests/unit/test_security.py` — 1x `I001` (unsorted import block).
  - 2 of the 9 are auto-fixable with `--fix`; left unfixed as authentic,
    believable lint debt.
- `python -m mypy app` — **2 errors**, both in `app/core/cache.py`:
  - line 15: `get_redis()` declared to return `Redis`, but the
    `global _client` lazy-init pattern narrows to `Redis | None`.
  - line 25: `json.loads()` given the redis-py stub's inferred
    `Awaitable[Any] | Any` return type from `.get()`.
  `cache.py` is the oldest, least-touched core module — matches the
  brief's expectation of type debt concentrated in a legacy module.
- App boot — verified via `TestClient(app).get("/health")` → `200
  {"status": "ok"}`, equivalent to the `make run` boot path (ASGI app
  starts and serves cleanly; a literal `uvicorn` process was not left
  running in this shell).
- `alembic upgrade head` against a throwaway sqlite DB — all 4 migrations
  applied in order (0001 → 0002 → 0003 → 0004); `pragma table_info(inventory)`
  confirms the live `reorder_threshold` column exists (see §4 for the
  drift).

Re-run after the final comment-cleanup edit pass (removing lines that had
named PII/severity/drift/gap directly) — identical results: 10 passed / 1
skipped, 9 ruff findings, 2 mypy errors.

---

## 4. Schema, migrations, and the deliberate drift

Tables: `customers`, `products`, `inventory`, `orders`, `order_items`,
`payments` (all in `migrations/versions/0001_initial_schema.py`), plus
`webhook_events` (added in `0002_add_webhook_events.py` — the "one more
supporting table" called for in the brief).

Migrations, in order:
- `migrations/versions/0001_initial_schema.py` — initial 6 tables.
- `migrations/versions/0002_add_webhook_events.py` — adds `webhook_events`.
- `migrations/versions/0003_add_reorder_threshold.py` — **the drift**: adds
  `inventory.reorder_threshold` (`op.add_column`, `NOT NULL DEFAULT 0`) to
  the live schema. `app/models/inventory.py` (7 lines, `Inventory` class)
  has no `reorder_threshold` attribute — any ORM read/write of `Inventory`
  silently ignores that column. Only discoverable by diffing
  `migrations/versions/0003_add_reorder_threshold.py` against
  `app/models/inventory.py`.
- `migrations/versions/0004_add_orders_status_index.py` — adds
  `ix_orders_status` index, no drift.

---

## 5. Redis & Celery usage

- Redis as **cache**: `app/core/cache.py` (`cache_get_json`/`cache_set_json`/
  `cache_delete`), used by `app/services/inventory_service.py:14`
  `get_product_cached()`, keyed `product:{product_id}` (line 7), TTL from
  `settings.product_cache_ttl_seconds` (`app/config.py:25`, 300s default).
  **Caching bug**: `reserve_stock()` (`app/services/inventory_service.py:34-40`)
  mutates `Inventory.quantity_reserved` (line 39) but never calls
  `cache_delete()` on the corresponding `product:{id}` key — the cached
  product blob is never invalidated on a stock change; it only expires via
  TTL. `cache_delete()` exists (`app/core/cache.py:35`) and is exported but
  has no caller anywhere in the codebase — a strong signal once found.
- Redis as **Celery broker/result backend**: `app/tasks/celery_app.py:5-9`,
  reading `settings.celery_broker_url` / `settings.celery_result_backend`
  from `app/config.py:11-16`, both defaulting to the same redis host,
  different DB indices (0 and 1).
- Celery tasks (`app/tasks/order_tasks.py`), 3 total with **varying retry
  config**:
  - `send_order_confirmation` (line 12): `max_retries=5, default_retry_delay=10`
  - `sync_inventory_levels` (line 37): `max_retries=1, default_retry_delay=60`
  - `reconcile_payment_webhook` (line 51): **no retry config at all** — a
    transient failure drops the job silently.
  In test mode (`RXFLOW_ENV`/`environment` == `"test"`),
  `celery_app.conf.task_always_eager` is set (`app/tasks/celery_app.py:14-16`)
  so `.delay()` calls run synchronously without a live broker — this is why
  the order-flow integration tests pass without Redis running.

---

## 6. Outbound calls and timeout/retry inconsistency

All four route through `app/core/http_client.py:6` `build_client()`.

| Client | File | Connect/Read timeout | Retry policy |
|---|---|---|---|
| Payment gateway | `app/clients/payment_gateway_client.py:24` | 2.0s / 3.0s (explicit) | 3 attempts, exponential backoff (`_MAX_RETRIES=3`, `_BACKOFF_BASE_SECONDS=0.5`, lines 9-10, loop at lines 26-32) |
| Shipping/labels | `app/clients/shipping_client.py:5-6` | 5.0s / **30.0s** (explicit, suspiciously long) | none |
| Email (ESP) | `app/clients/email_client.py:9-10` | 2.0s / 2.0s (explicit) | none — fire-and-forget, exception swallowed and logged at INFO (lines 19-21) |
| Tax calculation | `app/clients/tax_client.py:7` `build_client()` called with **no args** | falls back entirely to `settings.default_http_timeout_seconds` (5.0s, `app/config.py:23`) | none |

Three of the four clients (payment, shipping, email) hardcode their own
connect/read timeout constants and never reference
`settings.default_http_timeout_seconds`; only `tax_client.py` depends on it
by omission (it never overrides the factory's defaults). This is the
deliberate cross-client inconsistency called for in the brief.

Note: `calculate_tax()` in `tax_client.py` is a real, tested client but is
not called anywhere in `order_service.py` — see §10.4.

---

## 7. Authorization gap

`app/api/orders.py:36` `get_order()` — checks only that the caller is an
authenticated customer (`Depends(get_current_customer)`, line 39), then
does `db.get(Order, order_id)` (line 41) with **no `customer_id` filter**.
Any authenticated customer can fetch any other customer's order by
guessing/incrementing the order id, including its `shipping_address` and
item list.

Contrast with `cancel_order()` at `app/api/orders.py:48`, which does filter
`Order.customer_id == current_customer.id` (line 55) — the correct pattern
exists nine lines away in the same file, making this a genuine
"which one is right" comparison rather than an obviously missing check.
`refund_order()` (line 67) uses a third pattern again — `require_staff`
(`app/core/permissions.py:7`) instead of an ownership filter, which is
correct for a staff-only action but shows three different authorization
shapes across one file.

Exercised (not asserted-as-a-bug, just exercised as current behavior) by
`tests/integration/test_order_flow.py::test_customer_can_fetch_another_customers_order_by_id`.

---

## 8. PII-in-logs instances

1. **Low severity** — `app/services/notification_service.py:9-14`: customer
   email logged at INFO during routine order confirmation
   (`logger.info("Sending order confirmation for order %s to %s (total=%s)", ...)`).
2. **Medium severity** — `app/services/order_service.py:28-32`: full
   shipping address dumped at ERROR level when an order has zero items
   (`logger.error("Order validation failed for customer %s: no items. address=%s", ...)`).
3. **Medium/high severity** — `app/tasks/order_tasks.py:25-30`: customer
   email **and** shipping address both logged at INFO from the async
   confirmation task
   (`logger.info("Order confirmation task processing order=%s customer_email=%s address=%s", ...)`).
4. **Highest severity** — `app/clients/payment_gateway_client.py:22`:
   DEBUG-level log of the entire outbound payment payload, including raw
   `card_number` and `card_last4` (both present in the `payload` dict built
   at lines 14-19) — `logger.debug("Authorizing payment with gateway
   payload=%s", payload)`, preceded only by an innocuous-sounding comment
   ("Temporary debug logging to chase down a gateway discrepancy.", line 21)
   that does not name it as a PII or security issue.

All four are plain `%s`-style `logging` calls — grep-able via
`grep -rn "logger\.\(info\|error\|debug\)" app/`.

---

## 9. Ranked five highest-risk files (private justification)

1. **`app/clients/payment_gateway_client.py`** — logs the full raw card
   payload at DEBUG (§8.4); also the only module handling a raw
   `card_number` end to end (received in `app/schemas/order.py`, passed
   through `app/api/orders.py` → `order_service.py` → `payment_service.py`
   → here, unmasked at every hop).
2. **`app/api/orders.py`** — hosts the authorization gap (§7); highest
   route fan-in from customer-facing traffic (4 routes, all order-lifecycle
   critical), and the file where three different authz patterns coexist.
3. **`app/services/order_service.py`** — highest fan-out in the codebase
   (touches inventory, payment, DB, and Celery in one function); also has
   the medium-severity address-in-logs leak (§8.2).
4. **`app/core/cache.py`** — every Redis error is swallowed silently
   (`except redis.RedisError: return None` / `pass`, no logging at all,
   lines 21-22, 31-32, 38-39); carries the repo's only 2 mypy errors; and is
   the root dependency of the stale-cache bug surfaced through
   `inventory_service.py` (§5).
5. **`app/tasks/order_tasks.py`** — combines a PII leak (§8.3) with a task
   (`reconcile_payment_webhook`, line 51) that has no retry policy at all,
   meaning a transient failure in payment-webhook reconciliation is dropped
   with no alert path.

---

## 10. Genuinely ambiguous / undocumented design points

1. **Which module owns "the" authorization pattern?** `core/permissions.py`
   (`require_staff`/`require_admin`) is used for `refund_order`, but
   `cancel_order` and `get_order` do their ownership check (or fail to)
   inline in the route function instead of via a shared dependency. All
   three look like plausible "the" pattern for a new endpoint.
2. **Repository vs. direct-ORM-in-service.** `app/repositories/customer_repository.py`
   is the only file using a repository class; every other model is queried
   directly from `services/`/`api/`. Nothing in the code indicates which
   pattern new code should follow.
3. **Where should caching live long-term?** `get_product_cached()` lives in
   `inventory_service.py` even though it only touches `Product`, not
   `Inventory` — arguably misplaced, but no `product_service.py` exists to
   move it to.
4. **`tax_client.py` is fully implemented and tested but never called** from
   `order_service.py` — nothing in the `POST /orders` path invokes
   `calculate_tax()`. Whether this is unfinished integration work or an
   intentionally deferred feature is not resolvable from the code alone.

---

*This file is internal to the lab facilitator. Do not share with
participants.*
