---
name: new-api-endpoint
description: Scaffold a new FastAPI endpoint in the rxflow order-management service, following this repo's existing route/service/schema/test conventions and avoiding its known pitfalls (auth pattern choice, cache invalidation, HTTP client config, PII logging). Use when adding any new route under app/api/, or a new service function it calls.
---

# Adding a new API endpoint to rxflow

Follow these steps in order. Don't skip the "decide" steps — this repo has more
than one existing pattern for several of them, and copying the nearest example
blindly can propagate a known bug (see KT.md).

## 1. Read KT.md first

Read `KT.md` in the repo root before writing any code. It documents the
module map, the three inconsistent auth patterns in `app/api/orders.py`, the
Redis cache-invalidation gap, per-client HTTP timeout inconsistencies, and
PII-in-logs spots. Treat it as more current than your own assumptions about
the code.

## 2. Decide the authorization pattern

`app/core/security.py:get_current_customer` gives you the caller. Then choose:

- **Owner-only access** (a customer can only see/act on their own records) —
  filter the query by `<Model>.customer_id == current_customer.id`, the way
  `cancel_order` and the new `list_orders` do in `app/api/orders.py`. This is
  the default for anything customer-facing.
- **Staff/admin-only action** — use `Depends(require_staff)` or
  `Depends(require_admin)` from `app/core/permissions.py`, the way
  `refund_order` does.
- **Do NOT** copy `GET /orders/{order_id}`'s pattern (auth-only, no ownership
  filter) — that's a known, documented gap, not a template.

State which pattern you're using and why before writing the route.

## 3. Route handler — `app/api/<resource>.py`

- Thin: validate via a Pydantic schema, call a service function, translate
  service exceptions to `HTTPException`, return an ORM object (FastAPI
  serializes it via `response_model`).
- Static path segments before dynamic ones on the same prefix (e.g. `GET
  ""` for a list route must be declared before `GET "/{id}"`, or FastAPI will
  try to match the literal path segment against the `{id}` param first).
- Reuse an existing response schema if the shape already matches (e.g.
  `list[OrderOut]` for a list endpoint) instead of inventing a near-duplicate.

## 4. Service function — `app/services/<name>_service.py`

- Business logic and DB writes live here, not in the route handler.
- This repo queries models directly from services (no repository layer,
  except `customer_repository.py`) — match that unless you have a specific
  reason to introduce a repository for the new code.
- Raise a domain-specific exception (e.g. `OrderValidationError`) for
  expected failure cases; let the route handler map it to an HTTP status.

## 5. Outbound HTTP clients (only if calling something external)

- Go through `app/core/http_client.py:build_client()`.
- Explicit timeouts are inconsistent across existing clients (see KT.md §8)
  — for new code, prefer *not* passing explicit timeouts so it falls back to
  `settings.default_http_timeout_seconds`, matching `tax_client`'s pattern,
  rather than adding a fourth hardcoded value.

## 6. Caching (only if the resource is read-heavy and cached elsewhere)

- If you mutate a cached record, call `cache_delete()` from
  `app/core/cache.py` for the corresponding key. `reserve_stock()` currently
  does NOT do this for `product:{id}` — don't repeat that gap in new code.

## 7. Logging

- Before adding any `logger.info/error/debug` call, grep first:
  `grep -rn "logger\.\(info\|error\|debug\)" app/`
- Never log full card numbers, passwords, or (where avoidable) email/shipping
  address at INFO or above. If you must log an identifier, prefer a
  non-PII key (customer id, order id) over PII fields.

## 8. Schema — `app/schemas/<resource>.py`

- Separate `*Create` (request) and `*Out` (response, `from_attributes =
  True`) models, matching `app/schemas/order.py`.

## 9. Tests

- Add an integration test in `tests/integration/test_<flow>.py` following
  the existing `_register_and_login` / `_seed_product` helper pattern in
  `test_order_flow.py`: register/login a customer via the real HTTP client,
  exercise the new route, assert on the response body and status code.
- If the route is ownership-scoped, add a test with two customers proving
  one cannot see/act on the other's data — this is the single most common
  bug class in this repo (see KT.md §5).

## 10. Verify

Run, in order, and fix anything red before considering the task done:

```
make test
make lint
make typecheck
```

## 11. Update KT.md

If the new endpoint introduces a new pattern (a new auth shape, a new
outbound client, a new cache key) or resolves one of the documented gaps,
update the relevant KT.md section in the same change. Stale docs are treated
as a bug in this repo.
