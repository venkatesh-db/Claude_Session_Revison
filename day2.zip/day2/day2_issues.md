# API 500 Error Investigation — api-2026-08-17.log

## Context
API started returning 500s on the evening of 2026-08-17. Investigation requested as a staged, read-only, evidence-first analysis (no source code review, no fix proposals) to understand the pattern before anyone guesses at a root cause.

## Stage 1 — Understand
- Goal: read-only, evidence-based characterization of the 500 pattern (counts, time window, endpoint/message breakdown, examples, WARN/INFO context), each observation labeled CONFIRMED (directly counted) or HYPOTHESIS (inferred).
- Explicitly out of scope: root-cause diagnosis, reading source code, suggesting fixes.

## Stage 2 — Inspect (read-only findings)

**Volume & window (CONFIRMED)**
- 1,847 total `status=500` lines in `api-2026-08-17.log` (36,130 lines total).
  `grep -c "status=500" api-2026-08-17.log`
- All 500s fall within 19:12:01–21:40:00 on 2026-08-17 (single evening window; none before/after).
- Hourly breakdown of pool-timeout errors: 578 (19:xx), 716 (20:xx), 473 (21:xx) — peak in the 20:00 hour.
  `grep "connection pool timeout" api-2026-08-17.log | awk '{print $1}' | sed 's/.*T//;s/\..*//' | awk -F: '{print $1}' | sort -n | uniq -c`

**By endpoint (CONFIRMED)**
```
1610  POST /orders
 214  POST /pricing/quote
  23  GET  /labs/health
```
`grep "status=500" api-2026-08-17.log | grep -oE '(GET|POST|PUT|DELETE) [^ ]+' | sort | uniq -c | sort -rn`

**By error message (CONFIRMED)**
```
1767  "connection pool timeout: could not acquire connection from pool (size=N, active=N) after Nms"
  64  "InvalidOperation: decimal conversion failed for discount_rate"
  16  "lab connector read timeout after Nms"
```

**Top groups, endpoint × message (CONFIRMED)**
| Rank | Count | Endpoint | Message |
|---|---|---|---|
| 1 | 1594 | POST /orders | connection pool timeout (size=20, active=20) after ~30000ms |
| 2 | 150 | POST /pricing/quote | connection pool timeout (size=20, active=20) after ~30000ms |
| 3 | 64 | POST /pricing/quote | InvalidOperation: decimal conversion failed for discount_rate |
| (4) | 23 | GET /labs/health | connection pool timeout |
| (5) | 16 | POST /orders | lab connector read timeout |

**Example lines (verbatim, CONFIRMED)**
1. `2026-08-17T19:12:01.485+05:30 ERROR [api-2b91] POST /orders status=500 duration_ms=30046 msg="connection pool timeout: could not acquire connection from pool (size=20, active=20) after 30000ms"`
2. `2026-08-17T19:15:47.024+05:30 ERROR [api-2b91] POST /pricing/quote status=500 duration_ms=30004 msg="connection pool timeout: could not acquire connection from pool (size=20, active=20) after 30000ms"`
3. `2026-08-17T19:14:18.554+05:30 ERROR [api-2b91] POST /pricing/quote status=500 duration_ms=135 msg="InvalidOperation: decimal conversion failed for discount_rate"`
4. `2026-08-17T19:51:40.651+05:30 ERROR [api-5a08] GET /labs/health status=500 duration_ms=30037 msg="connection pool timeout: could not acquire connection from pool (size=20, active=20) after 30000ms"`
5. `2026-08-17T19:30:27.191+05:30 ERROR [api-5a08] POST /orders status=500 duration_ms=7345 msg="lab connector read timeout after 4000ms"`

**WARN / INFO context (CONFIRMED)**
- Total WARN lines: 1,280. Total INFO lines: 33,003.
- Baseline WARN types recurring all day at low volume: `celery task retry (rxflow.tasks.submit / notify)`, `redis command latency_ms=N cmd=INCR`, `slow query detected table=lens_jobs`.
- WARN volume by hour is flat (~12–22/hr) until 19:00, then spikes to 369 (19:xx), 393 (20:xx), 311 (21:xx), dropping back to ~15/hr after 22:00 — same window as the 500 spike.
- HYPOTHESIS: the WARN spike (celery retries, redis latency, slow queries) is related to the 500 spike since they share the same time window — but no request/trace-ID-level link was established, so causation is not confirmed, only co-occurrence.

## Stage 3 — Plan (next investigative steps, in order)
1. **Correlate WARN/ERROR by request/trace ID** (if the log has one) rather than by hour, to move from co-occurrence to actual linkage.
2. **Reconstruct the onset timeline** just before 19:12:01 (pool already saturated at active=20/size=20 at first log line) to see if it was a gradual ramp or a sudden step change.
3. **Check correlation between `slow query … table=lens_jobs` WARNs and pool-timeout ERRORs** specifically, per-minute — a classic pool-exhaustion contributor.
4. **Characterize the `InvalidOperation: decimal conversion failed for discount_rate` group (64 events)** separately — may be an unrelated, coincidentally-timed second issue rather than part of the same incident.
5. **Characterize the `lab connector read timeout` group (16 events)** similarly — possibly an independent downstream dependency issue.

**Evidence gaps (not obtainable from this log alone):**
- A request/trace ID field linking WARN and ERROR lines (presence unconfirmed).
- Per-minute (not per-hour) granularity for WARN type 3 vs. pool-timeout errors, to establish lead/lag order.
- Deploy/config-change history (e.g., a ~19:00 deploy) — external to this log.
- Whether `pool size=20` is a long-standing or recently changed config value.

## Side notes from this session
- No source code was opened; no fix was proposed, per explicit instruction.
- Discussed available subagent types (claude, claude-code-guide, Explore, general-purpose, Plan, statusline-setup) and when each would be useful; concluded no subagent was needed yet since all analysis so far was simple enough to run directly and verifiably.
- 6 peer Claude Code sessions were visible on the machine (`day2-cd`, `day2-5d`, `day2-5b`, `day2-00`, `day2-1d`, `rxflow-7b`) but none were used.
