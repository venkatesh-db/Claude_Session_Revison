# AI Reasoning Report: Simple Calculator in Python

## Task
Write a simple calculator program in Python.

## Thought Process

1. **Define the scope.** A "simple calculator" should support the four basic
   arithmetic operations: addition, subtraction, multiplication, and division.
   Anything more (exponents, parentheses, expression parsing) would go beyond
   "simple" and add unnecessary complexity.

2. **Choose a structure.** Rather than writing one large function with a chain
   of if/elif statements, I split each operation into its own small function
   (`add`, `subtract`, `multiply`, `divide`). This keeps each function
   testable and readable, and makes it trivial to extend later if needed.

3. **Dispatch logic.** A `calculate(a, op, b)` function maps the operator
   string to the corresponding function using a dictionary (`operations`).
   This avoids a long if/elif/else chain and is a common, idiomatic Python
   pattern for simple dispatch tables.

4. **Handle edge cases.**
   - Division by zero: raises a `ValueError` with a clear message instead of
     letting Python throw an unhandled `ZeroDivisionError`.
   - Unsupported operator: raises a `ValueError` so the caller gets a clear
     reason rather than a `KeyError`.

5. **User interface.** A simple command-line loop (`main()`) reads input in
   the form `number operator number` (e.g. `3 + 4`), parses it, and prints
   the result. The user can type `q` to quit. Input is validated:
   - The expression must split into exactly 3 parts.
   - The numbers must be convertible to `float` (supports decimals).
   - Errors are caught and shown to the user without crashing the program.

6. **Why a loop instead of a single calculation?** A real "calculator" is
   normally used repeatedly, so an interactive loop is more useful than a
   one-shot script, while still being simple enough to fit the task.

## Result
The final solution is [`calculator.py`](calculator.py):
- Four pure arithmetic functions (easy to test independently)
- A dispatcher function for operator lookup
- A command-line loop with basic input validation and error handling

## Possible Future Extensions (not implemented, kept out of scope)
- Support for full expressions with parentheses and operator precedence
- A GUI (e.g. with `tkinter`)
- Scientific operations (power, square root, trigonometry)
