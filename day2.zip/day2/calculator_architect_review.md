# Principal Architect Review: Simple Calculator

## Reference
This document builds on [`calculator_report.md`](calculator_report.md), which
captured the *implementation agent's* thinking (the developer-level reasoning
behind `calculator.py`). Here, the same artifact is reviewed from a
**principal architect** role — one level up — to identify what an
implementation agent reasons about vs. what a principal architect must
additionally reason about, and to close the gap between the two.

## Role vs. Agent: what each is optimizing for

| | Implementation Agent (developer) | Principal Architect |
|---|---|---|
| Horizon | This task, this file | This system, its lifecycle |
| Unit of concern | Function correctness, readability | Boundaries, contracts, failure domains, evolution |
| Success criteria | "It works, it's clean" | "It works, it's safe, it scales, it's owned by someone" |
| Risk lens | Bugs in logic | Blast radius, misuse, integration, non-functional requirements |

The agent's report is correct *within its scope*. A principal architect's job
is to ask what that scope left out, because a developer optimizing for "this
task" is structurally unlikely to surface concerns outside it.

## Architect-Level Thinking Process

### 1. Re-read the artifact for implicit assumptions, not just stated decisions
The report states the calculator is CLI-based, four operations, `float`
arithmetic, dict dispatch. Reading between the lines, it silently assumes:
- Single-user, single-process, no persistence, no concurrency.
- Trusted input source (a human at a terminal), not another system.
- `float` is "good enough" precision (it isn't, for money/financial use).

An architect's first move is surfacing *unstated* assumptions the agent had
no reason to question, because they were out of its task frame.

### 2. Classify the gap into categories
- **Functional gaps**: no logging, no audit trail, no API surface for reuse
  (the logic isn't separated from the CLI — `main()` couples I/O with
  control flow, which blocks embedding this as a library/service later).
- **Non-functional gaps**: no tests (the report says functions are "testable"
  but no test suite exists), no CI, no packaging, no versioning.
- **Robustness gaps**: `float` for arithmetic is imprecise for decimals
  (e.g. `0.1 + 0.2`); a production calculator handling money would need
  `Decimal`. No max-input/overflow guarding.
- **Security/misuse gaps**: none present here (no `eval`, no dynamic parsing)
  — worth explicitly confirming rather than assuming, since “arithmetic
  input parsers” are a classic injection vector when scope creeps toward
  expression parsing (mentioned as a future extension).
- **Operability gaps**: no logging/observability, no error taxonomy beyond
  `ValueError`, nothing distinguishing user error from programmer error.
- **Ownership/lifecycle gaps**: no versioning, no changelog, no decision on
  where this lives (script vs. package vs. service) or who maintains it.

### 3. Decide what actually matters given the system's real scope
A principal architect does not gold-plate a toy calculator. The correct
architectural judgment here is:
- For a genuinely "simple," standalone CLI tool: the agent's decisions are
  *appropriate*. Adding CI/tests/packaging would be over-engineering for the
  stated scope.
- The judgment call an architect adds is **scope validation**: confirming
  with the requester whether "simple calculator" is truly a toy/demo, or a
  seed for something that will be embedded, exposed as an API, or extended
  with money-handling logic — because that changes several decisions
  (`float` vs `Decimal`, separating logic from I/O, adding tests) from
  "unnecessary" to "required."

### 4. Fill the gap: architect-level additions layered onto the agent's work
Rather than redoing the agent's decisions, an architect's contribution is
*framing conditions and boundaries* around them:
1. **Separate core logic from interface** — extract `add/subtract/multiply/
   divide/calculate` as an importable module independent of `main()`'s CLI
   loop, so it can later back a REST API, a library, or a GUI without
   rewrting logic. (The agent already did the hard part — small pure
   functions — this is just decoupling the entry point.)
2. **Define the precision contract explicitly** — document that `float` is a
   deliberate choice for a demo tool, and flag `Decimal` as required if this
   is ever used for financial calculations.
3. **Establish an error taxonomy** — distinguish `UserInputError` from
   internal errors, so callers (human or programmatic) can handle them
   differently; the agent's blanket `ValueError` is fine for a CLI, not for
   an API.
4. **Add a test suite as a gate**, not an afterthought — the report claims
   functions are "testable"; an architect requires that claim be backed by
   an actual `pytest` suite before this is considered "done" beyond
   prototype stage.
5. **Record the decision, not just the code** — this document itself is the
   architectural artifact: it captures *why* the agent's scope was accepted
   as-is, and what would change that judgment, so the next person (human or
   agent) doesn't have to re-derive it.

## Summary: the actual gap between role and agent
The implementation agent reasons **inside the task boundary**: given "write a
simple calculator," it made locally-optimal, well-justified choices. The
principal architect's role is to reason **about the task boundary itself**:
whether it's the right boundary, what's invisible from inside it, and what
conditions would force it to move. The gap is closed not by redoing the
agent's work, but by adding the missing layer of judgment: assumption
surfacing, risk classification, scope validation, and decision recording.
