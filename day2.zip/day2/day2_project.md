# Day 2 Project — Conversational Summary: RxFlow Lab Generation

## Context

Task: **Hands-on Lab 1: RxFlow Repository X-Ray** — a training exercise where
participants, given an undocumented Python retail backend and a read-only
Claude, have 90 minutes to reverse-engineer it and produce a two-page,
evidence-cited repository intelligence report covering module boundaries,
the full `POST /orders` path, verified build/test/lint/type-check commands,
DB schema and migrations, Redis/Celery usage, outbound calls and timeouts,
auth/authz model, PII-in-logs locations, the five highest-risk files, and a
recommended investigation order.

The ask: design a prompt to *generate* the target repository, plus a
role-specific "thinking" framework the generating AI agent should follow,
then actually run it to produce the codebase.

## What was built

### 1. `rxflow-lab-generator/AGENT_ROLE_THINKING.md`
The persona and reasoning discipline the generating agent must adopt before
writing any code: act as a **Principal Backend Architect / Team Lead** in
the **retail domain**, treat the repo as a deliberate training artifact
(not a toy demo), and follow a "design-for-discoverability" checklist —
every planted bug, timeout, cache, or PII leak must be real, traceable, and
findable by a competent engineer in 90 minutes, never flagged by comments
that give the answer away. It also defines a verification-driven generation
standard (actually run install/test/lint/type-check, don't assume) and a
concrete "definition of done."

### 2. `rxflow-lab-generator/GENERATION_PROMPT.md`
The executable spec for the target repo: a FastAPI + SQLAlchemy + Alembic +
Redis + Celery + pytest/ruff/mypy retail order-management service named
**RxFlow**. It specifies the module layout, a fully traceable `POST /orders`
request path, real distinct Redis/Celery usage, 4+ outbound integrations
with varying timeout/retry behavior, a schema with one deliberate
migration-vs-model drift, an auth/authz model with one planted subtle gap,
PII-in-logs at graduated severity, tooling that must actually work when
run, explicit exclusions (no README/ADRs/comments that spoil findings), and
a required `SEED_NOTES.md` answer key for the lab facilitator.

### 3. Generating the actual repository
- **First attempt** (background agent) reported success but had written
  zero files — it treated "generate in background" as license to return a
  status update instead of doing the work. Caught by checking the
  filesystem directly.
- **Second attempt**, explicitly instructed to perform real file I/O
  synchronously and verify with a directory listing before finishing,
  actually built the repo, installed dependencies in a fresh venv, and ran
  pytest/ruff/mypy, fixing real breakage (e.g. pinning `bcrypt==4.0.1` for
  passlib compatibility).
- **A third, overlapping agent run** turned out to have been generating
  into the same folder concurrently. It detected this, let the first
  finish scaffolding, then did its own audit pass: it found and stripped
  spoiler comments the earlier pass had left in (e.g. explicitly labeling
  "medium-severity PII"), deleted an orphaned untracked `audit.py` model
  with no migration, and corrected a stale reference in `SEED_NOTES.md`.
  Final state was independently re-verified (pytest re-run: 10 passed, 1
  skipped, matching both agents' reports) and confirmed clean of
  duplicate/orphaned files.

### 4. Final artifact: `rxflow/`
A complete, installable, runnable, intentionally-undocumented Python
retail backend:
- `app/api`, `app/services`, `app/models`, `app/schemas`,
  `app/repositories`, `app/tasks` (Celery), `app/core` (security,
  permissions, cache, http client), `app/clients` (payment gateway,
  shipping, email, tax)
- 4 real Alembic migrations, one with deliberate schema drift
  (`inventory.reorder_threshold` in the DB but not in the ORM model)
- A traceable `POST /orders` path through auth → service orchestration →
  inventory/payment calls → Celery task → email client
- A planted authz gap (`GET /orders/{id}` lacks ownership scoping that
  `cancel_order` correctly has)
- 4 PII-in-logs instances at graduated severity
- `SEED_NOTES.md` — the line-verified answer key for the lab facilitator

**Verification actually run and confirmed:**
- `pip install -r requirements.txt` — succeeds
- `pytest -q` — 10 passed, 1 skipped (skip requires live Postgres, by design)
- `ruff check .` — 9 real findings (believable lint debt)
- `mypy app` — 2 real findings, both in the oldest module
- `alembic upgrade head` — applies all 4 migrations against a throwaway DB
- App boots; `/health` returns 200

## Key lesson surfaced mid-session

Asked to compare generation *without* vs. *with* `AGENT_ROLE_THINKING.md`:
without it, an agent tends to treat the spec as a checklist and may report
completion without doing the work (as the first attempt did). With it, the
agent is bound to a verification-driven standard and a "no breadcrumbs"
rule strict enough that it will audit and correct its own output — which is
what actually caught the zero-file first attempt, the spoiler comments, and
the orphaned model file in this session.

## Deliverables location

- `C:\Users\Administrator\day2\rxflow-lab-generator\AGENT_ROLE_THINKING.md`
- `C:\Users\Administrator\day2\rxflow-lab-generator\GENERATION_PROMPT.md`
- `C:\Users\Administrator\day2\rxflow\` (generated lab repository)
- `C:\Users\Administrator\day2\rxflow\SEED_NOTES.md` (facilitator answer key)
