# missingproject.md — What is missing, and how to create it

A build guide, not a complaint list. `EVIDENCE_GAPS.md` records *what* is missing; this file
records *how to create each missing thing*, with the commands and file contents to do it.

Every status below was checked against the working tree. Items marked **UNVERIFIED** could not be
tested, and say why.

**Dependency rule:** M1 blocks M2, M3, M4, M5, M12 and M14. Nothing that fires on a git event can
be built before there is a git repository.

---

## Priority order

| Order | Topic | Why now |
|---|---|---|
| 1 | M1 Version control | unblocks five other topics |
| 2 | M10 `.env.example` + gitignore hole | must land *before* M1's first `git add` |
| 3 | M6 Security blockers | a first audit halts here |
| 4 | M2 Apply the staged hook files | the gate is incomplete without them |
| 5 | M3 CODEOWNERS + branch protection | the only binding control |
| 6 | M4 CI pipeline | makes the gates apply to all ten developers |
| 7 | M5 `claude` CLI | the headless audit has never executed |
| 8 | M7 Green the gates | a red gate cannot be a gate |
| 9 | M8 Doc staleness | future sessions load wrong facts today |
| 10 | M18 Float money | one line; violates a rule three documents state |
| 11 | M17 Webhook ingestion | a whole unwired vertical slice |
| 12 | M9, M11–M16 | hygiene, then the smallest items |

---

## M1 — Version control

**Status:** MISSING. No `.git` in the project root.
**Blocks:** M2, M3, M4, M5, M12, M14, and the `/code-review` command.

Four of the eight Claude Code mechanisms are commit- or push-triggered, so they cannot fire at
all: the hooks have no event, the change log has no commit to record, CODEOWNERS has no forge to
enforce it.

### How to create

    cd /c/Users/Administrator/day4/rxflow

    # Do M10 first, so the artifacts are ignored before the first add.
    git init
    git add -A
    git status                 # READ THIS before committing
    git commit -m "initial commit: RxFlow order-management backend"

    # Seed the change log from history.
    python scripts/changelog/append_entry.py --backfill --no-ai

### Verify

    git log --oneline | head
    git status --short         # expect no *.db and no .env
    grep -c '^## `' EVIDENCE_CHANGE_LOG.md

**Read `git status` before committing.** A first `git add -A` here will otherwise pick up
`test_rxflow.db` (60 KB) and the `lenskart-demo/` SQLite file.

---

## M2 — The staged hook files

**Status:** WRITTEN BUT NOT INSTALLED. `scripts/hooks/pre-commit`, `pre-push` and `install.sh`
exist and pass `bash -n`. Four pieces sit in `scripts/enforcement-staged/` and are not yet
applied, because `.claude/settings.json` denies writes to `scripts/hooks/**` and
`.github/CODEOWNERS` — the deny rules that make the gate read-only bind Claude too, so an owner
has to copy them into place by hand.

| Piece | What it does |
|---|---|
| `pre-commit` stage 0 | refuses any commit touching the gate; verifies sealed checksums |
| `scripts/hooks/post-commit` | writes the per-commit change-log entry |
| `scripts/hooks/seal.sh` | regenerates `MANIFEST.sha256` |
| `.github/CODEOWNERS` | see M3 |

### How to create

    # Staged copies live in the repo at scripts/enforcement-staged/ (durable, version-controlled)

    # stage 0 is a fragment: paste it into scripts/hooks/pre-commit at the marked
    # insertion point, just after the "checking N staged file(s)" echo.
    cat scripts/enforcement-staged/stage0-integrity-block.sh

    cp scripts/enforcement-staged/post-commit scripts/hooks/post-commit
    cp scripts/enforcement-staged/seal.sh     scripts/hooks/seal.sh
    chmod +x scripts/hooks/*

    bash scripts/hooks/install.sh   # sets core.hooksPath
    bash scripts/hooks/seal.sh      # generates MANIFEST.sha256

These were originally staged in a session scratchpad, which **was wiped** — breaking this
instruction until the copies were moved into the repository. Keep them under version control;
`scripts/enforcement-staged/README.md` carries the same apply sequence. Delete that directory in
the commit that seals the manifest, so each file has exactly one source of truth.

### Verify

    git config core.hooksPath                        # expect scripts/hooks
    sha256sum --check scripts/hooks/MANIFEST.sha256  # expect all OK

    # On a throwaway branch, confirm the gate actually refuses:
    git checkout -b hook-test
    echo '# tamper' >> scripts/hooks/pre-commit
    git add -A && git commit -m "should be refused"  # expect exit 1 at stage 0
    git checkout -- . && git checkout - && git branch -D hook-test

**UNVERIFIED:** no hook has ever run as an actual git hook. The scripts parse, and their detection
rules were tested against real files with a no-false-positive control, but there was no repository
to commit into. The block above is the first real test.

---

## M3 — CODEOWNERS and branch protection

**Status:** MISSING. `CODEOWNERS` staged only; no forge configuration.

This is the **only genuinely binding control**. Local hooks and Claude Code deny rules stop
accidental and instructed edits, but a determined developer can delete `.claude/settings.json`,
run `git config --unset core.hooksPath`, or use a different git client.

### How to create

    mkdir -p .github
    cp scripts/enforcement-staged/CODEOWNERS .github/CODEOWNERS
    sed -i 's/@rxflow-owners/@your-real-team-handle/g' .github/CODEOWNERS

Then, on the forge, for the default branch: enable branch protection, **Require review from Code
Owners**, **Include administrators**, and disallow direct pushes.

The staged file covers `/scripts/hooks/`, `/.claude/settings.json`, `/.claude/agents/`,
`/.github/CODEOWNERS`, `/.github/workflows/`, `CLAUDE.md`, `/.claude/skills/`, plus
`security.py`, `permissions.py`, `config.py` and `/migrations/`.

`CLAUDE.md` and `.claude/skills/` are in that list deliberately: a developer who can rewrite the
instructions can otherwise instruct Claude to weaken the gate.

### Verify

Open a pull request touching `scripts/hooks/pre-commit` from a non-owner account and confirm it
cannot merge without owner approval.

---

## M4 — CI pipeline

**Status:** MISSING. No `.github/` directory exists. Without CI the gates run only on the machine
of whoever installed them, which for ten developers is not a gate.

### How to create

Create `.github/workflows/gates.yml` with three jobs:

**`static`** — checkout, Python 3.11, `pip install -r requirements.txt`, then `ruff check .`,
`mypy app`, `pytest -q`.

**`migrations`** — closes gap D1. Add a `postgres:15` service (user/password/db all `rxflow`, with
a `pg_isready` health check), then run:

    RXFLOW_LIVE_DB_URL=postgresql://rxflow:rxflow@localhost:5432/rxflow \
      pytest tests/integration/test_migrations_apply_live_db.py -q

That test is `skipif`-guarded on `RXFLOW_LIVE_DB_URL` and **skips by default locally**, so this job
is the only thing that ever exercises the Alembic chain.

**`hooks`** — checkout with `fetch-depth: 0`, then `bash -n scripts/hooks/pre-commit
scripts/hooks/pre-push` and `sha256sum --check scripts/hooks/MANIFEST.sha256`, so the
deterministic gate applies centrally and cannot be skipped locally.

Do **not** make `mypy app` a required check until M7 is done — it fails today, so it would block
every pull request immediately.

### Verify

Push the branch and confirm three jobs appear, that `migrations` actually runs the test rather
than skipping it, and that `hooks` fails when `MANIFEST.sha256` is stale.

---

## M5 — The `claude` CLI

**Status:** MISSING from PATH. `which claude` finds nothing.

Consequence: the headless audit stages in `pre-commit` stage 2 and `pre-push` both degrade to a
printed notice and `exit 0`. That degradation is deliberate — a missing CLI must never cost
someone a commit — but it means **the release-readiness agent has never actually executed.**

### How to create

Install the Claude Code CLI so `claude -p` resolves, then confirm the agent runs standalone
before trusting the hook path:

    claude --version
    claude -p "Use the release-readiness agent to audit this repository. Be brief." \
      --allowedTools "Read,Grep,Glob,Bash"

### Verify

    RXFLOW_READINESS=advisory git commit --allow-empty -m "audit smoke test"
    # expect stage 2 to print a verdict block, not a skip notice

For CI, the audit needs an API key in secrets; scope it to a job that does not run on fork pull
requests.

---

## M6 — The three security blockers

**Status:** PRESENT IN CODE. Not missing files — missing fixes, and they are what a first audit
stops on.

| # | Fix | Location |
|---|---|---|
| 1 | Delete the payload log line, or log named masked fields only | `app/clients/payment_gateway_client.py:22` |
| 2 | Fail startup if `JWT_SECRET` is unset outside development | `app/config.py:18` |
| 3 | Fail startup if `DATABASE_URL` is unset outside development | `app/config.py:7` |

### How to create

For 1, remove the line and its "Temporary debug logging" comment. If the diagnostic is still
needed, log `{"order_id": ..., "amount_cents": ..., "card_last4": ...}` explicitly — never the
container.

For 2 and 3, add a validator to `Settings` so a missing variable is a startup failure rather than
a silently working app:

    # app/config.py, inside Settings
    @model_validator(mode="after")
    def _reject_dev_defaults_outside_development(self) -> "Settings":
        if self.environment == "development":
            return self
        if self.jwt_secret == "dev-secret-change-me":
            raise ValueError("JWT_SECRET must be set when RXFLOW_ENV is not 'development'")
        if self.database_url.startswith("sqlite"):
            raise ValueError("DATABASE_URL must be set when RXFLOW_ENV is not 'development'")
        return self

`from pydantic import model_validator` — pydantic 2.6.1 is already pinned.

### Verify

    # Scope to the logging call: the `payload` dict itself is legitimate and stays.
    grep -n 'logger.*payload' app/clients/payment_gateway_client.py   # expect nothing
    RXFLOW_ENV=production python -c "import app.config"        # expect ValueError
    RXFLOW_ENV=test python -c "import app.config; print('ok')" # expect ok
    pytest -q                                                  # must still pass

Fixing item 1 also makes `pre-commit` stage 1 pass on a file it currently blocks.

---

## M7 — Green the gates

**Status:** `make lint` fails with 10 errors; `make typecheck` fails with 4 and **has never been
green**, so it cannot serve as a release gate today.

### How to create

The `conftest.py` E402s are **deliberate** — the env vars must be set before the app import — so
the fix is a per-file ignore, not a reorder. Append to `pyproject.toml`:

    [tool.ruff.lint.per-file-ignores]
    # conftest sets RXFLOW_ENV/DATABASE_URL before importing the app; the import
    # order is load-bearing, so E402 here is correct, not a defect.
    "tests/conftest.py" = ["E402", "I001"]

Then `ruff check --fix tests/unit/test_security.py`.

For the 4 mypy errors in `app/core/cache.py`, the redis stubs type `get`/`incr`/`decr` as
sync-or-async unions. Narrow at the boundary rather than blanket-ignoring the module: assert
`_client is not None` in `get_redis()` before returning it, and wrap the command returns as
`cast(int, get_redis().incr(key))` with `from typing import cast`.

### Verify

    ruff check .        # expect clean
    mypy app            # expect "Success: no issues found"
    pytest -q           # expect unchanged pass count

Only once both are clean should `mypy app` become a required CI check.

---

## M8 — Documentation that is now wrong

**Status:** STALE. The most dangerous item here, because stale instructions are *trusted*.

`CLAUDE.md` now requires that skills and agents be reviewed whenever a documented workflow
changes. That rule is currently unmet:

| File | What it says | Reality |
|---|---|---|
| `.claude/skills/api-flow/SKILL.md:90` | "`sync_inventory_levels` … nothing in `app/` calls it — fulfillment is unwired" | **False.** `POST /orders/{order_id}/fulfill` calls it. |
| `CLAUDE.md` | describes the order lifecycle without a fulfillment step | incomplete: `fulfill_order` and the `fulfilled` status are undocumented |
| `ONBOARDING.md` | same omission | incomplete |

### How to create

1. In `CLAUDE.md`, add `fulfill_order` as the lifecycle step after payment: staff-only,
   `confirmed → fulfilled`, re-fulfilment is a no-op so a retried client cannot double-decrement,
   and it is what finally invokes `sync_inventory_levels`. Record the status set:
   `pending → confirmed → fulfilled`, with `cancelled` / `refunded` branches.
2. In `.claude/skills/api-flow/SKILL.md`, replace the "fulfillment is unwired" gap with the two
   that are still true: `decrement_stock_on_fulfillment` takes no row lock, and `cancel_order`
   still leaks `quantity_reserved`.
3. In `ONBOARDING.md`, add the fulfillment step to "The core workflow".
4. Re-run `bash scripts/hooks/seal.sh` if anything under `.claude/` changed.

### Verify

    grep -n 'fulfill' CLAUDE.md .claude/skills/api-flow/SKILL.md ONBOARDING.md
    grep -n 'unwired' .claude/skills/api-flow/SKILL.md    # expect no hits

---

## M9 — README.md

**Status:** MISSING. A fresh clone has no entry point; `ONBOARDING.md` and `CLAUDE.md` are
discovered only by knowing they exist.

### How to create

Keep it pointer-shaped — the detail already lives elsewhere. Cover: one paragraph on what RxFlow
is, the `make install` / `docker-compose up` / `make run` sequence, the three gate commands, then
links to `ONBOARDING.md` (new engineers), `CLAUDE.md` (loaded automatically by Claude Code),
`EVIDENCE_GAPS.md` and this file (what is incomplete), and `EVIDENCE_CHANGE_LOG.md` (per-commit
history). Close with the warning that external integrations are mocked and this must not point at
a live payment gateway before the Part E blockers are closed.

---

## M10 — `.env.example` and the gitignore hole

**Status:** BOTH MISSING. Required env vars are recorded nowhere but `app/config.py`, and
`.gitignore` covers `rxflow.db` but **not** `test_rxflow.db`, which is in the root right now.

### How to create

Create `.env.example` listing `RXFLOW_ENV`, `DATABASE_URL`, `REDIS_URL`, `CELERY_BROKER_URL`,
`CELERY_RESULT_BACKEND` and `JWT_SECRET` — with `JWT_SECRET` left empty and marked required
outside development, since M6 makes startup fail without it. Then:

    printf 'test_rxflow.db\nlenskart-demo/**/*.db\n' >> .gitignore

### Verify

    git check-ignore -v test_rxflow.db     # expect a match

Do this **before** M1's first `git add -A`.

---

## M11 — The dangling evidence pointer

**Status:** MISSING FILE, LIVE REFERENCE. `app/core/cache.py:50` points readers at
`EVIDENCE_redis_counter_drift.md`, which does not exist. Future sessions will chase it.

### How to create

Either write the file — the reproduction of the get/modify/set counter drift and why `INCR` fixes
it — or delete the reference from the docstring. Do one; leaving it as-is is the only wrong answer.

---

## M12 — Slash commands

**Status:** MISSING. No `.claude/commands/` directory.

The right shape for a short fixed thing typed most days: no judgement, no branching.

### How to create

    mkdir -p .claude/commands

Then three files:

- **`gates.md`** — run `ruff check .`, `mypy app`, `pytest -q` and report only deltas from the
  known baseline (ruff 10, mypy 4 in `cache.py`, pytest green), stating explicitly when a
  pre-existing failure is now fixed.
- **`drift.md`** — compare every column in `app/models/*.py` against what the Alembic chain
  produces, reporting drift in both directions and noting which is worse: a model column with no
  migration breaks on deploy; a migration column with no model attribute survives only on its
  server default. Seed it with the known case, `inventory.reorder_threshold`.
- **`changelog.md`** — run `python scripts/changelog/append_entry.py --range $ARGUMENTS`, noting
  that already-logged commits are skipped so it is safe to re-run.

### Verify

Type `/gates` in a session and confirm it resolves.

---

## M13 — An MCP server

**Status:** MISSING. Ten claude.ai connectors are listed for this session and **none is
authenticated**, so none can be used. The product page read earlier used a built-in fetch tool,
which is not MCP.

### How to create

Authorisation cannot be done from a non-interactive session. For claude.ai connectors, authorise
them in claude.ai connector settings; for other servers, use `claude mcp` or `/mcp` in an
interactive session. Do not paste tokens or callback URLs into a session.

**Where it would pay here:** the change log classifies commits as defect or enhancement from the
message text alone. An issue-tracker connection would let it cite the real ticket instead of
inferring intent from a verb.

---

## M14 — Run the release-readiness agent

**Status:** DEFINED, NEVER RUN. `.claude/agents/release-readiness.md` has never executed once, so
its checklist has never been tested against the codebase it describes.

### How to create

Dispatch it in a session, before wiring it into anything that blocks:

    Use the release-readiness agent to audit this repository.

Expect NO-GO on the M6 blockers — that is the agent working. The point of the first run is to
confirm its findings match `EVIDENCE_GAPS.md` Part E, and to catch any check that misfires.

---

## M15 — Close out the demo build

**Status:** INCOMPLETE. `lenskart-demo/frontend/` and `lenskart-demo/backend/` each pass their own
gates, but the halves have never been exercised together.

| Item | Fix |
|---|---|
| Four facets unwired: `weight`, `collection`, `face_shape`, `occasion` — omitted from the API contract | one line each in `_COLUMN_FILTERS` and the router signature |
| Frontend JavaScript never executed — no `node`, no headless browser — **UNVERIFIED** | install node or a headless browser, then load the page |
| CORS verified by curl only | exercise it from the real page |
| Facet counts catalogue-wide, not selection-narrowed | make `/api/filters` accept the active filter set |

### How to create

    cd lenskart-demo/backend && uvicorn main:app --port 8001 &
    cd ../frontend && python -m http.server 8080 &
    # set USE_MOCK = false in app.js, load http://localhost:8080, and confirm the
    # field names the page expects match what the API actually emits

"The two halves fit together" is currently an inference from a shared contract, not an observed
fact. This is the check that changes that.

---

## M16 — Enforcement decisions still open

Not missing code — missing decisions. Each needs an owner's answer.

| # | Decision | Default today |
|---|---|---|
| 1 | Should stage 0 protect `CLAUDE.md` and `.claude/skills/` locally, not just via CODEOWNERS? | not protected — this is the "developer instructs Claude" vector |
| 2 | Should the readiness audit block commits, or only advise? | `blocking` on commit, `advisory` on push |
| 3 | Should pushing require every commit to have a change-log entry? | not enforced; `post-commit` cannot block |
| 4 | Should `cancel_order` release `quantity_reserved`? | it does not; cancels strand stock permanently |
| 5 | Should `decrement_stock_on_fulfillment` take a row lock like its siblings? | it does not, and it is now HTTP-reachable |

Items 4 and 5 change existing behaviour, which is why they were flagged rather than done.

---

## M17 — Webhook ingestion is entirely unwired

**Status:** MISSING ENTRY POINT. Found only on a re-verification pass; it was absent from the
first version of every gap document, including this one.

`app/models/webhook_event.py` defines a `WebhookEvent` table. Migration
`0002_add_webhook_events.py` creates it. `app/tasks/order_tasks.py:56` defines
`reconcile_payment_webhook`, which marks an event processed. **Nothing writes a `WebhookEvent`
row, and nothing calls the task** — `grep -rn 'reconcile_payment_webhook' app/` matches only its
own decorator. There is no route under `app/api/` that accepts a webhook.

So the feature is a complete vertical slice with no front door: a model, a migration and a worker,
reachable by nothing. This is the same class of defect as `sync_inventory_levels` having no caller
before `POST /orders/{order_id}/fulfill` was added — and it is the *last* remaining instance.

### How to create

Use the `api-new` skill; the layering it enforces is exactly what this needs.

    /api-new POST /webhooks/payment — accepts a payment-gateway webhook, persists a
    WebhookEvent row, and enqueues reconcile_payment_webhook. Public route (gateways
    do not carry our JWT) so it MUST verify a shared-secret signature header instead,
    and it must be idempotent on the gateway's own event id.

Design points to settle before writing:

- **Authentication.** A webhook cannot use `get_current_customer`. It needs signature
  verification against a secret from `Settings`, which is a new env var for M10 and a new startup
  check for M6.
- **Idempotency.** Gateways retry. The natural key is the gateway's event id, which the current
  table has no column for — so this needs a new migration adding a unique constraint, following
  the `uq_orders_customer_idempotency_key` precedent.
- **`payload_raw` is `String(4000)`.** A larger payload will either truncate or raise depending on
  the backend. Validate the length before insert and return 413 rather than failing at the DB.
- **Respond fast.** Persist, enqueue, return 202. Do not reconcile inline — that is what the task
  is for.

### Verify

    grep -rn 'reconcile_payment_webhook' app/          # expect a caller, not just the decorator
    grep -rn 'webhook' app/api/                        # expect a route
    pytest tests/integration/test_webhooks.py -q       # signature reject, replay, oversize payload

---

## M18 — Float arithmetic on a money value

**Status:** PRESENT IN CODE. Also found only on the re-verification pass.

`app/services/notification_service.py:16` formats the order total as:

    body = f"Thanks for your order! Total: ${total_cents / 100:.2f}"

`CLAUDE.md` states money is integer cents and never floats. There are **two** violations, not one
— the second was found only by running the grep this section recommends:

| Site | Code | Why it matters |
|---|---|---|
| `app/services/notification_service.py:16` | `total_cents / 100:.2f` | display-only, but `/ 100` is a binary float and `:.2f` rounds half-to-even, so some totals render a cent away from what was charged |
| `app/clients/tax_client.py:13` | `int(subtotal_cents * 0.08)` | **computes a money value through a float.** `int()` truncates toward zero, so tax is systematically under-collected on some subtotals |

The tax one is the more serious of the two: it is not display, it is arithmetic that produces a
number the system then treats as money.

It also hardcodes `$` while prices elsewhere in this project are quoted in rupees.

### How to create

For the notification, format with integer division so no float enters the path:

    rupees, paise = divmod(total_cents, 100)
    body = f"Thanks for your order! Total: {rupees}.{paise:02d}"

For the tax client, do the percentage in integers and state the rounding rule explicitly:

    # 8%, rounded half-up, entirely in integers.
    return (subtotal_cents * 8 + 50) // 100

Then confirm both are gone:

    grep -rn 'cents *[/*]' app/ | grep -v '//'    # expect no hits

### Verify

    grep -rn 'cents *[/*]' app/ | grep -v '//'   # expect no hits
    pytest -q                                    # tax tests exist: tests/unit/test_tax_client.py

### Learn

A stated invariant is only real if something enforces it. "Money is integer cents" appears in
`CLAUDE.md`, in `ONBOARDING.md` and in the `api-new` skill, and was still violated in **two**
files — one of them seventeen lines long and never opened during the original review. A single
grep in the pre-commit gate would have caught both; three documents caught neither.

---

## Completion checklist

    [ ] M10 .env.example + gitignore test_rxflow.db   (BEFORE M1's git add)
    [ ] M1  git init, baseline commit, backfill change log
    [ ] M6  three security blockers
    [ ] M2  apply stage 0, post-commit, seal.sh; install + seal
    [ ] M3  CODEOWNERS + branch protection
    [ ] M4  CI: static / migrations / hooks jobs
    [ ] M5  claude CLI on PATH; smoke-test the audit
    [ ] M7  ruff clean, mypy clean; then make them required checks
    [ ] M8  fix stale api-flow gap text, CLAUDE.md, ONBOARDING.md
    [ ] M9  README.md
    [ ] M11 write or remove EVIDENCE_redis_counter_drift.md
    [ ] M12 /gates, /drift, /changelog
    [ ] M13 authorise an MCP server (interactive session required)
    [ ] M14 run release-readiness once
    [ ] M15 wire 4 facets, exercise the demo end to end
    [ ] M16 answer the five open decisions
    [ ] M17 webhook ingestion route + signature + idempotency migration
    [ ] M18 remove float money math: notification_service.py:16 AND tax_client.py:13
