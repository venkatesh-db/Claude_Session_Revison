"""FastAPI application for the eyewear catalogue demo (serves on port 8001)."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api import products
from db import Base, engine

FRONTEND_ORIGINS = ["http://localhost:8080", "http://127.0.0.1:8080"]


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    """Create the schema if the DB file has not been seeded yet (no Alembic in this demo)."""
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(title="Eyewear Catalogue API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(products.router)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
