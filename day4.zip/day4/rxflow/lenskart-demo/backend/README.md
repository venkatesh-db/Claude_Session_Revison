# Eyewear Catalogue API

FastAPI service backing the eyeglasses product-listing page: faceted browse, sorting and
pagination over ~928 deterministically seeded frames. Standalone from the main RxFlow app, but
follows the same house conventions (integer money, `api/` → `services/` → `models/`, no repository
layer, services raise plain exceptions).

## Run

```bash
pip install -r requirements.txt
python seed.py                            # creates catalogue.db with 928 products
uvicorn main:app --port 8001 --reload
```

Then `http://127.0.0.1:8001/health` → `{"status":"ok"}` and
`http://127.0.0.1:8001/docs` for the OpenAPI UI.

CORS is open to `http://localhost:8080` (and `127.0.0.1:8080`), where the frontend is served.

## Tests / lint / types

```bash
python -m pytest -q
ruff check .
mypy .
```

## Endpoints

| Method | Path                 | Notes                                          |
| ------ | -------------------- | ---------------------------------------------- |
| GET    | `/health`            | liveness                                       |
| GET    | `/api/products`      | filter + sort + paginate                       |
| GET    | `/api/filters`       | facet keys, labels and DB-computed counts      |
| GET    | `/api/products/{id}` | one frame; `404 {"detail": "product not found"}` |

### `GET /api/products` query params

- `page` (≥1, default 1), `page_size` (1–48, default 12)
- `sort` ∈ `recommended | price_asc | price_desc | newest | rating`
- `gender`, `shape`, `brand`, `color`, `frame_type`, `material`, `size` — repeatable.
  Values within one facet are OR-ed; different facets are AND-ed.
- `price_min`, `price_max` — integer paise, **both bounds inclusive**

Sort semantics: `recommended` = highest discount first, `newest` = newest `created_at` first,
`rating` = highest rating then most reviews. Every mode carries an `id` tiebreak so pages never
overlap.

## Money and rating

All money is integer paise in `*_paise` fields — no floats anywhere in storage or the payload.
`discount_percent` is **computed** with integer floor division from `price_paise`/`mrp_paise`
(both in the `Product.discount_percent` property and, for the `recommended` ORDER BY, in SQL) and
is never stored. `rating` is stored as `rating_tenths` (an int) and divided by 10 on read.

## Environment

`EYEWEAR_DATABASE_URL` overrides the SQLite file (defaults to `catalogue.db` next to `db.py`);
the test suite points it at a temp-file DB.
