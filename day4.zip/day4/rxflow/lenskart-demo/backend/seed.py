"""Deterministic catalogue seeder.

Generates ``DEFAULT_PRODUCT_COUNT`` (928) frames from a fixed RNG seed, so facet counts are
byte-for-byte reproducible across machines and across test runs. After generating, it asserts that
every facet value in ``catalogue_data`` actually occurs at least once — otherwise a filter option
would render in the UI with a count of zero.

Usage:  python seed.py
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from catalogue_data import (
    BRANDS,
    CATEGORY_BADGES,
    COLLECTIONS,
    COLORS,
    FACE_SHAPES,
    FRAME_TYPES,
    GENDERS,
    IMAGE_KIND_BY_SHAPE,
    MATERIALS,
    OCCASIONS,
    OFFER_BADGES,
    PRICE_BUCKETS,
    PROMO_CODES,
    SHAPES,
    SIZES,
    WEIGHTS,
)
from db import Base, SessionLocal, engine
from models.product import Product, ProductColor

RANDOM_SEED = 20240909
DEFAULT_PRODUCT_COUNT = 928

#: MRP tiers in paise, chosen so that every bucket in ``PRICE_BUCKETS`` ends up populated.
_MRP_TIERS: list[int] = [
    99_900,
    149_900,
    199_900,
    249_900,
    299_900,
    399_900,
    499_900,
    649_900,
    799_900,
    999_900,
]

#: Discount percentages applied to the MRP to derive the selling price.
_DISCOUNTS: list[int] = [0, 10, 15, 20, 25, 30, 40, 50, 60]

_EPOCH = datetime(2024, 1, 1, 9, 0, 0)


def _brand_prefix(brand: str) -> str:
    """"Vincent Chase" -> "VC"; single-word brands take their first two letters."""
    parts = brand.split()
    if len(parts) > 1:
        return "".join(word[0] for word in parts).upper()
    return brand[:2].upper()


def build_products(count: int = DEFAULT_PRODUCT_COUNT) -> list[Product]:
    """Build (but do not persist) ``count`` deterministic products."""
    rng = random.Random(RANDOM_SEED)
    products: list[Product] = []

    for index in range(count):
        brand = rng.choice(BRANDS)
        shape = rng.choice(SHAPES)

        mrp_paise = rng.choice(_MRP_TIERS)
        discount = rng.choice(_DISCOUNTS)
        # Integer paise throughout — the selling price is floored, never rounded through a float.
        price_paise = mrp_paise - (mrp_paise * discount // 100)

        colors = rng.sample([hex_code for hex_code, _ in COLORS], k=rng.randint(2, 4))

        product = Product(
            brand=brand,
            model_name=f"{_brand_prefix(brand)} E{10000 + index}",
            rating_tenths=rng.randint(30, 50),
            review_count=rng.randint(11, 4200),
            price_paise=price_paise,
            mrp_paise=mrp_paise,
            promo_code=rng.choice(PROMO_CODES),
            offer_badge=rng.choice(OFFER_BADGES),
            category_badge=rng.choice(CATEGORY_BADGES),
            size=rng.choice(SIZES),
            shape=shape,
            gender=rng.choice(GENDERS),
            frame_type=rng.choice(FRAME_TYPES),
            material=rng.choice(MATERIALS),
            weight=rng.choice(WEIGHTS),
            collection=rng.choice(COLLECTIONS),
            face_shape=rng.choice(FACE_SHAPES),
            occasion=rng.choice(OCCASIONS),
            image_kind=IMAGE_KIND_BY_SHAPE[shape],
            # Strictly increasing with index, so "newest" == highest id.
            created_at=_EPOCH + timedelta(minutes=index),
            color_rows=[
                ProductColor(hex_code=hex_code, position=position)
                for position, hex_code in enumerate(colors)
            ],
        )
        products.append(product)

    _assert_full_coverage(products)
    return products


def _assert_full_coverage(products: list[Product]) -> None:
    """Fail loudly if the seed missed a facet value or a price bucket."""
    checks: list[tuple[str, list[str], set[str]]] = [
        ("gender", GENDERS, {p.gender for p in products}),
        ("shape", SHAPES, {p.shape for p in products}),
        ("size", SIZES, {p.size for p in products}),
        ("brand", BRANDS, {p.brand for p in products}),
        ("frame_type", FRAME_TYPES, {p.frame_type for p in products}),
        ("material", MATERIALS, {p.material for p in products}),
        ("weight", WEIGHTS, {p.weight for p in products}),
        ("collection", COLLECTIONS, {p.collection for p in products}),
        ("face_shape", FACE_SHAPES, {p.face_shape for p in products}),
        ("occasion", OCCASIONS, {p.occasion for p in products}),
        (
            "color",
            [hex_code for hex_code, _ in COLORS],
            {row.hex_code for p in products for row in p.color_rows},
        ),
    ]
    for name, expected, seen in checks:
        missing = set(expected) - seen
        if missing:
            raise AssertionError(f"seed left {name} values unused: {sorted(missing)}")

    prices = [p.price_paise for p in products]
    for value, _label, low, high in PRICE_BUCKETS:
        in_bucket = [p for p in prices if p >= low and (high is None or p <= high)]
        if not in_bucket:
            raise AssertionError(f"seed left price bucket {value} empty")


def seed(db: Session, count: int = DEFAULT_PRODUCT_COUNT, *, reset: bool = True) -> int:
    """Populate ``db`` with the deterministic catalogue and return the row count."""
    if reset:
        db.query(ProductColor).delete()
        db.query(Product).delete()
        db.flush()

    db.add_all(build_products(count))
    db.commit()
    return int(db.execute(select(func.count(Product.id))).scalar_one())


def main() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        total = seed(db)
        colors = int(db.execute(select(func.count(ProductColor.id))).scalar_one())
    finally:
        db.close()
    print(f"seeded {total} products and {colors} colourways (seed={RANDOM_SEED})")


if __name__ == "__main__":
    main()
