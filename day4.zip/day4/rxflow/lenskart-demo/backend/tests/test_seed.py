"""Determinism tests for the seeder."""

from __future__ import annotations

from sqlalchemy import func, select

from db import SessionLocal
from models.product import Product, ProductColor
from seed import DEFAULT_PRODUCT_COUNT, build_products


def test_seed_is_deterministic() -> None:
    first = build_products(50)
    second = build_products(50)

    def fingerprint(products: list[Product]) -> list[tuple[object, ...]]:
        return [
            (
                p.brand,
                p.model_name,
                p.price_paise,
                p.mrp_paise,
                p.shape,
                tuple(r.hex_code for r in p.color_rows),
            )
            for p in products
        ]

    assert fingerprint(first) == fingerprint(second)


def test_seeded_row_counts() -> None:
    db = SessionLocal()
    try:
        products = db.execute(select(func.count(Product.id))).scalar_one()
        colors = db.execute(select(func.count(ProductColor.id))).scalar_one()
    finally:
        db.close()
    assert products == DEFAULT_PRODUCT_COUNT
    assert colors >= products * 2


def test_prices_never_exceed_mrp() -> None:
    for product in build_products(200):
        assert 0 < product.price_paise <= product.mrp_paise
        assert isinstance(product.price_paise, int)
