"""Test fixtures: a temp-file SQLite DB seeded with the full deterministic catalogue.

``EYEWEAR_DATABASE_URL`` is set before importing ``db`` so the tests never touch the dev
``catalogue.db``.
"""

from __future__ import annotations

import os
import sys
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

_TEST_DB = Path(tempfile.gettempdir()) / "eyewear_test_catalogue.db"
os.environ["EYEWEAR_DATABASE_URL"] = f"sqlite:///{_TEST_DB}"

from fastapi.testclient import TestClient  # noqa: E402

from db import Base, SessionLocal, engine  # noqa: E402
from main import app  # noqa: E402
from seed import seed  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def seeded_db() -> Iterator[None]:
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client() -> Iterator[TestClient]:
    with TestClient(app) as test_client:
        yield test_client
