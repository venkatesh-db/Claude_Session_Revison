"""End-to-end tests for the catalogue API."""

from __future__ import annotations

import math
from typing import Any

import pytest
from fastapi.testclient import TestClient

from catalogue_data import PRICE_BUCKETS
from seed import DEFAULT_PRODUCT_COUNT


def _get(client: TestClient, **params: Any) -> dict[str, Any]:
    response = client.get("/api/products", params=params)
    assert response.status_code == 200, response.text
    return response.json()


def test_health(client: TestClient) -> None:
    assert client.get("/health").json() == {"status": "ok"}


def test_seeded_total(client: TestClient) -> None:
    assert _get(client)["total"] == DEFAULT_PRODUCT_COUNT


# --------------------------------------------------------------------------- pagination


def test_pages_are_disjoint_and_math_is_right(client: TestClient) -> None:
    page1 = _get(client, page=1, page_size=12, sort="price_asc")
    page2 = _get(client, page=2, page_size=12, sort="price_asc")

    assert len(page1["items"]) == 12
    assert len(page2["items"]) == 12
    ids1 = {item["id"] for item in page1["items"]}
    ids2 = {item["id"] for item in page2["items"]}
    assert ids1.isdisjoint(ids2)

    assert page1["total"] == DEFAULT_PRODUCT_COUNT
    assert page1["total_pages"] == math.ceil(DEFAULT_PRODUCT_COUNT / 12)
    assert page2["page"] == 2


@pytest.mark.parametrize("page_size", [1, 5, 12, 47, 48])
def test_total_pages_matches_ceil_division(client: TestClient, page_size: int) -> None:
    payload = _get(client, page_size=page_size)
    assert payload["total_pages"] == math.ceil(payload["total"] / page_size)


def test_last_page_partial_size(client: TestClient) -> None:
    payload = _get(client, page_size=48, page=math.ceil(DEFAULT_PRODUCT_COUNT / 48))
    expected = DEFAULT_PRODUCT_COUNT % 48 or 48
    assert len(payload["items"]) == expected


def test_out_of_range_page_returns_empty_not_500(client: TestClient) -> None:
    payload = _get(client, page=9999, page_size=12)
    assert payload["items"] == []
    assert payload["total"] == DEFAULT_PRODUCT_COUNT
    assert payload["page"] == 9999


def test_full_pagination_walk_covers_every_product_once(client: TestClient) -> None:
    seen: list[int] = []
    page = 1
    while True:
        payload = _get(client, page=page, page_size=48, sort="newest")
        if not payload["items"]:
            break
        seen.extend(item["id"] for item in payload["items"])
        page += 1
    assert len(seen) == DEFAULT_PRODUCT_COUNT
    assert len(set(seen)) == DEFAULT_PRODUCT_COUNT


# --------------------------------------------------------------------------- validation


@pytest.mark.parametrize("page_size", [0, -1, 49, 1000])
def test_page_size_out_of_bounds_is_422(client: TestClient, page_size: int) -> None:
    assert client.get("/api/products", params={"page_size": page_size}).status_code == 422


@pytest.mark.parametrize("page", [0, -3])
def test_page_below_one_is_422(client: TestClient, page: int) -> None:
    assert client.get("/api/products", params={"page": page}).status_code == 422


def test_unknown_sort_is_422(client: TestClient) -> None:
    assert client.get("/api/products", params={"sort": "cheapest"}).status_code == 422


def test_non_integer_price_is_422(client: TestClient) -> None:
    assert client.get("/api/products", params={"price_min": "1000.55"}).status_code == 422


# --------------------------------------------------------------------------- sorting


def test_sort_price_asc_is_monotonic(client: TestClient) -> None:
    prices = [i["price_paise"] for i in _get(client, sort="price_asc", page_size=48)["items"]]
    assert prices == sorted(prices)


def test_sort_price_desc_is_monotonic(client: TestClient) -> None:
    prices = [i["price_paise"] for i in _get(client, sort="price_desc", page_size=48)["items"]]
    assert prices == sorted(prices, reverse=True)


def test_sort_newest_is_descending_by_id(client: TestClient) -> None:
    # created_at increases strictly with id in the seed, so newest-first == id-descending.
    ids = [i["id"] for i in _get(client, sort="newest", page_size=48)["items"]]
    assert ids == sorted(ids, reverse=True)
    assert ids[0] == DEFAULT_PRODUCT_COUNT


def test_sort_rating_is_descending(client: TestClient) -> None:
    items = _get(client, sort="rating", page_size=48)["items"]
    keys = [(i["rating"], i["review_count"]) for i in items]
    assert keys == sorted(keys, reverse=True)


def test_sort_recommended_is_descending_by_discount(client: TestClient) -> None:
    items = _get(client, sort="recommended", page_size=48)["items"]
    discounts = [i["discount_percent"] for i in items]
    assert discounts == sorted(discounts, reverse=True)


def test_sort_holds_across_a_page_boundary(client: TestClient) -> None:
    first = _get(client, sort="price_asc", page=1, page_size=12)["items"]
    second = _get(client, sort="price_asc", page=2, page_size=12)["items"]
    assert first[-1]["price_paise"] <= second[0]["price_paise"]


# --------------------------------------------------------------------------- filtering


def test_single_facet_filter(client: TestClient) -> None:
    payload = _get(client, gender="Men", page_size=48)
    assert payload["total"] > 0
    assert {i["gender"] for i in payload["items"]} == {"Men"}


def test_multi_value_single_facet_is_ored(client: TestClient) -> None:
    men = _get(client, gender="Men")["total"]
    women = _get(client, gender="Women")["total"]
    both = _get(client, gender=["Men", "Women"])["total"]
    assert both == men + women


def test_multi_facet_is_anded(client: TestClient) -> None:
    payload = _get(client, gender="Men", frame_type="Full Rim", material="TR90", page_size=48)
    assert payload["total"] > 0
    assert payload["total"] < _get(client, gender="Men")["total"]
    for item in payload["items"]:
        assert item["gender"] == "Men"
        assert item["frame_type"] == "Full Rim"
        assert item["material"] == "TR90"


def test_color_filter_matches_any_selected_colourway(client: TestClient) -> None:
    payload = _get(client, color="#1a1a1a", page_size=48)
    assert payload["total"] > 0
    for item in payload["items"]:
        assert "#1a1a1a" in item["colors"]


def test_color_filter_counts_each_frame_once(client: TestClient) -> None:
    # A frame offering both colours must not be double-counted by the EXISTS clause.
    payload = _get(client, color=["#1a1a1a", "#8b4513"], page_size=48)
    ids = [item["id"] for item in payload["items"]]
    assert len(ids) == len(set(ids))
    assert payload["total"] <= (
        _get(client, color="#1a1a1a")["total"] + _get(client, color="#8b4513")["total"]
    )


def test_shape_and_size_filter_combination(client: TestClient) -> None:
    payload = _get(client, shape="Round", size="Medium", page_size=48)
    for item in payload["items"]:
        assert item["shape"] == "Round"
        assert item["size"] == "Medium"


def test_filter_with_no_matches_returns_empty(client: TestClient) -> None:
    payload = _get(client, brand="NoSuchBrand")
    assert payload["total"] == 0
    assert payload["items"] == []
    assert payload["total_pages"] == 0


# --------------------------------------------------------------------------- price ranges


def test_price_bounds_are_inclusive(client: TestClient) -> None:
    all_prices = sorted({i["price_paise"] for i in _get(client, page_size=48)["items"]})
    low, high = all_prices[0], all_prices[-1]

    exact = _get(client, price_min=low, price_max=low, page_size=48)
    assert exact["total"] > 0
    assert {i["price_paise"] for i in exact["items"]} == {low}

    inside = _get(client, price_min=low, price_max=high, page_size=48)
    assert inside["total"] > 0
    for item in inside["items"]:
        assert low <= item["price_paise"] <= high


def test_price_min_excludes_below_and_includes_boundary(client: TestClient) -> None:
    boundary = 199_900
    at_or_above = _get(client, price_min=boundary, page_size=48)
    below = _get(client, price_max=boundary - 1, page_size=48)
    assert at_or_above["total"] + below["total"] == _get(client)["total"]
    for item in at_or_above["items"]:
        assert item["price_paise"] >= boundary


def test_price_filter_combines_with_facets(client: TestClient) -> None:
    payload = _get(client, gender="Women", price_max=150_000, page_size=48)
    for item in payload["items"]:
        assert item["gender"] == "Women"
        assert item["price_paise"] <= 150_000


# --------------------------------------------------------------------------- discount math


@pytest.mark.parametrize(
    ("price", "mrp", "expected"),
    [
        (150_000, 200_000, 25),
        (99_900, 99_900, 0),
        (50_000, 100_000, 50),
        (66_667, 100_000, 33),  # floors, does not round up from 33.333
        (66_666, 100_000, 33),
        (1, 3, 66),  # 66.66 -> 66
        (39_960, 99_900, 60),
    ],
)
def test_discount_percent_integer_math(price: int, mrp: int, expected: int) -> None:
    from models.product import Product

    product = Product(price_paise=price, mrp_paise=mrp)
    assert product.discount_percent == expected
    assert isinstance(product.discount_percent, int)


def test_discount_percent_matches_payload_for_every_item(client: TestClient) -> None:
    for item in _get(client, page_size=48)["items"]:
        expected = (item["mrp_paise"] - item["price_paise"]) * 100 // item["mrp_paise"]
        assert item["discount_percent"] == expected


def test_money_fields_are_integers(client: TestClient) -> None:
    for item in _get(client, page_size=48)["items"]:
        assert isinstance(item["price_paise"], int)
        assert isinstance(item["mrp_paise"], int)
        assert isinstance(item["discount_percent"], int)


# --------------------------------------------------------------------------- detail route


def test_get_product_by_id(client: TestClient) -> None:
    response = client.get("/api/products/1")
    assert response.status_code == 200
    body = response.json()
    assert body["id"] == 1
    assert set(body) == {
        "id",
        "brand",
        "model_name",
        "rating",
        "review_count",
        "price_paise",
        "mrp_paise",
        "discount_percent",
        "promo_code",
        "offer_badge",
        "category_badge",
        "size",
        "shape",
        "gender",
        "frame_type",
        "material",
        "colors",
        "image_kind",
    }


def test_get_missing_product_is_404_with_lowercase_detail(client: TestClient) -> None:
    response = client.get("/api/products/999999")
    assert response.status_code == 404
    assert response.json() == {"detail": "product not found"}


# --------------------------------------------------------------------------- facets


def test_filters_shape(client: TestClient) -> None:
    response = client.get("/api/filters")
    assert response.status_code == 200
    facets = response.json()["facets"]
    keys = [facet["key"] for facet in facets]
    assert keys == [
        "price",
        "gender",
        "shape",
        "size",
        "brand",
        "color",
        "frame_type",
        "material",
        "weight",
        "collection",
        "face_shape",
        "occasion",
    ]
    for facet in facets:
        assert facet["options"], f"facet {facet['key']} has no options"
        for option in facet["options"]:
            assert option["count"] > 0


@pytest.mark.parametrize(
    "key",
    ["gender", "shape", "size", "brand", "frame_type", "material"],
)
def test_single_valued_facet_counts_sum_to_total(client: TestClient, key: str) -> None:
    facets = {f["key"]: f for f in client.get("/api/filters").json()["facets"]}
    counts = sum(option["count"] for option in facets[key]["options"])
    assert counts == DEFAULT_PRODUCT_COUNT


@pytest.mark.parametrize("key", ["gender", "shape", "brand", "frame_type", "material", "size"])
def test_facet_count_equals_filtered_total(client: TestClient, key: str) -> None:
    facets = {f["key"]: f for f in client.get("/api/filters").json()["facets"]}
    for option in facets[key]["options"]:
        payload = _get(client, **{key: option["value"]})
        assert payload["total"] == option["count"], f"{key}={option['value']}"


def test_color_facet_count_equals_filtered_total(client: TestClient) -> None:
    facets = {f["key"]: f for f in client.get("/api/filters").json()["facets"]}
    for option in facets["color"]["options"]:
        assert _get(client, color=option["value"])["total"] == option["count"]


def test_price_buckets_tile_without_gaps() -> None:
    # Regression: non-contiguous buckets silently dropped 77 products from the price facet.
    expected_low = 0
    for _value, _label, low, high in PRICE_BUCKETS:
        assert low == expected_low
        if high is None:
            return
        expected_low = high + 1
    raise AssertionError("last price bucket must be open-ended")


def test_price_facet_counts_sum_to_total_and_match_ranges(client: TestClient) -> None:
    facets = {f["key"]: f for f in client.get("/api/filters").json()["facets"]}
    options = {option["value"]: option["count"] for option in facets["price"]["options"]}
    assert sum(options.values()) == DEFAULT_PRODUCT_COUNT

    for value, _label, low, high in PRICE_BUCKETS:
        params: dict[str, Any] = {"price_min": low}
        if high is not None:
            params["price_max"] = high
        assert _get(client, **params)["total"] == options[value]
