"""Service-layer unit tests that bypass HTTP."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from sqlalchemy.orm import Session

from db import SessionLocal
from services import catalogue_service
from services.catalogue_service import (
    InvalidSortError,
    ProductNotFoundError,
    ProductQuery,
)


@pytest.fixture()
def db() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def test_invalid_sort_raises_service_error_not_http(db: Session) -> None:
    with pytest.raises(InvalidSortError):
        catalogue_service.list_products(db, ProductQuery(sort="bogus"))


def test_missing_product_raises_not_found(db: Session) -> None:
    with pytest.raises(ProductNotFoundError):
        catalogue_service.get_product(db, 10_000_000)


def test_total_pages_is_zero_when_nothing_matches(db: Session) -> None:
    page = catalogue_service.list_products(db, ProductQuery(brand=["Nope"]))
    assert page.total == 0
    assert page.total_pages == 0
    assert page.items == []


def test_build_facets_returns_twelve_facets(db: Session) -> None:
    facets = catalogue_service.build_facets(db)
    assert len(facets) == 12
