"""Catalogue routers. Query params are validated by FastAPI (422 on bad input); service-layer
exceptions are translated to HTTP errors here and nowhere else."""

from __future__ import annotations

from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from db import get_db
from schemas.product import FiltersOut, ProductListOut, ProductOut
from services import catalogue_service
from services.catalogue_service import ProductNotFoundError, ProductQuery

router = APIRouter(prefix="/api", tags=["catalogue"])

MAX_PAGE_SIZE = 48

SortMode = Literal["recommended", "price_asc", "price_desc", "newest", "rating"]


@router.get("/products", response_model=ProductListOut)
def list_products(
    db: Annotated[Session, Depends(get_db)],
    page: Annotated[int, Query(ge=1)] = 1,
    page_size: Annotated[int, Query(ge=1, le=MAX_PAGE_SIZE)] = 12,
    sort: SortMode = "recommended",
    gender: Annotated[list[str] | None, Query()] = None,
    shape: Annotated[list[str] | None, Query()] = None,
    brand: Annotated[list[str] | None, Query()] = None,
    color: Annotated[list[str] | None, Query()] = None,
    frame_type: Annotated[list[str] | None, Query()] = None,
    material: Annotated[list[str] | None, Query()] = None,
    size: Annotated[list[str] | None, Query()] = None,
    price_min: Annotated[int | None, Query(ge=0)] = None,
    price_max: Annotated[int | None, Query(ge=0)] = None,
) -> ProductListOut:
    query = ProductQuery(
        page=page,
        page_size=page_size,
        sort=sort,
        gender=gender or [],
        shape=shape or [],
        brand=brand or [],
        color=color or [],
        frame_type=frame_type or [],
        material=material or [],
        size=size or [],
        price_min=price_min,
        price_max=price_max,
    )
    result = catalogue_service.list_products(db, query)
    return ProductListOut.model_validate(result)


@router.get("/filters", response_model=FiltersOut)
def get_filters(db: Annotated[Session, Depends(get_db)]) -> FiltersOut:
    return FiltersOut.model_validate({"facets": catalogue_service.build_facets(db)})


@router.get("/products/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Annotated[Session, Depends(get_db)]) -> ProductOut:
    try:
        product = catalogue_service.get_product(db, product_id)
    except ProductNotFoundError:
        raise HTTPException(status_code=404, detail="product not found") from None
    return ProductOut.model_validate(product)
