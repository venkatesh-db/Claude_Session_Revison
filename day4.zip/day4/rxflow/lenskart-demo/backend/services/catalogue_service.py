"""Catalogue business logic: filtering, sorting, pagination and facet counting.

Services raise plain module-level exceptions; translating them to HTTP responses is the router's
job. All ORM access is direct (``db.get`` / ``db.query`` / ``select``) — there is deliberately no
repository layer.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import ColumnElement, Select, func, select
from sqlalchemy.orm import Session

from catalogue_data import (
    COLOR_LABELS,
    PRICE_BUCKETS,
    SORT_MODES,
)
from models.product import Product, ProductColor


class CatalogueError(Exception):
    """Base error for catalogue operations."""


class ProductNotFoundError(CatalogueError):
    """Raised when no product exists for the requested id."""


class InvalidSortError(CatalogueError):
    """Raised when an unsupported sort mode is requested."""


#: Facet key -> (human label, mapped ``Product`` column). ``color`` and ``price`` are special-cased
#: because they are, respectively, multi-valued and range-bucketed.
SIMPLE_FACETS: dict[str, tuple[str, Any]] = {
    "gender": ("Gender", Product.gender),
    "shape": ("Shape", Product.shape),
    "size": ("Size", Product.size),
    "brand": ("Brand", Product.brand),
    "frame_type": ("Frame Type", Product.frame_type),
    "material": ("Material", Product.material),
    "weight": ("Weight", Product.weight),
    "collection": ("Collection", Product.collection),
    "face_shape": ("Face Shape", Product.face_shape),
    "occasion": ("Occasion", Product.occasion),
}

#: Order the frontend renders the filter rail in.
FACET_ORDER: tuple[str, ...] = (
    "price",
    "gender",
    "shape",
    "size",
    "brand",
    "color",
    "frame_type",
    "material",
    "weight",
    "collection",
    "face_shape",
    "occasion",
)

#: Filter query params that map straight onto a single ``Product`` column.
_COLUMN_FILTERS: dict[str, Any] = {
    "gender": Product.gender,
    "shape": Product.shape,
    "brand": Product.brand,
    "frame_type": Product.frame_type,
    "material": Product.material,
    "size": Product.size,
}

#: ``discount_percent`` recomputed in SQL. SQLite integer division floors, matching the Python
#: property on ``Product``, so the "recommended" ordering agrees with the serialized value.
_DISCOUNT_EXPR: ColumnElement[Any] = (
    (Product.mrp_paise - Product.price_paise) * 100 / Product.mrp_paise
)


@dataclass(slots=True)
class ProductQuery:
    """Validated listing request. Multi-value facets arrive as lists and are OR-ed within a
    facet, AND-ed across facets."""

    page: int = 1
    page_size: int = 12
    sort: str = "recommended"
    gender: list[str] = field(default_factory=list)
    shape: list[str] = field(default_factory=list)
    brand: list[str] = field(default_factory=list)
    color: list[str] = field(default_factory=list)
    frame_type: list[str] = field(default_factory=list)
    material: list[str] = field(default_factory=list)
    size: list[str] = field(default_factory=list)
    price_min: int | None = None
    price_max: int | None = None


@dataclass(slots=True)
class ProductPage:
    """Service-level listing result; the router hands this straight to ``ProductListOut``."""

    items: list[Product]
    total: int
    page: int
    page_size: int
    total_pages: int


def _apply_filters(stmt: Select[Any], query: ProductQuery) -> Select[Any]:
    """AND together every active facet. Values inside one facet are OR-ed via ``IN``."""
    for name, column in _COLUMN_FILTERS.items():
        values: list[str] = getattr(query, name)
        if values:
            stmt = stmt.where(column.in_(values))

    if query.color:
        # EXISTS rather than a JOIN: a frame with two matching colourways must still count once.
        stmt = stmt.where(
            select(ProductColor.id)
            .where(
                ProductColor.product_id == Product.id,
                ProductColor.hex_code.in_(query.color),
            )
            .exists()
        )

    # Boundaries are inclusive on both ends.
    if query.price_min is not None:
        stmt = stmt.where(Product.price_paise >= query.price_min)
    if query.price_max is not None:
        stmt = stmt.where(Product.price_paise <= query.price_max)

    return stmt


def _apply_sort(stmt: Select[Any], sort: str) -> Select[Any]:
    """Attach the ORDER BY for a sort mode. Every mode ends in an ``id`` tiebreak so paging is
    stable and page 1 / page 2 can never overlap."""
    if sort == "price_asc":
        return stmt.order_by(Product.price_paise.asc(), Product.id.asc())
    if sort == "price_desc":
        return stmt.order_by(Product.price_paise.desc(), Product.id.asc())
    if sort == "newest":
        return stmt.order_by(Product.created_at.desc(), Product.id.desc())
    if sort == "rating":
        return stmt.order_by(
            Product.rating_tenths.desc(), Product.review_count.desc(), Product.id.asc()
        )
    if sort == "recommended":
        return stmt.order_by(_DISCOUNT_EXPR.desc(), Product.id.asc())
    raise InvalidSortError(f"unsupported sort mode: {sort}")


def list_products(db: Session, query: ProductQuery) -> ProductPage:
    """Return one page of the filtered, sorted catalogue.

    Issues exactly two statements against ``products``: a ``COUNT`` over the filtered set and the
    ``LIMIT``/``OFFSET`` page itself (plus one ``selectin`` load for the page's colours).
    """
    if query.sort not in SORT_MODES:
        raise InvalidSortError(f"unsupported sort mode: {query.sort}")

    count_stmt = _apply_filters(select(func.count(Product.id)), query)
    total = int(db.execute(count_stmt).scalar_one())

    total_pages = math.ceil(total / query.page_size) if total else 0

    page_stmt = _apply_sort(_apply_filters(select(Product), query), query.sort)
    page_stmt = page_stmt.limit(query.page_size).offset((query.page - 1) * query.page_size)
    items = list(db.execute(page_stmt).scalars().all())

    return ProductPage(
        items=items,
        total=total,
        page=query.page,
        page_size=query.page_size,
        total_pages=total_pages,
    )


def get_product(db: Session, product_id: int) -> Product:
    """Fetch one product or raise :class:`ProductNotFoundError`."""
    product = db.get(Product, product_id)
    if product is None:
        raise ProductNotFoundError(f"no product with id {product_id}")
    return product


def _price_facet_options(db: Session) -> list[dict[str, Any]]:
    """One COUNT per price bucket, evaluated in SQL."""
    options: list[dict[str, Any]] = []
    for value, label, low, high in PRICE_BUCKETS:
        stmt = select(func.count(Product.id)).where(Product.price_paise >= low)
        if high is not None:
            stmt = stmt.where(Product.price_paise <= high)
        count = int(db.execute(stmt).scalar_one())
        options.append({"value": value, "label": label, "count": count})
    return options


def _color_facet_options(db: Session) -> list[dict[str, Any]]:
    """Colour counts come from a GROUP BY on the child table, so a frame is counted once per
    colourway it actually offers."""
    rows = db.execute(
        select(ProductColor.hex_code, func.count(func.distinct(ProductColor.product_id)))
        .group_by(ProductColor.hex_code)
        .order_by(func.count(func.distinct(ProductColor.product_id)).desc())
    ).all()
    return [
        {"value": hex_code, "label": COLOR_LABELS.get(hex_code, hex_code), "count": int(count)}
        for hex_code, count in rows
    ]


def _simple_facet_options(db: Session, column: Any) -> list[dict[str, Any]]:
    rows = db.execute(
        select(column, func.count(Product.id)).group_by(column).order_by(column.asc())
    ).all()
    return [{"value": value, "label": value, "count": int(count)} for value, count in rows]


def build_facets(db: Session) -> list[dict[str, Any]]:
    """Compute every facet's options and counts from the database.

    Counts are catalogue-wide (not narrowed by the caller's current selection), so for any
    single-valued facet the count of an option equals the ``total`` of a listing request filtered
    to that option alone.
    """
    facets: list[dict[str, Any]] = []
    for key in FACET_ORDER:
        if key == "price":
            facets.append({"key": key, "label": "Price", "options": _price_facet_options(db)})
        elif key == "color":
            facets.append({"key": key, "label": "Color", "options": _color_facet_options(db)})
        else:
            label, column = SIMPLE_FACETS[key]
            facets.append(
                {"key": key, "label": label, "options": _simple_facet_options(db, column)}
            )
    return facets
