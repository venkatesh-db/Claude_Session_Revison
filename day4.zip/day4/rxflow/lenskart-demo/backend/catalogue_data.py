"""Static facet vocabulary shared by the seeder, the filter endpoint and validation.

Kept in one place so the seed script and the ``/api/filters`` labels can never drift apart.
"""

from __future__ import annotations

from typing import Final

GENDERS: Final[list[str]] = ["Men", "Women", "Unisex", "Kids"]

SHAPES: Final[list[str]] = [
    "Rectangle",
    "Round",
    "Square",
    "Aviator",
    "Cat Eye",
    "Wayfarer",
    "Hexagon",
    "Oval",
]

SIZES: Final[list[str]] = ["Narrow", "Medium", "Wide", "Extra Wide"]

BRANDS: Final[list[str]] = [
    "OptiView",
    "Lenskraft",
    "Vincent Chase",
    "John Jacobs",
    "Aqualens",
    "Hooper",
    "Fastrack",
    "Titan Eye",
]

FRAME_TYPES: Final[list[str]] = ["Full Rim", "Half Rim", "Rimless"]

MATERIALS: Final[list[str]] = ["TR90", "Acetate", "Metal", "Titanium", "Polycarbonate"]

WEIGHTS: Final[list[str]] = ["Light (<15g)", "Average (15-25g)", "Heavy (>25g)"]

COLLECTIONS: Final[list[str]] = ["Classic", "Air", "Blend Edit", "Signature", "Sale"]

FACE_SHAPES: Final[list[str]] = ["Oval", "Round", "Square", "Heart", "Diamond"]

OCCASIONS: Final[list[str]] = ["Everyday", "Work", "Sports", "Party", "Travel"]

COLORS: Final[list[tuple[str, str]]] = [
    ("#1a1a1a", "Black"),
    ("#8b4513", "Brown"),
    ("#1f3a93", "Blue"),
    ("#b8860b", "Gold"),
    ("#7f8c8d", "Gunmetal"),
    ("#8e0e2e", "Maroon"),
    ("#2e7d32", "Green"),
    ("#e0e0e0", "Silver"),
    ("#ff69b4", "Pink"),
    ("#f5f5dc", "Transparent"),
]

COLOR_LABELS: Final[dict[str, str]] = dict(COLORS)

CATEGORY_BADGES: Final[list[str]] = ["Classic", "Air", "Blend Edit", "Signature", "Sale"]

PROMO_CODES: Final[list[str]] = ["SINGLE", "BOGO", "FLAT50", "NEW20", "CLEAR"]

OFFER_BADGES: Final[list[str]] = [
    "Free BLU lenses",
    "Buy 1 Get 1",
    "50% off on lenses",
    "Free shipping",
    "Try at home",
]

# Frame shape -> the SVG silhouette the frontend should draw.
IMAGE_KIND_BY_SHAPE: Final[dict[str, str]] = {
    "Rectangle": "rect",
    "Round": "round",
    "Square": "square",
    "Aviator": "aviator",
    "Cat Eye": "cateye",
    "Wayfarer": "wayfarer",
    "Hexagon": "hexagon",
    "Oval": "oval",
}

# Price buckets for the "price" facet, in paise: (value, label, inclusive low, inclusive high).
# The ranges must tile [0, inf) with no gaps and no overlap, otherwise the facet counts stop
# summing to the catalogue total.
PRICE_BUCKETS: Final[list[tuple[str, str, int, int | None]]] = [
    ("0-99999", "Under ₹1,000", 0, 99_999),
    ("100000-199999", "₹1,000 - ₹1,999", 100_000, 199_999),
    ("200000-349999", "₹2,000 - ₹3,499", 200_000, 349_999),
    ("350000-599999", "₹3,500 - ₹5,999", 350_000, 599_999),
    ("600000-", "₹6,000 & above", 600_000, None),
]

SORT_MODES: Final[tuple[str, ...]] = (
    "recommended",
    "price_asc",
    "price_desc",
    "newest",
    "rating",
)
