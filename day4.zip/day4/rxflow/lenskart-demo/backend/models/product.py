"""SQLAlchemy 2.0 models for the eyewear catalogue.

Money is stored as integer paise (``*_paise``) — never floats. ``rating`` is likewise stored as an
integer number of tenths (``rating_tenths``) so nothing in the schema depends on binary floats;
the float-looking ``rating`` in the API payload is derived on read.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import ForeignKey, Index, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db import Base


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    brand: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    model_name: Mapped[str] = mapped_column(String(64), nullable=False)

    rating_tenths: Mapped[int] = mapped_column(Integer, nullable=False)
    review_count: Mapped[int] = mapped_column(Integer, nullable=False)

    price_paise: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    mrp_paise: Mapped[int] = mapped_column(Integer, nullable=False)

    promo_code: Mapped[str] = mapped_column(String(32), nullable=False)
    offer_badge: Mapped[str] = mapped_column(String(64), nullable=False)
    category_badge: Mapped[str] = mapped_column(String(32), nullable=False)

    size: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    shape: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    gender: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    frame_type: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    material: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    weight: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    collection: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    face_shape: Mapped[str] = mapped_column(String(24), nullable=False, index=True)
    occasion: Mapped[str] = mapped_column(String(24), nullable=False, index=True)

    image_kind: Mapped[str] = mapped_column(String(16), nullable=False)

    created_at: Mapped[datetime] = mapped_column(nullable=False, index=True)

    color_rows: Mapped[list[ProductColor]] = relationship(
        back_populates="product",
        cascade="all, delete-orphan",
        order_by="ProductColor.position",
        lazy="selectin",
    )

    __table_args__ = (
        # Listing requests filter on facet columns and then sort; these composites let SQLite
        # satisfy the common "one facet + price/rating sort" shape from an index.
        Index("ix_products_gender_price", "gender", "price_paise"),
        Index("ix_products_shape_price", "shape", "price_paise"),
        Index("ix_products_rating", "rating_tenths", "review_count"),
    )

    @property
    def rating(self) -> float:
        return self.rating_tenths / 10

    @property
    def colors(self) -> list[str]:
        return [row.hex_code for row in self.color_rows]

    @property
    def discount_percent(self) -> int:
        """Integer-floor discount computed from price/MRP — never stored."""
        if self.mrp_paise <= 0:
            return 0
        return (self.mrp_paise - self.price_paise) * 100 // self.mrp_paise


class ProductColor(Base):
    """One selectable colourway of a frame.

    A child table (rather than a delimited string) keeps the ``color`` facet countable with a
    plain ``GROUP BY`` and filterable with a join instead of a ``LIKE`` scan.
    """

    __tablename__ = "product_colors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_id: Mapped[int] = mapped_column(
        ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True
    )
    hex_code: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    position: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    product: Mapped[Product] = relationship(back_populates="color_rows")

    __table_args__ = (UniqueConstraint("product_id", "hex_code", name="uq_product_color"),)
