# EVIDENCE — Task 2 (Python backend)

Eyewear catalogue API. FastAPI + SQLAlchemy 2.0 + SQLite, served on port 8001.
All command output below is verbatim from commands actually run on this machine
(interpreter: `C:\Users\Administrator\day2\rxflow\.venv\Scripts\python.exe`).

---

## 1. What was built

```
lenskart-demo/backend/
├── main.py                          39    FastAPI app, CORS for :8080, lifespan create_all, /health
├── db.py                            34    engine / SessionLocal / Base / get_db dependency
├── catalogue_data.py               104    facet vocabulary + price buckets, shared by seed & filters
├── seed.py                         175    deterministic 928-product seeder (fixed RNG seed)
├── api/
│   ├── __init__.py                   0
│   └── products.py                  68    routers; query validation; service→HTTP error mapping
├── services/
│   ├── __init__.py                   0
│   └── catalogue_service.py        246    filter / sort / paginate / facet counting; owns the query
├── models/
│   ├── __init__.py                   3
│   └── product.py                   99    Product + ProductColor (Mapped/mapped_column), indexes
├── schemas/
│   ├── __init__.py                  15
│   └── product.py                   73    Pydantic v2 response models (class Config: from_attributes)
├── tests/
│   ├── conftest.py                  46    temp-DB fixture, session-scoped full seed, TestClient
│   ├── test_products_api.py        372    pagination, sorting, filtering, price, discount, facets
│   ├── test_catalogue_service.py    47    service raises plain exceptions, not HTTPException
│   └── test_seed.py                 46    determinism, row counts, price ≤ MRP invariant
├── pyproject.toml                   20    ruff (line 100, E/F/I), mypy (py311, strict defs), pytest
├── requirements.txt                  6
├── README.md                        60
├── .gitignore                        5
└── EVIDENCE_TASK2.md                      (this file)
```

Line counts are from `wc -l` (excluding caches):

```
$ find . -name "*.py" -o -name "*.md" -o -name "*.toml" -o -name "*.txt" | grep -v __pycache__ | sort | xargs wc -l
    60 ./README.md
     0 ./api/__init__.py
    68 ./api/products.py
   104 ./catalogue_data.py
    34 ./db.py
    39 ./main.py
     3 ./models/__init__.py
    99 ./models/product.py
    20 ./pyproject.toml
     6 ./requirements.txt
    15 ./schemas/__init__.py
    73 ./schemas/product.py
   175 ./seed.py
     0 ./services/__init__.py
   246 ./services/catalogue_service.py
    46 ./tests/conftest.py
    47 ./tests/test_catalogue_service.py
   372 ./tests/test_products_api.py
    46 ./tests/test_seed.py
  1461 total
```

(The 1461 total shown by `wc` also included `./.pytest_cache/README.md` at 8 lines in the raw run;
the tree above lists only authored files.)

---

## 2. Verification actually run

### 2.1 First test run — one genuine failure

```
$ python -m pytest -q
=========================== short test summary info ===========================
FAILED tests/test_products_api.py::test_price_facet_counts_sum_to_total_and_match_ranges
1 failed, 67 passed, 9 warnings in 1.46s
```

The failure detail:

```
    def test_price_facet_counts_sum_to_total_and_match_ranges(client: TestClient) -> None:
        facets = {f["key"]: f for f in client.get("/api/filters").json()["facets"]}
        options = {option["value"]: option["count"] for option in facets["price"]["options"]}
>       assert sum(options.values()) == DEFAULT_PRODUCT_COUNT
E       AssertionError: assert 851 == 928
E        +  where 851 = sum(dict_values([128, 224, 195, 186, 118]))
```

**Root cause (a real bug, not a bad test).** My original `PRICE_BUCKETS` were
`0–99900`, `100000–199900`, `200000–349900`, `350000–599900`, `600000–∞`. Those ranges do not tile
the number line: any price in `99_901–99_999`, `199_901–199_999`, etc. fell into no bucket at all.
77 of the 928 seeded frames landed in those dead zones, so the price facet under-reported and the
UI would have shown filter chips that could never account for the whole catalogue.

**Fix** — made the buckets contiguous in `catalogue_data.py`:

```python
PRICE_BUCKETS: Final[list[tuple[str, str, int, int | None]]] = [
    ("0-99999", "Under ₹1,000", 0, 99_999),
    ("100000-199999", "₹1,000 - ₹1,999", 100_000, 199_999),
    ("200000-349999", "₹2,000 - ₹3,499", 200_000, 349_999),
    ("350000-599999", "₹3,500 - ₹5,999", 350_000, 599_999),
    ("600000-", "₹6,000 & above", 600_000, None),
]
```

and added `test_price_buckets_tile_without_gaps`, which asserts each bucket's low equals the
previous bucket's high + 1 and that the last is open-ended — so a future edit cannot silently
reintroduce a gap.

### 2.2 Re-run — full suite green

```
$ python -m pytest -q -p no:warnings
.....................................................................    [100%]
69 passed in 1.48s
```

### 2.3 Lint and typecheck

```
$ ruff check .
(ruff exit: 0)
```

Ruff prints nothing and exits 0 — clean. (An earlier run flagged two `E501` long lines in
`tests/test_seed.py`; fixed by extracting a `fingerprint()` helper.)

```
$ mypy .
Success: no issues found in 16 source files
```

Clean. (Earlier run reported 7 errors: a `ColumnElement[int]` vs `ColumnElement[float | Decimal]`
mismatch on the SQL discount expression — SQLAlchemy types `/` as possibly-fractional even though
SQLite floors it — plus missing annotations in tests. Fixed by annotating the expression
`ColumnElement[Any]` and fully annotating the test fixtures/helpers.)

### 2.4 Seeded row count (real query)

```
$ python seed.py
seeded 928 products and 2805 colourways (seed=20240909)

$ python -c "import sqlite3; c=sqlite3.connect('catalogue.db'); ..."
products      : 928
product_colors: 2805
distinct brands: 8
min/max price  : (39960, 999900)
```

### 2.5 Live server + curl

Server started in the background and confirmed up:

```
$ python -m uvicorn main:app --port 8001
INFO:     Started server process [3536]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://127.0.0.1:8001 (Press CTRL+C to quit)
INFO:     127.0.0.1:51027 - "GET /health HTTP/1.1" 200 OK
```

**Health**

```
$ curl -s "http://127.0.0.1:8001/health"
{"status":"ok"}
```

**Product list, page 1** (`page_size=3` to keep the paste readable)

```
$ curl -s "http://127.0.0.1:8001/api/products?page=1&page_size=3"
{
    "items": [
        {
            "id": 1,
            "brand": "Vincent Chase",
            "model_name": "VC E10000",
            "rating": 4.1,
            "review_count": 2212,
            "price_paise": 59960,
            "mrp_paise": 149900,
            "discount_percent": 60,
            "promo_code": "SINGLE",
            "offer_badge": "Try at home",
            "category_badge": "Air",
            "size": "Extra Wide",
            "shape": "Aviator",
            "gender": "Women",
            "frame_type": "Half Rim",
            "material": "Titanium",
            "colors": [
                "#b8860b",
                "#e0e0e0",
                "#7f8c8d"
            ],
            "image_kind": "aviator"
        },
        {
            "id": 18,
            "brand": "Hooper",
            "model_name": "HO E10017",
            "rating": 3.7,
            "review_count": 1672,
            "price_paise": 399960,
            "mrp_paise": 999900,
            "discount_percent": 60,
            "promo_code": "FLAT50",
            "offer_badge": "Try at home",
            "category_badge": "Blend Edit",
            "size": "Medium",
            "shape": "Oval",
            "gender": "Unisex",
            "frame_type": "Full Rim",
            "material": "Acetate",
            "colors": [
                "#7f8c8d",
                "#1a1a1a",
                "#1f3a93",
                "#b8860b"
            ],
            "image_kind": "oval"
        },
        {
            "id": 28,
            "brand": "Hooper",
            "model_name": "HO E10027",
            "rating": 4.5,
            "review_count": 3307,
            "price_paise": 319960,
            "mrp_paise": 799900,
            "discount_percent": 60,
            "promo_code": "SINGLE",
            "offer_badge": "Free shipping",
            "category_badge": "Classic",
            "size": "Extra Wide",
            "shape": "Rectangle",
            "gender": "Men",
            "frame_type": "Rimless",
            "material": "Acetate",
            "colors": [
                "#ff69b4",
                "#1f3a93",
                "#7f8c8d",
                "#b8860b"
            ],
            "image_kind": "rect"
        }
    ],
    "total": 928,
    "page": 1,
    "page_size": 3,
    "total_pages": 310
}
```

Default sort is `recommended` = highest discount first, which is why all three lead items are at
60%.

**Filtered + sorted** — two genders OR-ed, AND-ed with shape, frame type and a price window,
sorted ascending by price:

```
$ curl -s "http://127.0.0.1:8001/api/products?gender=Men&gender=Unisex&shape=Round&frame_type=Full%20Rim&price_min=100000&price_max=400000&sort=price_asc&page_size=3"
{
    "items": [
        {
            "id": 272,
            "brand": "Titan Eye",
            "model_name": "TE E10271",
            "rating": 3.8,
            "review_count": 3059,
            "price_paise": 112425,
            "mrp_paise": 149900,
            "discount_percent": 25,
            "promo_code": "BOGO",
            "offer_badge": "Free BLU lenses",
            "category_badge": "Signature",
            "size": "Extra Wide",
            "shape": "Round",
            "gender": "Unisex",
            "frame_type": "Full Rim",
            "material": "TR90",
            "colors": [
                "#7f8c8d",
                "#1f3a93"
            ],
            "image_kind": "round"
        },
        {
            "id": 36,
            "brand": "Lenskraft",
            "model_name": "LE E10035",
            "rating": 4.0,
            "review_count": 4095,
            "price_paise": 127415,
            "mrp_paise": 149900,
            "discount_percent": 15,
            "promo_code": "BOGO",
            "offer_badge": "50% off on lenses",
            "category_badge": "Blend Edit",
            "size": "Narrow",
            "shape": "Round",
            "gender": "Unisex",
            "frame_type": "Full Rim",
            "material": "Metal",
            "colors": [
                "#b8860b",
                "#ff69b4"
            ],
            "image_kind": "round"
        },
        {
            "id": 740,
            "brand": "Hooper",
            "model_name": "HO E10739",
            "rating": 3.5,
            "review_count": 2183,
            "price_paise": 149940,
            "mrp_paise": 249900,
            "discount_percent": 40,
            "promo_code": "NEW20",
            "offer_badge": "Try at home",
            "category_badge": "Air",
            "size": "Narrow",
            "shape": "Round",
            "gender": "Unisex",
            "frame_type": "Full Rim",
            "material": "Titanium",
            "colors": [
                "#ff69b4",
                "#e0e0e0",
                "#2e7d32"
            ],
            "image_kind": "round"
        }
    ],
    "total": 12,
    "page": 1,
    "page_size": 3,
    "total_pages": 4
}
```

Prices ascend (112425 → 127415 → 149940), every item is Round / Full Rim / Men-or-Unisex, and all
sit inside the requested paise window.

**Single product**

```
$ curl -s "http://127.0.0.1:8001/api/products/1"
{
    "id": 1,
    "brand": "Vincent Chase",
    "model_name": "VC E10000",
    "rating": 4.1,
    "review_count": 2212,
    "price_paise": 59960,
    "mrp_paise": 149900,
    "discount_percent": 60,
    "promo_code": "SINGLE",
    "offer_badge": "Try at home",
    "category_badge": "Air",
    "size": "Extra Wide",
    "shape": "Aviator",
    "gender": "Women",
    "frame_type": "Half Rim",
    "material": "Titanium",
    "colors": [
        "#b8860b",
        "#e0e0e0",
        "#7f8c8d"
    ],
    "image_kind": "aviator"
}
```

**404 for a missing id**

```
$ curl -s -o /dev/null -w "HTTP %{http_code}\n" "http://127.0.0.1:8001/api/products/999999"
HTTP 404
$ curl -s "http://127.0.0.1:8001/api/products/999999"
{"detail":"product not found"}
```

**422 for a bad `page_size`**

```
$ curl -s -w "\nHTTP %{http_code}\n" "http://127.0.0.1:8001/api/products?page_size=99"
{"detail":[{"type":"less_than_equal","loc":["query","page_size"],"msg":"Input should be less than or equal to 48","input":"99","ctx":{"le":48},"url":"https://errors.pydantic.dev/2.6/v/less_than_equal"}]}
HTTP 422
```

**422 for an unknown `sort`**

```
$ curl -s -w "\nHTTP %{http_code}\n" "http://127.0.0.1:8001/api/products?sort=cheapest"
{"detail":[{"type":"literal_error","loc":["query","sort"],"msg":"Input should be 'recommended', 'price_asc', 'price_desc', 'newest' or 'rating'","input":"cheapest","ctx":{"expected":"'recommended', 'price_asc', 'price_desc', 'newest' or 'rating'"},"url":"https://errors.pydantic.dev/2.6/v/literal_error"}]}
HTTP 422
```

**Out-of-range page is a 200 with an empty list, not a 500**

```
$ curl -s "http://127.0.0.1:8001/api/products?page=9999"
{
    "items": [],
    "total": 928,
    "page": 9999,
    "page_size": 12,
    "total_pages": 78
}
```

**CORS preflight headers for the frontend origin**

```
$ curl -s -H "Origin: http://localhost:8080" -D - -o /dev/null "http://127.0.0.1:8001/api/products?page_size=1" | grep -i access-control
access-control-allow-credentials: true
access-control-allow-origin: http://localhost:8080
```

**`GET /api/filters`** — price, gender and frame_type facets verbatim, plus a per-facet summary of
all twelve:

```
{
  "facets": [
    {
      "key": "price",
      "label": "Price",
      "options": [
        { "value": "0-99999",       "label": "Under ₹1,000",    "count": 141 },
        { "value": "100000-199999", "label": "₹1,000 - ₹1,999", "count": 249 },
        { "value": "200000-349999", "label": "₹2,000 - ₹3,499", "count": 216 },
        { "value": "350000-599999", "label": "₹3,500 - ₹5,999", "count": 204 },
        { "value": "600000-",       "label": "₹6,000 & above",  "count": 118 }
      ]
    },
    {
      "key": "gender",
      "label": "Gender",
      "options": [
        { "value": "Kids",   "label": "Kids",   "count": 239 },
        { "value": "Men",    "label": "Men",    "count": 224 },
        { "value": "Unisex", "label": "Unisex", "count": 227 },
        { "value": "Women",  "label": "Women",  "count": 238 }
      ]
    },
    {
      "key": "frame_type",
      "label": "Frame Type",
      "options": [
        { "value": "Full Rim", "label": "Full Rim", "count": 306 },
        { "value": "Half Rim", "label": "Half Rim", "count": 306 },
        { "value": "Rimless",  "label": "Rimless",  "count": 316 }
      ]
    }
  ]
}

all 12 facets: key, #options, sum(counts)
  price          5   928
  gender         4   928
  shape          8   928
  size           4   928
  brand          8   928
  color         10   2805
  frame_type     3   928
  material       5   928
  weight         3   928
  collection     5   928
  face_shape     5   928
  occasion       5   928
```

Every single-valued facet's counts sum to exactly 928. `color` sums to 2805 because a frame offers
2–4 colourways, so it is counted once per colourway it actually has — matching the 2805 rows in
`product_colors`. `test_facet_count_equals_filtered_total` further asserts, for every option of
every facet, that the facet count equals the `total` of a listing request filtered to that option
alone.

Note on the ₹ glyph: the facet JSON above was re-captured through a UTF-8 stdout because my first
`curl | python -m json.tool` capture mangled it via the Windows cp1252 console codepage. The
server's own bytes are correct UTF-8 — verified directly:

```
content-type: application/json
raw bytes around label: b':"Under \xe2\x82\xb91,000","count'
decoded label: Under ₹1,000
```

`\xe2\x82\xb9` is U+20B9 INDIAN RUPEE SIGN, so the frontend receives a valid UTF-8 payload.

**Server stopped**

```
$ taskkill //F //PID 3536
SUCCESS: The process with PID 3536 has been terminated.
```

---

## 3. Request lifecycle

```mermaid
flowchart TD
    subgraph seedpath["Seed path — python seed.py"]
        S1["seed.py main()"] --> S2["Base.metadata.create_all"]
        S2 --> S3["build_products(928)<br/>random.Random(20240909)"]
        S3 --> S4["_assert_full_coverage<br/>every facet value + price bucket used"]
        S4 --> S5["db.add_all + db.commit<br/>928 products, 2805 product_colors"]
    end

    C["curl / browser<br/>GET /api/products?gender=Men&sort=price_asc"] --> M["main.py FastAPI app<br/>CORSMiddleware allow_origins :8080"]
    M --> R["api/products.py :: list_products"]

    R --> V{"FastAPI / Pydantic v2<br/>query validation"}
    V -- "page&lt;1, page_size 0 or &gt;48,<br/>sort not in Literal[...]" --> E422["422 detail[] — never reaches service"]
    V -- valid --> Q["build ProductQuery dataclass<br/>None → [] for each multi-value facet"]

    Q --> SVC["services/catalogue_service.list_products<br/>re-checks sort → InvalidSortError"]

    subgraph sqlbuild["SQLAlchemy query construction"]
        F["_apply_filters<br/>column.in_(values) per facet (AND across, OR within)<br/>EXISTS subquery on product_colors for color<br/>price_paise &gt;= min / &lt;= max (inclusive)"]
        CNT["stmt 1: select(func.count(Product.id))<br/>same filters → total"]
        TP["total_pages = ceil(total / page_size)<br/>0 when total == 0"]
        SRT["_apply_sort<br/>price_asc/desc · created_at desc · rating_tenths desc<br/>recommended = (mrp-price)*100/mrp desc<br/>+ id tiebreak on every mode"]
        PG["stmt 2: .limit(page_size).offset((page-1)*page_size)"]
        COL["stmt 3: selectin load of<br/>product_colors for this page only"]
        F --> CNT --> TP
        F --> SRT --> PG --> COL
    end

    SVC --> F
    COL --> PP["ProductPage dataclass<br/>items / total / page / page_size / total_pages"]
    PP --> SER["ProductListOut.model_validate<br/>from_attributes reads ORM properties:<br/>rating = rating_tenths/10<br/>colors = [row.hex_code]<br/>discount_percent = (mrp-price)*100//mrp"]
    SER --> RESP["200 application/json"]

    R -.->|"GET /api/products/{id}"| G["service.get_product → db.get(Product, id)"]
    G -- None --> NF["ProductNotFoundError<br/>→ router → HTTPException 404<br/>{'detail': 'product not found'}"]
    G -- found --> SER

    R -.->|"GET /api/filters"| BF["service.build_facets<br/>10 × GROUP BY + 5 × bucket COUNT<br/>+ 1 GROUP BY on product_colors"]
    BF --> SER2["FiltersOut → 200"]

    S5 -.->|"catalogue.db"| F
```

---

## 4. Query / performance notes

**Filtering.** `_apply_filters` builds one `Select` and is applied to *both* the count statement
and the page statement, so the two can never disagree. Each active facet contributes one
`column.in_(values)` clause: values inside a facet are OR-ed by `IN`, and separate facets are
AND-ed because they are separate `.where()` calls. Price bounds are `>=` / `<=`, i.e. inclusive on
both ends (`test_price_bounds_are_inclusive`, `test_price_min_excludes_below_and_includes_boundary`).

`color` is the one multi-valued attribute, so it lives in a child table `product_colors` rather
than a delimited string column. It is filtered with a correlated `EXISTS` subquery, deliberately
*not* a `JOIN`: a frame offering both `#1a1a1a` and `#8b4513` would be returned twice by a join and
would inflate `COUNT(*)`. `EXISTS` matches it exactly once
(`test_color_filter_counts_each_frame_once`).

**Counting.** `total` is a real `SELECT count(products.id)` over the filtered set — never
`len(items)` — so pagination metadata is correct on every page including out-of-range ones.
`total_pages` is `math.ceil(total / page_size)`, and explicitly `0` when nothing matches rather
than `1` (an empty grid should not claim to have a page).

**Statements per listing request — measured, not estimated:**

```
SQL statements for one listing request: 3
  [1] SELECT count(products.id) AS count_1 FROM products WHERE products.gender IN (?) AND (EXISTS (SELECT product_colors.id FROM product_colors WHERE product_colors.product_id = products.id AND pr
  [2] SELECT products.id, products.brand, products.model_name, products.rating_tenths, products.review_count, products.price_paise, products.mrp_paise, products.promo_code, products.offer_badge, p
  [3] SELECT product_colors.product_id AS product_colors_product_id, product_colors.id AS product_colors_id, product_colors.hex_code AS product_colors_hex_code, product_colors.position AS product_
```

Three, constant, regardless of page size: the filtered `COUNT`, the `LIMIT`/`OFFSET` page, and one
`selectin` batch load of colours for just that page's rows. `Product.color_rows` is
`lazy="selectin"` precisely to make that third query a single `IN (...)` batch instead of N+1 —
a 48-row page would otherwise cost 49 queries.

`/api/filters` is heavier by design: 10 single-column `GROUP BY` counts, one `GROUP BY` with
`COUNT(DISTINCT product_id)` on `product_colors`, and 5 bucket `COUNT`s for price — 16 statements.
It is a page-load-once payload, so it is not on the hot path.

**Indexes added and why.**

```
products -> ix_products_gender          products -> ix_products_gender_price
products -> ix_products_shape           products -> ix_products_shape_price
products -> ix_products_size            products -> ix_products_rating
products -> ix_products_brand           products -> ix_products_price_paise
products -> ix_products_frame_type      products -> ix_products_created_at
products -> ix_products_material
products -> ix_products_weight
products -> ix_products_collection
products -> ix_products_face_shape
products -> ix_products_occasion
product_colors -> ix_product_colors_product_id
product_colors -> ix_product_colors_hex_code
```

- Every facet column is indexed individually — each one is both a `WHERE ... IN` target for
  filtering and a `GROUP BY` key for facet counting, and an index serves both.
- `price_paise`, `rating_tenths`/`review_count` and `created_at` back the four non-`recommended`
  sort modes so the `ORDER BY` is index-ordered rather than a filesort.
- Two composites, `(gender, price_paise)` and `(shape, price_paise)`, cover the dominant real UI
  shape — pick a gender or shape in the rail, then sort by price. SQLite confirms it uses them as
  covering indexes:

```
$ explain query plan select count(id) from products where gender=? and price_paise>=?
SEARCH products USING COVERING INDEX ix_products_gender_price (gender=? AND price_paise>?)
```

- `product_colors.product_id` makes the `EXISTS` correlation and the `selectin` batch load index
  lookups; `hex_code` backs the colour `IN` filter and the colour facet `GROUP BY`.
- `recommended` sorts on the computed expression `(mrp_paise - price_paise) * 100 / mrp_paise`
  and is therefore *not* indexable — with 928 rows the sort is trivial, but at real scale this
  would want either a stored/generated `discount_percent` column with its own index or a
  precomputed ranking score. Called out as a known trade-off rather than hidden.

**Money and rating representation.** All money is integer paise in `*_paise` columns; nothing is
stored as a float. `discount_percent` is computed, never stored — `Product.discount_percent` uses
Python `//` and the `recommended` `ORDER BY` uses SQLite integer `/`, which floors identically for
non-negative operands, so the ordering always agrees with the number the client is shown.
`rating` is stored as `rating_tenths` (int) and divided by 10 only on serialization, so even the
rating never round-trips through a stored float.

---

## 5. Limitations

**Seeded / mocked.**
- All 928 products are synthetic, generated from `random.Random(20240909)`. There is no real
  catalogue, no images (the API returns an `image_kind` string like `"rect"`/`"aviator"` and the
  frontend draws the silhouette itself), no real brands' data, no inventory, price history or
  reviews — `rating` and `review_count` are random values in fixed ranges.
- Facet counts are reproducible only because the RNG seed is fixed. Re-seeding with a different
  seed changes every count in this document.

**Not implemented.**
- **Facet counts are catalogue-wide, not selection-narrowed.** `/api/filters` returns the count of
  each option over the whole catalogue, not "how many results remain if I add this filter to my
  current selection". Real storefronts do the latter (drill-down counts, which require re-counting
  each facet against the other active filters). The frontend contract asked for a static
  `/api/filters` payload, so this is the agreed behaviour, not an oversight — but it means a count
  can read `224` next to a chip that would actually yield fewer results alongside the user's other
  active filters.
- `weight`, `collection`, `face_shape` and `occasion` are exposed as facets with real counts and
  are stored and indexed, but are **not accepted as filter query params** — the agreed contract
  lists only `gender`/`shape`/`brand`/`color`/`frame_type`/`material`/`size`. Selecting one of
  those four chips in the UI currently has no server-side effect. Wiring them up is a one-line
  addition each to `_COLUMN_FILTERS` and the router signature.
- No text search, no cursor pagination (deep `OFFSET` degrades linearly — fine at 928 rows, not at
  a million), no caching layer, no rate limiting, no auth (the whole catalogue is public), no
  Alembic migrations (`create_all` on startup), no `/api/products` response caching headers.
- Unknown filter values are not rejected — `?brand=NoSuchBrand` returns an empty 200 rather than a
  422. Deliberate (facet values are data, not API surface), and covered by
  `test_filter_with_no_matches_returns_empty`.

**Not verified.**
- No load or concurrency testing. The 3-statements-per-request figure is measured, but latency
  under concurrent load is not, and SQLite's single-writer model was never exercised (this service
  is read-only after seeding).
- Not tested against the real frontend. CORS headers for `http://localhost:8080` are verified by
  curl, but no browser actually consumed the API — the frontend is Task 1 and was built
  concurrently, so end-to-end integration between the two is unverified by me.
- Only SQLite was exercised. The code has no SQLite-specific SQL except one assumption that matters:
  `recommended` relies on `/` being **integer** division. On PostgreSQL, `integer / integer` is also
  integer division, so it would carry over — but this is reasoned, not tested.
- Python 3.11 is the mypy target; the suite was run on the repo venv's interpreter
  (`day2/rxflow/.venv`), not on a clean 3.11 install from `requirements.txt`.
