"""Pydantic v2 response schemas for the catalogue API."""

from __future__ import annotations

from pydantic import BaseModel


class ProductOut(BaseModel):
    """A single catalogue card.

    ``rating``, ``colors`` and ``discount_percent`` are read off ``Product`` properties, so
    ``discount_percent`` is always the integer-derived value and never a stored column.
    """

    id: int
    brand: str
    model_name: str
    rating: float
    review_count: int
    price_paise: int
    mrp_paise: int
    discount_percent: int
    promo_code: str
    offer_badge: str
    category_badge: str
    size: str
    shape: str
    gender: str
    frame_type: str
    material: str
    colors: list[str]
    image_kind: str

    class Config:
        from_attributes = True
        # "model_name" is a real catalogue field, not a Pydantic-reserved one.
        protected_namespaces = ()


class ProductListOut(BaseModel):
    items: list[ProductOut]
    total: int
    page: int
    page_size: int
    total_pages: int

    class Config:
        from_attributes = True


class FacetOptionOut(BaseModel):
    value: str
    label: str
    count: int

    class Config:
        from_attributes = True


class FacetOut(BaseModel):
    key: str
    label: str
    options: list[FacetOptionOut]

    class Config:
        from_attributes = True


class FiltersOut(BaseModel):
    facets: list[FacetOut]

    class Config:
        from_attributes = True
