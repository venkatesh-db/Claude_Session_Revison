/* app.js — OptiView PLP. Vanilla JS, no framework, no build step.
 *
 * Flip USE_MOCK to false to talk to the real backend at API_BASE.
 * When true (or when a fetch fails) everything runs off MOCK_PRODUCTS and
 * filtering / sorting / paging happen client-side.
 */
'use strict';

var USE_MOCK = true;                        // <-- set false once the backend is up
var API_BASE = 'http://localhost:8001';
var PAGE_SIZE = 12;

/* ------------------------------------------------------------------ state */

var state = {
  page: 1,
  page_size: PAGE_SIZE,
  sort: 'recommended',
  price_min: 0,          // rupees, inclusive
  price_max: 5000,
  selected: {            // facet key -> array of selected values
    gender: [], shape: [], size: [], brand: [], color: [],
    frame_type: [], material: [], weight: [], collection: [],
    face_shape: [], occasion: []
  },
  wishlist: loadWishlist(),
  activeColor: {},       // product id -> swatch index
  items: [],
  total: 0,
  total_pages: 1,
  source: 'mock'
};

/* Facet definitions. Rendered into the sidebar; `derive` maps a product to
   the value(s) it matches for that facet, so the same list drives both the
   UI and the client-side filter. */
var FACETS = [
  { key: 'gender',     label: 'Gender',          type: 'check',  options: ['Men', 'Women', 'Unisex', 'Kids'] },
  { key: 'shape',      label: 'Shape & Style',   type: 'check',  options: ['Rectangle', 'Round', 'Square', 'Cat Eye', 'Aviator', 'Wayfarer', 'Hexagon'] },
  { key: 'size',       label: 'Frame Size',      type: 'check',  options: ['Small', 'Medium', 'Large'] },
  { key: 'brand',      label: 'Brand',           type: 'check',  options: ['OptiView', 'Northline', 'Aureli', 'Cobalt Co.', 'Verda', 'Mirador'] },
  { key: 'color',      label: 'Frame Colour',    type: 'swatch', options: [
      { value: 'Black', hex: '#1a1a1a' }, { value: 'Brown', hex: '#7a5c3a' },
      { value: 'Grey',  hex: '#8c8c8c' }, { value: 'Gold',  hex: '#c9a227' },
      { value: 'Blue',  hex: '#2b3a55' }, { value: 'Green', hex: '#26402c' },
      { value: 'Red',   hex: '#8e2b45' }, { value: 'Beige', hex: '#d7b9a0' } ] },
  { key: 'frame_type', label: 'Frame Type',      type: 'check',  options: ['Full Rim', 'Half Rim', 'Rimless'] },
  { key: 'material',   label: 'Material',        type: 'check',  options: ['TR90', 'Acetate', 'Metal', 'Titanium', 'Plastic'] },
  { key: 'weight',     label: 'Weight',          type: 'check',  options: ['Light', 'Average'], derive: deriveWeight },
  { key: 'collection', label: 'Collection',      type: 'check',  options: ['Air', 'Blend Edit', 'Everyday', 'Signature'], derive: deriveCollection },
  { key: 'face_shape', label: 'Face Shape',      type: 'check',  options: ['Oval', 'Round', 'Square', 'Heart'], derive: deriveFaceShape },
  { key: 'occasion',   label: 'Occasion',        type: 'check',  options: ['Everyday', 'Work', 'Sport', 'Party'], derive: deriveOccasion }
];

/* Derived attributes: deterministic from the product so results are stable. */
function deriveWeight(p) { return p.material === 'Titanium' || p.material === 'TR90' ? ['Light'] : ['Average']; }
function deriveCollection(p) {
  if (p.frame_type === 'Rimless') return ['Air'];
  if (p.category_badge === 'Premium') return ['Signature'];
  if (p.category_badge === 'On Sale') return ['Everyday'];
  return ['Blend Edit'];
}
function deriveFaceShape(p) {
  var m = { Rectangle: 'Round', Square: 'Round', Round: 'Square', Hexagon: 'Square', 'Cat Eye': 'Heart', Aviator: 'Oval', Wayfarer: 'Oval' };
  return [m[p.shape] || 'Oval'];
}
function deriveOccasion(p) {
  if (p.material === 'TR90') return ['Sport', 'Everyday'];
  if (p.category_badge === 'Premium') return ['Work', 'Party'];
  return ['Everyday', 'Work'];
}

/* Colour-name buckets so the swatch filter can match raw hex values. */
var COLOR_BUCKETS = {
  Black: ['#1a1a1a', '#101010', '#111111', '#000000', '#1b1b1b', '#222222'],
  Brown: ['#8b4513', '#7a5c3a', '#553311', '#3b2f2f', '#946b2d', '#b08d57'],
  Grey:  ['#4a4a4a', '#5c5c5c', '#8c8c8c', '#9a9a9a', '#404040', '#2b2b2b'],
  Gold:  ['#c0a060', '#c9a227', '#b08d57', '#946b2d'],
  Blue:  ['#2b3a55', '#0b3d5c', '#123c5e', '#3b7dd8', '#2f6f7f'],
  Green: ['#1f4d3f', '#26402c'],
  Red:   ['#8e2b45', '#e05a4f', '#6a2c2c'],
  Beige: ['#d7b9a0', '#d0a5a5']
};

/* ------------------------------------------------------------- formatting */

/** Integer paise -> "₹1,500". Integer arithmetic only, never floats. */
function formatPaise(paise) {
  var rupees = Math.round(paise / 100);        // paise are whole; no float math on the value
  return '₹' + String(rupees).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
function rupeesOf(paise) { return Math.round(paise / 100); }
function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

/* --------------------------------------------------------------- wishlist */

function loadWishlist() {
  try {
    var raw = window.localStorage.getItem('optiview.wishlist');
    return raw ? JSON.parse(raw) : [];
  } catch (e) { return []; }
}
function saveWishlist() {
  try { window.localStorage.setItem('optiview.wishlist', JSON.stringify(state.wishlist)); } catch (e) { /* private mode */ }
}
function toggleWishlist(id) {
  var i = state.wishlist.indexOf(id);
  if (i === -1) state.wishlist.push(id); else state.wishlist.splice(i, 1);
  saveWishlist();
  renderWishlistCount();
}
function renderWishlistCount() {
  var el = document.getElementById('wishlist-count');
  el.textContent = String(state.wishlist.length);
  el.setAttribute('aria-label', state.wishlist.length + ' items in wishlist');
}

/* ------------------------------------------------------------ frame art */

/** Inline SVG placeholder frames — nothing is loaded over the network. */
function frameSvg(kind, hex) {
  var c = hex || '#1a1a1a';
  var lens = 'rgba(120,150,170,.28)';
  var parts = {
    rect:     '<rect x="18" y="26" width="70" height="42" rx="8"/><rect x="132" y="26" width="70" height="42" rx="8"/>',
    round:    '<circle cx="53" cy="47" r="26"/><circle cx="167" cy="47" r="26"/>',
    square:   '<rect x="20" y="24" width="66" height="46" rx="4"/><rect x="134" y="24" width="66" height="46" rx="4"/>',
    cateye:   '<path d="M18 34c14-14 56-16 70-2 4 22-16 34-38 32C28 62 14 46 18 34z"/><path d="M202 34c-14-14-56-16-70-2-4 22 16 34 38 32 22-2 36-18 32-30z"/>',
    aviator:  '<path d="M20 28h68l-10 40c-2 8-38 10-46 0z"/><path d="M132 28h68l-12 40c-8 10-44 8-46 0z"/>',
    wayfarer: '<path d="M18 28h72l-6 38c-2 8-56 8-60 0z"/><path d="M130 28h72l-6 38c-4 8-58 8-60 0z"/>',
    hexagon:  '<path d="M36 26h34l16 21-16 21H36L20 47z"/><path d="M150 26h34l16 21-16 21h-34l-16-21z"/>'
  };
  var shape = parts[kind] || parts.rect;
  return '<svg viewBox="0 0 220 94" role="img" aria-label="Illustration of a ' +
    esc(kind) + ' eyeglass frame" focusable="false">' +
    '<g fill="' + lens + '" stroke="' + esc(c) + '" stroke-width="5" stroke-linejoin="round">' + shape + '</g>' +
    '<g stroke="' + esc(c) + '" stroke-width="5" stroke-linecap="round" fill="none">' +
    '<path d="M88 42h44"/><path d="M14 30 2 20"/><path d="M206 30l12-10"/></g></svg>';
}

/* ------------------------------------------------------ sidebar rendering */

function renderFacets() {
  var host = document.getElementById('facet-list');
  var html = '';
  FACETS.forEach(function (f, idx) {
    var open = idx < 4;                     // first few open, like the real PLP
    var bodyId = 'facet-' + f.key;
    var n = state.selected[f.key].length;
    html += '<section class="facet" data-facet="' + f.key + '">' +
      '<h3><button type="button" class="facet-btn" aria-expanded="' + open + '" aria-controls="' + bodyId + '">' +
      '<span>' + esc(f.label) + '</span>' +
      (n ? '<span class="facet-tag">' + n + '</span>' : '') +
      '<span class="chev" aria-hidden="true"></span></button></h3>' +
      '<div class="facet-body" id="' + bodyId + '">';

    if (f.type === 'swatch') {
      html += '<fieldset class="swatches" style="border:0;margin:0;padding:0">' +
        '<legend class="visually-hidden">' + esc(f.label) + '</legend>';
      f.options.forEach(function (o) {
        var on = state.selected[f.key].indexOf(o.value) !== -1;
        html += '<label class="swatch" title="' + esc(o.value) + '">' +
          '<input type="checkbox" data-facet="' + f.key + '" value="' + esc(o.value) + '"' + (on ? ' checked' : '') + ' />' +
          '<span class="dot" style="background:' + esc(o.hex) + '"></span>' +
          '<span class="visually-hidden">' + esc(o.value) + '</span></label>';
      });
      html += '</fieldset>';
    } else {
      html += '<fieldset style="border:0;margin:0;padding:0">' +
        '<legend class="visually-hidden">' + esc(f.label) + '</legend>';
      f.options.forEach(function (v) {
        var on = state.selected[f.key].indexOf(v) !== -1;
        html += '<label class="opt"><input type="checkbox" data-facet="' + f.key + '" value="' + esc(v) + '"' +
          (on ? ' checked' : '') + ' /><span>' + esc(v) + '</span>' +
          '<span class="cnt">(' + countFor(f, v) + ')</span></label>';
      });
      html += '</fieldset>';
    }
    html += '</div></section>';
  });
  host.innerHTML = html;
}

/** Facet counts over the whole (mock) catalogue — indicative, not cross-filtered. */
function countFor(f, value) {
  var all = window.MOCK_PRODUCTS || [];
  var n = 0;
  for (var i = 0; i < all.length; i++) if (matchesFacet(all[i], f.key, [value])) n++;
  return n;
}

function renderChips() {
  var host = document.getElementById('active-chips');
  var html = '';
  FACETS.forEach(function (f) {
    state.selected[f.key].forEach(function (v) {
      html += '<span class="chip">' + esc(f.label) + ': ' + esc(v) +
        ' <button type="button" data-chip-facet="' + f.key + '" data-chip-value="' + esc(v) +
        '" aria-label="Remove filter ' + esc(f.label) + ' ' + esc(v) + '">&times;</button></span>';
    });
  });
  if (state.price_min > 0 || state.price_max < 5000) {
    html += '<span class="chip">Price: ₹' + state.price_min + '–₹' + state.price_max +
      ' <button type="button" data-chip-facet="__price" data-chip-value="reset" aria-label="Reset price filter">&times;</button></span>';
  }
  host.innerHTML = html;
}

/* ---------------------------------------------------- filtering / sorting */

function valuesFor(p, key) {
  var f = null;
  for (var i = 0; i < FACETS.length; i++) if (FACETS[i].key === key) f = FACETS[i];
  if (f && f.derive) return f.derive(p);
  if (key === 'color') {
    var names = [];
    (p.colors || []).forEach(function (hex) {
      Object.keys(COLOR_BUCKETS).forEach(function (name) {
        if (COLOR_BUCKETS[name].indexOf(String(hex).toLowerCase()) !== -1 && names.indexOf(name) === -1) names.push(name);
      });
    });
    return names;
  }
  return [p[key]];
}

function matchesFacet(p, key, wanted) {
  if (!wanted.length) return true;
  var have = valuesFor(p, key);
  for (var i = 0; i < wanted.length; i++) if (have.indexOf(wanted[i]) !== -1) return true;
  return false;
}

function applyFilters(list) {
  return list.filter(function (p) {
    var r = rupeesOf(p.price_paise);
    if (r < state.price_min || r > state.price_max) return false;
    for (var i = 0; i < FACETS.length; i++) {
      var k = FACETS[i].key;
      if (!matchesFacet(p, k, state.selected[k])) return false;
    }
    return true;
  });
}

function applySort(list) {
  var out = list.slice();
  switch (state.sort) {
    case 'price_asc':  out.sort(function (a, b) { return a.price_paise - b.price_paise; }); break;
    case 'price_desc': out.sort(function (a, b) { return b.price_paise - a.price_paise; }); break;
    case 'newest':     out.sort(function (a, b) { return b.id - a.id; }); break;
    case 'rating':     out.sort(function (a, b) { return (b.rating - a.rating) || (b.review_count - a.review_count); }); break;
    default:           out.sort(function (a, b) {
                         return (b.rating * Math.log(1 + b.review_count)) - (a.rating * Math.log(1 + a.review_count));
                       });
  }
  return out;
}

/* ------------------------------------------------------------ data access */

function buildQuery() {
  var q = new URLSearchParams();
  q.set('page', state.page);
  q.set('page_size', state.page_size);
  q.set('sort', state.sort);
  ['gender', 'shape', 'brand', 'color', 'frame_type', 'material', 'size'].forEach(function (k) {
    q.set(k, state.selected[k].join(','));
  });
  q.set('price_min', state.price_min * 100);   // API speaks paise
  q.set('price_max', state.price_max * 100);
  return q.toString();
}

function loadPage() {
  var grid = document.getElementById('grid');
  grid.setAttribute('aria-busy', 'true');

  if (USE_MOCK) { useMock(); return Promise.resolve(); }

  return fetch(API_BASE + '/api/products?' + buildQuery(), { headers: { Accept: 'application/json' } })
    .then(function (res) { if (!res.ok) throw new Error('HTTP ' + res.status); return res.json(); })
    .then(function (data) {
      state.items = data.items || [];
      state.total = data.total || 0;
      state.total_pages = data.total_pages || 1;
      state.source = 'api';
      render();
    })
    .catch(function (err) {
      if (window.console) console.warn('[OptiView] API unavailable, using mock data:', err.message);
      useMock();
    });
}

function useMock() {
  var all = applySort(applyFilters(window.MOCK_PRODUCTS || []));
  state.total = all.length;
  state.total_pages = Math.max(1, Math.ceil(all.length / state.page_size));
  if (state.page > state.total_pages) state.page = state.total_pages;
  var start = (state.page - 1) * state.page_size;
  state.items = all.slice(start, start + state.page_size);
  state.source = 'mock';
  render();
}

/* ------------------------------------------------------------- rendering */

function cardHtml(p) {
  var colors = p.colors || ['#1a1a1a'];
  var active = state.activeColor[p.id] || 0;
  var wished = state.wishlist.indexOf(p.id) !== -1;

  var swatches = colors.map(function (hex, i) {
    return '<button type="button" class="card-swatch" data-swatch-id="' + p.id + '" data-swatch-i="' + i +
      '" style="background:' + esc(hex) + '" aria-pressed="' + (i === active) + '"' +
      ' aria-label="Colour option ' + (i + 1) + ' of ' + colors.length + ' for ' + esc(p.model_name) + '"></button>';
  }).join('');

  return '<article class="product-card" data-id="' + p.id + '">' +
    '<div class="card-top">' +
      '<span class="cat-badge" data-badge="' + esc(p.category_badge) + '">' + esc(p.category_badge) + '</span>' +
      '<button type="button" class="wish" data-wish="' + p.id + '" aria-pressed="' + wished + '"' +
        ' aria-label="' + (wished ? 'Remove' : 'Add') + ' ' + esc(p.brand + ' ' + p.model_name) + ' ' +
        (wished ? 'from' : 'to') + ' wishlist">' + (wished ? '♥' : '♡') + '</button>' +
    '</div>' +
    '<p class="rating-pill">' + esc(p.rating.toFixed ? p.rating.toFixed(1) : p.rating) +
      ' <span class="star" aria-hidden="true">★</span>' +
      '<span class="visually-hidden">out of 5</span> <span class="rc">(' + esc(p.review_count) + ')</span></p>' +
    '<div class="frame-art">' + frameSvg(p.image_kind, colors[active]) + '</div>' +
    '<div class="card-swatches" role="group" aria-label="Colour options">' + swatches + '</div>' +
    '<h3 class="brand">' + esc(p.brand) + '</h3>' +
    '<p class="model">' + esc(p.model_name) + ' &middot; ' + esc(p.shape) + ' &middot; ' + esc(p.frame_type) + '</p>' +
    '<p class="price-line">' +
      '<span class="price">' + formatPaise(p.price_paise) + '</span>' +
      '<span class="mrp"><span class="visually-hidden">M.R.P. </span>' + formatPaise(p.mrp_paise) + '</span>' +
      '<span class="off">' + esc(p.discount_percent) + '% OFF</span></p>' +
    (p.promo_code ? '<p class="promo">Use code <code>' + esc(p.promo_code) + '</code> for this price</p>' : '') +
    (p.offer_badge ? '<p class="offer">' + esc(p.offer_badge) + '</p>' : '') +
    '<p class="size-line">Size: ' + esc(p.size) + ' &middot; ' + esc(p.material) + '</p>' +
    '<div class="card-actions">' +
      '<button type="button" class="try">3D Try</button>' +
      '<button type="button" class="similar">View Similar</button>' +
    '</div>' +
  '</article>';
}

function renderGrid() {
  var grid = document.getElementById('grid');
  grid.innerHTML = state.items.map(cardHtml).join('');
  grid.setAttribute('aria-busy', 'false');
  document.getElementById('empty').hidden = state.items.length > 0;
}

function renderPagination() {
  var host = document.getElementById('pagination');
  var tp = state.total_pages, cur = state.page;
  if (tp <= 1) { host.innerHTML = ''; return; }

  var pages = [], i;
  for (i = 1; i <= tp; i++) {
    if (i === 1 || i === tp || Math.abs(i - cur) <= 1) pages.push(i);
    else if (pages[pages.length - 1] !== '…') pages.push('…');
  }

  var html = '<button type="button" data-page="' + (cur - 1) + '"' + (cur === 1 ? ' disabled' : '') +
    ' aria-label="Previous page">&lsaquo; Prev</button>';
  pages.forEach(function (p) {
    if (p === '…') { html += '<span class="gap" aria-hidden="true">…</span>'; return; }
    html += '<button type="button" data-page="' + p + '"' + (p === cur ? ' aria-current="page"' : '') +
      ' aria-label="Page ' + p + '">' + p + '</button>';
  });
  html += '<button type="button" data-page="' + (cur + 1) + '"' + (cur === tp ? ' disabled' : '') +
    ' aria-label="Next page">Next &rsaquo;</button>';
  host.innerHTML = html;
}

function render() {
  document.getElementById('item-count').textContent = String(state.total);
  renderChips();
  renderGrid();
  renderPagination();
  renderWishlistCount();
}

/* --------------------------------------------------------------- wiring */

function onFacetChange(e) {
  var input = e.target.closest('input[type=checkbox][data-facet]');
  if (!input) return;
  var key = input.getAttribute('data-facet');
  var val = input.value;
  var arr = state.selected[key];
  var i = arr.indexOf(val);
  if (input.checked && i === -1) arr.push(val);
  if (!input.checked && i !== -1) arr.splice(i, 1);
  state.page = 1;
  renderFacetTag(key);
  loadPage();
}

function renderFacetTag(key) {
  var sec = document.querySelector('.facet[data-facet="' + key + '"] .facet-btn');
  if (!sec) return;
  var tag = sec.querySelector('.facet-tag');
  var n = state.selected[key].length;
  if (n && !tag) {
    tag = document.createElement('span');
    tag.className = 'facet-tag';
    sec.insertBefore(tag, sec.querySelector('.chev'));
  }
  if (tag) { tag.textContent = n ? String(n) : ''; if (!n) tag.remove(); }
}

function wire() {
  // collapsible filter sections (event delegation, works for re-rendered HTML)
  document.querySelector('.sidebar').addEventListener('click', function (e) {
    var btn = e.target.closest('.facet-btn');
    if (!btn) return;
    var open = btn.getAttribute('aria-expanded') === 'true';
    btn.setAttribute('aria-expanded', String(!open));
  });

  document.querySelector('.sidebar').addEventListener('change', onFacetChange);

  // price inputs + range
  var pmin = document.getElementById('price-min');
  var pmax = document.getElementById('price-max');
  var range = document.getElementById('price-range');
  var out = document.getElementById('price-out');

  function syncPrice() {
    state.price_min = Math.max(0, parseInt(pmin.value, 10) || 0);
    state.price_max = Math.max(state.price_min, parseInt(pmax.value, 10) || 5000);
    out.textContent = '₹' + String(state.price_max).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    state.page = 1;
    loadPage();
  }
  pmin.addEventListener('change', syncPrice);
  pmax.addEventListener('change', syncPrice);
  range.addEventListener('input', function () { out.textContent = '₹' + range.value.replace(/\B(?=(\d{3})+(?!\d))/g, ','); });
  range.addEventListener('change', function () { pmax.value = range.value; syncPrice(); });

  document.getElementById('sort').addEventListener('change', function (e) {
    state.sort = e.target.value;
    state.page = 1;
    loadPage();
  });

  document.getElementById('clear-all').addEventListener('click', function () {
    Object.keys(state.selected).forEach(function (k) { state.selected[k] = []; });
    state.price_min = 0; state.price_max = 5000; state.page = 1;
    pmin.value = 0; pmax.value = 5000; range.value = 5000; out.textContent = '₹5,000';
    renderFacets();
    loadPage();
  });

  document.getElementById('active-chips').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-chip-facet]');
    if (!btn) return;
    var key = btn.getAttribute('data-chip-facet');
    if (key === '__price') {
      state.price_min = 0; state.price_max = 5000;
      pmin.value = 0; pmax.value = 5000; range.value = 5000; out.textContent = '₹5,000';
    } else {
      var v = btn.getAttribute('data-chip-value');
      var arr = state.selected[key];
      var i = arr.indexOf(v);
      if (i !== -1) arr.splice(i, 1);
      renderFacets();
    }
    state.page = 1;
    loadPage();
  });

  document.getElementById('grid').addEventListener('click', function (e) {
    var wish = e.target.closest('[data-wish]');
    if (wish) {
      var id = parseInt(wish.getAttribute('data-wish'), 10);
      toggleWishlist(id);
      var on = state.wishlist.indexOf(id) !== -1;
      wish.setAttribute('aria-pressed', String(on));
      wish.textContent = on ? '♥' : '♡';
      return;
    }
    var sw = e.target.closest('[data-swatch-id]');
    if (sw) {
      var pid = parseInt(sw.getAttribute('data-swatch-id'), 10);
      state.activeColor[pid] = parseInt(sw.getAttribute('data-swatch-i'), 10);
      renderGrid();
      return;
    }
  });

  document.getElementById('pagination').addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-page]');
    if (!btn || btn.disabled) return;
    var p = parseInt(btn.getAttribute('data-page'), 10);
    if (p < 1 || p > state.total_pages) return;
    state.page = p;
    loadPage();
    document.getElementById('results').scrollIntoView({ block: 'start' });
  });

  // mobile filter drawer toggle
  var toggle = document.getElementById('filter-toggle');
  var sidebar = document.getElementById('filters');
  function applyViewport() {
    var small = window.matchMedia('(max-width: 899px)').matches;
    sidebar.hidden = small && toggle.getAttribute('aria-expanded') !== 'true';
  }
  toggle.addEventListener('click', function () {
    var open = toggle.getAttribute('aria-expanded') === 'true';
    toggle.setAttribute('aria-expanded', String(!open));
    applyViewport();
  });
  window.addEventListener('resize', applyViewport);
  applyViewport();
}

function init() {
  renderFacets();
  wire();
  loadPage();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();
