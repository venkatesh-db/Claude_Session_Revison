"""Contract checks on mock-products.js + the card template in app.js."""
import json
import re
import sys

src = open("mock-products.js", encoding="utf-8").read()
arr = src[src.index("["): src.rindex("]") + 1]
arr = re.sub(r'(?m)^\s*/\*.*?\*/\s*', '', arr)
arr = re.sub(r'([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:', r'\1"\2":', arr)
items = json.loads(arr)

REQUIRED = ["id", "brand", "model_name", "rating", "review_count", "price_paise",
            "mrp_paise", "discount_percent", "promo_code", "offer_badge",
            "category_badge", "size", "shape", "gender", "frame_type",
            "material", "colors", "image_kind"]

fails = []
print("mock product count   :", len(items))
if len(items) < 24:
    fails.append("fewer than 24 mock products")

for it in items:
    missing = [k for k in REQUIRED if k not in it]
    if missing:
        fails.append("id=%s missing %s" % (it.get("id"), missing))
    for k in ("price_paise", "mrp_paise", "discount_percent", "review_count", "id"):
        if k in it and not isinstance(it[k], int):
            fails.append("id=%s %s is not an integer (%r)" % (it["id"], k, it[k]))
    if it["price_paise"] >= it["mrp_paise"]:
        fails.append("id=%s price >= mrp" % it["id"])

ids = [i["id"] for i in items]
print("unique ids           :", len(set(ids)) == len(ids))
print("all money integral   :", all(isinstance(i["price_paise"], int) for i in items))
print("badges present       :", sorted({i["category_badge"] for i in items}))
print("image_kinds          :", sorted({i["image_kind"] for i in items}))
print("price range (rupees) :", min(i["price_paise"] for i in items) // 100,
      "-", max(i["price_paise"] for i in items) // 100)

app = open("app.js", encoding="utf-8").read()
TOKENS = {
    "card root":        'class="product-card"',
    "category badge":   'class="cat-badge"',
    "rating pill":      'class="rating-pill"',
    "colour swatches":  'class="card-swatch"',
    "price":            'class="price"',
    "struck MRP":       'class="mrp"',
    "percent off":      "% OFF",
    "promo line":       "for this price",
    "offer badge":      'class="offer"',
    "size indicator":   'class="size-line"',
    "3D Try action":    ">3D Try<",
    "View Similar":     ">View Similar<",
    "wishlist toggle":  'class="wish"',
    "aria-pressed":     'aria-pressed="',
    "pagination":       "data-page=",
    "no float on money": "Math.round(paise / 100)",
}
print()
for name, tok in TOKENS.items():
    ok = tok in app
    print("%-20s %s" % (name, "present" if ok else "MISSING"))
    if not ok:
        fails.append("template missing " + name)

print()
if fails:
    print("FAIL:", fails)
    sys.exit(1)
print("ALL DATA/TEMPLATE CHECKS PASSED")
