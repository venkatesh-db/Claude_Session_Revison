"""Structural checks on index.html (stdlib html.parser only)."""
import re
import sys
from html.parser import HTMLParser

SRC = open("index.html", encoding="utf-8").read()


class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.decl = None
        self.h1 = 0
        self.landmarks = []
        self.bad_media = []
        self.controls_missing = []
        self.expandable = []
        self.tags = {}

    def handle_decl(self, decl):
        self.decl = decl

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        self.tags[tag] = self.tags.get(tag, 0) + 1
        if tag == "h1":
            self.h1 += 1
        if tag in ("header", "main", "nav", "aside", "footer"):
            self.landmarks.append((tag, a.get("aria-label") or a.get("role") or ""))
        if tag == "img" and not a.get("alt"):
            self.bad_media.append(("img", a))
        if tag == "svg":
            if not (a.get("aria-hidden") or a.get("aria-label") or a.get("role") == "img"):
                self.bad_media.append(("svg", a))
        if tag == "button" and "aria-expanded" in a:
            self.expandable.append((a.get("aria-expanded"), a.get("aria-controls")))
        if tag == "input" and a.get("type") in ("number", "range"):
            if not (a.get("id") and re.search(r'for="%s"' % a["id"], SRC)):
                if "<label" not in SRC[max(0, SRC.find(a.get("id", "zz")) - 200):]:
                    self.controls_missing.append(a.get("id"))


p = P()
p.feed(SRC)

fails = []
print("doctype              :", p.decl)
if (p.decl or "").lower() != "doctype html":
    fails.append("doctype")

print("<h1> count           :", p.h1)
if p.h1 != 1:
    fails.append("h1 count != 1")

print("landmarks            :", p.landmarks)
for req in ("header", "main", "aside", "footer"):
    if req not in [t for t, _ in p.landmarks]:
        fails.append("missing landmark " + req)

print("img/svg missing text :", p.bad_media or "none")
if p.bad_media:
    fails.append("media without alt/aria text")

print("aria-expanded buttons:", p.expandable)
for exp, ctl in p.expandable:
    if exp not in ("true", "false") or not ctl or ('id="%s"' % ctl) not in SRC:
        fails.append("bad aria-expanded/controls: %r %r" % (exp, ctl))

print("labelled price inputs:", "ok" if not p.controls_missing else p.controls_missing)
if p.controls_missing:
    fails.append("unlabelled inputs")

print("select#sort labelled :", 'for="sort"' in SRC and 'id="sort"' in SRC)
if not ('for="sort"' in SRC and 'id="sort"' in SRC):
    fails.append("sort select unlabelled")

print("lang attribute       :", re.search(r'<html[^>]*lang="([^"]+)"', SRC).group(1))
print("skip link            :", 'class="skip-link"' in SRC)
print("script tags          :", re.findall(r'<script src="([^"]+)"', SRC))
print("tag histogram        :", dict(sorted(p.tags.items())))

print()
if fails:
    print("FAIL:", fails)
    sys.exit(1)
print("ALL STRUCTURAL CHECKS PASSED")
