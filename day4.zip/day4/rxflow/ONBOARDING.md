# RxFlow — New Engineer Onboarding

## What is RxFlow?

RxFlow is an order-management backend built with **FastAPI + SQLAlchemy + Celery**. A customer
registers, browses products, places an order against tracked inventory, pays through a payment
gateway, and gets an order-confirmation email sent asynchronously. This is currently a **lab/teaching
codebase** — the payment gateway, shipping carrier, tax service, and email provider are all mocked
HTTP clients hitting fake `*.internal` URLs. The retry/timeout/error-handling code around them is
real and production-shaped; only the actual network responses are stubbed.

## Getting set up

```bash
make install          # pip install -r requirements.txt
docker-compose up     # starts Postgres (rxflow/rxflow) + Redis, for a "real" local env
make run              # uvicorn app.main:app --reload  (defaults to sqlite:///./rxflow.db if no Postgres)
```

Without `docker-compose up`, the app still runs: it falls back to a local SQLite file, and Redis
calls fail closed (caching becomes a no-op, background counters return `-1`) instead of crashing
requests.

```bash
make test        # pytest -q
make lint         # ruff check .
make typecheck    # mypy app
```

Run a single test: `pytest tests/unit/test_inventory_service.py::test_name -q`

## How the code is organized

```
app/
  api/          FastAPI routers — auth, customers, products, orders
  services/     Business logic (order_service, payment_service, inventory_service, notification_service)
  models/       SQLAlchemy models (customer, product, inventory, order, payment, webhook_event)
  clients/      Outbound integrations — payment gateway, shipping, tax, email (all mocked)
  core/         Cross-cutting: security (JWT), permissions (role gates), cache (Redis), http_client
  tasks/        Celery background jobs
  repositories/ Legacy — see note below
migrations/     Alembic, applied to Postgres in real deployments
tests/
  unit/         No DB/HTTP dependency beyond fakes
  integration/  Spins up the FastAPI app against a SQLite DB
```

**The flow to internalize:** `api/` → `services/` → `models/` (direct ORM queries) + `clients/` +
`tasks/`. There's no repository/DAO layer for most of the app — services query the ORM directly
(`db.query(...)`, `db.get(...)`). `app/repositories/customer_repository.py` is the one exception: it
predates this pattern, was never extended to orders/products/inventory, and should **not** be used as
a template for new code.

## The core workflow: placing an order

`app/services/order_service.py::create_order()` is the most important function in the codebase to
understand. In order:

1. **Idempotency check.** Every order request carries an `idempotency_key`. If a `(customer_id,
   idempotency_key)` pair already exists, the existing order is returned as-is — unless the incoming
   items/address differ from the original, in which case it's rejected as a conflict. This is backed
   by a real DB unique constraint, and a race between two concurrent identical requests is handled by
   catching the `IntegrityError` on insert and re-fetching the winning row.
2. **Stock reservation.** For each line item, `inventory_service.reserve_stock()` takes a row lock
   (`SELECT ... FOR UPDATE`) on the `Inventory` row and checks `quantity_on_hand - quantity_reserved`
   before incrementing `quantity_reserved`. Note: reservation ≠ decrement. The actual
   `quantity_on_hand` decrement happens later, at fulfillment time, via a separate Celery task
   (`sync_inventory_levels`) — not inside `create_order`.
3. **Payment authorization**, via a mocked gateway client with real retry/backoff logic.
4. Order is committed as `confirmed`, and an async confirmation email is queued
   (`send_order_confirmation.delay(order.id)`).

## Things every new engineer should know

- **Money is integer cents**, never floats — columns are named `*_cents`.
- **Celery tasks open their own DB session** (`SessionLocal()`) — they don't use FastAPI's `get_db`
  dependency, because they run outside the request lifecycle.
- **In tests, Celery runs eagerly** (`RXFLOW_ENV=test` sets `task_always_eager=True`), so `.delay()`
  calls execute synchronously in-process — no broker/worker needed to test task logic.
- **Redis/cache failures degrade silently** by design (see `app/core/cache.py`) — a Redis outage
  should never break checkout or product browsing, only disable caching and job counters.
- **Auth**: JWT via `python-jose`, `sub` claim = customer id, `role` claim mirrors `Customer.role`
  (`customer` / `staff` / `admin`). `require_staff` / `require_admin` in `app/core/permissions.py` gate
  staff-only routes (e.g. stock updates, refunds).
- **Migrations are additive**: numbered sequentially in `migrations/versions/` — add a new one rather
  than editing a past migration, even in dev.
- **`refund_order`** in `app/api/orders.py` currently just flips `Order.status` to `"refunded"` — it
  does not call back out to the payment gateway client. Worth knowing before assuming refunds are
  wired end-to-end.

## Where to look for more detail

`CLAUDE.md` at the repo root carries the same architecture summary in a form intended for Claude Code
sessions — useful as a second reference, and kept up to date alongside this document.
