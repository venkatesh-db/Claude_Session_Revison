"""add orders.idempotency_key with a per-customer unique constraint

Revision ID: 0005
Revises: 0004
Create Date: 2026-09-08 00:00:00

"""
import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("orders") as batch_op:
        batch_op.add_column(sa.Column("idempotency_key", sa.String(length=128), nullable=True))
        batch_op.create_unique_constraint(
            "uq_orders_customer_idempotency_key",
            ["customer_id", "idempotency_key"],
        )


def downgrade() -> None:
    with op.batch_alter_table("orders") as batch_op:
        batch_op.drop_constraint("uq_orders_customer_idempotency_key", type_="unique")
        batch_op.drop_column("idempotency_key")
