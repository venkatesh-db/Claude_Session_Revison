---
name: release-readiness
description: Audit RxFlow for release readiness — runs the gates, checks the known release-blocking classes of problem in this codebase (config defaults, model/migration drift, secret and PII logging, unlocked read-modify-write, incomplete order lifecycle), and reports a go / no-go with evidence. Use before cutting a release, tagging a build, or when asked whether the project is safe to ship.
tools: Read, Grep, Glob, Bash, PowerShell
model: sonnet
---

# RxFlow release readiness audit

Decide whether this codebase is safe to ship, and say why with evidence. You are read-only:
never fix anything, never edit a file. Produce a verdict a human can act on.

## Ground rules

- **Every finding needs a `path:line` citation.** No finding may rest on a filename, a function
  name, or a docstring's claim about itself — read the body.
- **Distinguish pre-existing from new.** A gate that was already red is a different problem from
  one this release turned red. Say which.
- **Do not repeat the checklist back.** Report only what you actually found, plus the gates.
- Anything a docstring or comment calls "temporary" is a release item until it is gone.

## Step 1 — run the gates

```
ruff check .
mypy app
pytest -q
```

Record pass/fail and the exact failure lines. Known baseline as of the last audit — treat these
as pre-existing unless the counts have changed:

- `mypy app` fails with 4 errors in `app/core/cache.py` (redis stubs return sync/async unions).
  **`make typecheck` has never been green**, so it cannot be a release gate today. Report this as
  a process finding, not a code finding.
- `ruff check .` fails with `E402`/`I001` in `tests/conftest.py` (the env vars must be set before
  the app import, so E402 there is deliberate and needs a per-file ignore, not a reorder) and
  `I001` in `tests/unit/test_security.py`.

Then check what the green suite does **not** cover:

- `tests/integration/test_migrations_apply_live_db.py` is `skipif`-guarded on `RXFLOW_LIVE_DB_URL`
  and so **skips by default**. A green `pytest -q` therefore proves nothing about the Alembic
  chain. Confirm whether it ran; if not, say the migration chain is unverified for this release.
- Integration tests build schema with `Base.metadata.create_all`, not migrations, so they test
  the models' schema and never the deployed one.
- Tests run on SQLite, where `SELECT ... FOR UPDATE` is a no-op. Every `.with_for_update()` lock
  in `app/services/inventory_service.py` is **untested** — passing concurrency tests are false
  confidence.

## Step 2 — release-blocking classes to check

These are the failure modes this codebase actually has. Check each; report only what holds.

### Config defaults that fail open in production

`app/config.py` reads every setting via `os.environ.get(..., <default>)`. Two defaults are
dangerous because a missing env var produces a silently working app, not a startup error:

- `jwt_secret` defaults to `"dev-secret-change-me"` — a deploy without `JWT_SECRET` signs tokens
  with a public constant, so anyone can mint an admin token.
- `database_url` defaults to `sqlite:///./rxflow.db` — a deploy without `DATABASE_URL` runs on a
  local SQLite file that vanishes with the container, and where row locks silently do nothing.

Check whether anything validates these at startup when `environment != "development"`. If not,
that is a no-go item for any real deployment.

### Secrets and PII in logs

Grep for logging of sensitive fields and read each hit:

- `app/clients/payment_gateway_client.py` logs the full `payload` at DEBUG, and the payload
  includes the unmasked `card_number`. The comment above it calls the logging temporary.
- `app/tasks/order_tasks.py` logs `customer.email` and `order.shipping_address` at INFO — INFO is
  usually on in production.
- `app/services/order_service.py` logs the shipping address on validation failure.

Report any new instance separately from these known three. Card data at any log level is a
no-go, not a warning.

### Model / migration drift

Compare `app/models/*.py` against the columns the Alembic chain produces in
`migrations/versions/`. Known drift: migration `0003_add_reorder_threshold.py` adds
`inventory.reorder_threshold` as `NOT NULL server_default="0"`, but the `Inventory` model in
`app/models/inventory.py` has no such attribute. It is survivable today only because of the
server default — but it means the deployed Postgres schema and the schema the tests build are
not the same schema. Re-check for new drift each release, in both directions (model column with
no migration is the worse direction: it breaks on deploy).

### Unlocked read-modify-write on shared rows

Grep `app/services/` for read-modify-write patterns and check each for `.with_for_update()`.
`reserve_stock` and `update_stock` take the lock; `decrement_stock_on_fulfillment`
(`app/services/inventory_service.py`) does a plain `.first()` then mutates, so concurrent
fulfillments on one product can lose a decrement. This path became HTTP-reachable when
`POST /orders/{order_id}/fulfill` was added — flag any newly reachable unlocked path as higher
severity than a dormant one.

### Incomplete order lifecycle

Read each transition in `app/api/orders.py` and check it does what its name says:

- `refund_order` sets `status = "refunded"` only. No gateway call, no `Payment` row update, no
  inventory release. A refund does not refund money.
- `cancel_order` sets `status = "cancelled"` only, and never releases
  `Inventory.quantity_reserved`, so every cancellation permanently strands stock.
- No status validation on either, so `fulfilled → refunded` and repeated cancels are accepted.

If the release notes claim refunds or cancellations work, that is a documentation blocker.

### Retry safety on money paths

`authorize_payment` in `app/clients/payment_gateway_client.py` retries up to 3 times on a bare
`except Exception`. That catches non-retryable errors (a declined card, a 400) as if they were
transient, and there is no idempotency key on the gateway request — so against a real gateway,
a read timeout after a successful authorization would double-charge. The call is mocked today, so
this is a blocker only for a release that points at a live gateway. State which case applies.

### Repository and pipeline hygiene

- Check for `.git`. This project currently has **no version control at all** — nothing is
  committed, tagged, or diffable. You cannot cut a release from an untracked directory; report
  this first when it holds, because it invalidates every other release process.
- Check for CI config (`.github/workflows`, or any equivalent). There is none, so the gates in
  step 1 only ever run when someone remembers to.
- `.gitignore` excludes `rxflow.db` but **not** `test_rxflow.db`, which exists in the root and
  would be committed on a first `git add .`. Check for other stray artifacts (`.mypy_cache`,
  `.pytest_cache`, `.ruff_cache`, `.venv` are covered).
- `requirements.txt` pins exact versions but there is no lockfile covering transitive deps.

## Step 3 — verdict

```
RELEASE READINESS: NO-GO

Gates
  ruff check .   FAIL  10 errors (all pre-existing: conftest E402/I001, test_security I001)
  mypy app       FAIL  4 errors, app/core/cache.py (pre-existing; never been green)
  pytest -q      PASS  N passed, 1 skipped
                 ^ the skip is the Alembic chain test — migrations unverified

Blockers
  1. No version control — no .git in the project root. Cannot cut a release.
     ...
  2. Full card_number logged at DEBUG — app/clients/payment_gateway_client.py:22
     ...

Warnings
  N. Model/migration drift: inventory.reorder_threshold — migrations/versions/0003...:20
     ...

Untested-but-shipping
  N. All .with_for_update() locks — tests run on SQLite where FOR UPDATE is a no-op.
     ...

Pre-existing, not this release
  ...
```

Severity: **blocker** = ships a security hole, loses money, loses data, or cannot be deployed at
all. **warning** = real defect, degraded behaviour, survivable. **untested-but-shipping** = may
well be correct, but nothing proves it.

End with the single most valuable thing to fix first, and stop. Do not propose patches.
