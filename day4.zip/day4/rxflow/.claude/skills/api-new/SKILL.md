---
name: api-new
description: Add a new API endpoint to RxFlow following the codebase's existing layering — schema, service function, router route, tests, migration. Use when asked to add, create, or write a new endpoint, route, or API.
---

# New API endpoint

Add an endpoint that looks like it was always there. RxFlow has strong local conventions;
follow them rather than a generic FastAPI layout.

## Before writing anything

1. **Read the nearest sibling.** If the endpoint belongs on an existing resource, read that
   whole router in `app/api/` plus its schema module and service. Match its structure, naming,
   and error style exactly. `app/api/products.py` is the cleanest small example;
   `app/api/orders.py` is the reference for anything with side effects.
2. **Decide the auth level** and confirm it with the user if the request left it open:
   public, any authenticated customer, `require_staff`, or `require_admin`.
3. **Check whether the data already exists** on the models. A new column means a migration —
   see step 6.

## Layer order

Write in this order; each layer depends only on the ones above it.

### 1. Schema — `app/schemas/<resource>.py`

Pydantic v2. Request and response models are separate. Put real constraints in `Field`, since
this is the only input validation the endpoint gets.

```python
class ThingCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    price_cents: int = Field(ge=0)


class ThingOut(BaseModel):
    id: int
    name: str
    price_cents: int

    class Config:
        from_attributes = True
```

Money is always integer cents on a `*_cents` field. Never a float, never a `Decimal` in the
schema.

### 2. Service — `app/services/<resource>_service.py`

All business logic lives here. The router must contain no logic beyond exception translation.

- Query the ORM directly: `db.get(Model, id)`, `db.query(Model).filter(...)`. Do **not** add a
  repository — `app/repositories/customer_repository.py` predates this pattern and is not the
  template.
- Define module-level exceptions for each failure mode
  (`ThingNotFoundError`, `ThingValidationError`) subclassing `Exception`. Never raise
  `HTTPException` from a service.
- The service owns the `db.commit()`, then `db.refresh(obj)` before returning.
- Take a row lock with `.with_for_update()` before any read-modify-write on a row that
  concurrent requests can touch — inventory quantities are the existing precedent.
- If the write must be safely retryable, take an `idempotency_key`, back it with a DB unique
  constraint, and handle the race by catching `IntegrityError` on `flush()`, rolling back, and
  re-querying the winner. Copy the shape from `order_service.create_order`.

### 3. Client, if it calls out — `app/clients/<service>_client.py`

One module per external integration. Build the HTTP client through the shared factory with
explicit timeouts, and keep the real call in a private `_call_*` function:

```python
from app.core.http_client import build_client

def do_thing(payload: dict) -> dict:
    with build_client(connect_timeout=2.0, read_timeout=3.0) as client:
        return _call_thing(client, payload)
```

Never construct `httpx.Client` directly. Never log a payload containing a card number,
password, or token.

### 4. Router — `app/api/<resource>.py`

```python
@router.post("", response_model=ThingOut, status_code=status.HTTP_201_CREATED)
def create_thing(
    payload: ThingCreate,
    db: Session = Depends(get_db),
    current_customer: Customer = Depends(get_current_customer),
) -> Thing:
    try:
        return create_thing_service(db, customer=current_customer, ...)
    except ThingValidationError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
```

- Router owns `prefix` and `tags`; routes use paths relative to it (`""`, `"/{thing_id}"`).
- Translate **every** service exception. An uncaught one is a 500.
- Lowercase detail strings, matching the existing `"order not found"` style.
- Staff-gated routes take `_staff: Customer = Depends(require_staff)` and do not also take
  `get_current_customer`.
- Register a brand-new router in `create_app()` in `app/main.py`.

### 5. Background work, if any — `app/tasks/order_tasks.py`

Enqueue with `.delay()` **after** the commit, never before. Tasks open their own
`SessionLocal()` and close it in a `finally`. Import service functions lazily inside the task
body if a top-level import would cycle.

### 6. Migration, if the schema changed — `migrations/versions/`

Add a new sequential file (`00NN_<description>.py`); never edit an existing migration, even in
dev. Additive changes only — new nullable column, new index, new table. Keep `down_revision`
chained to the current head.

### 7. Tests

Both halves, following the existing split:

- `tests/unit/test_<resource>_service.py` — service logic against fakes, no app.
- `tests/integration/test_<resource>.py` — through the `client` fixture, covering the happy
  path, the auth rejection (401 unauthenticated, 403 wrong role), and each mapped error status.

`RXFLOW_ENV=test` makes Celery eager, so `.delay()` runs inline and task effects are assertable
in the same test.

## Finish

Run `make lint`, `make typecheck`, and `make test` — all three. Ruff enforces import order (`I`)
and a 100-char line length. Mypy checks `app/` with full annotations, including the handler's
return type.

Then report: the files added or changed, the route signature and auth level, and anything you
deliberately left out.

## Rules

- Do not invent a new layer, base class, or helper when an existing one fits.
- Do not add a repository class.
- Do not commit from the router or from a client.
- Do not widen an existing endpoint's auth or response shape as a side effect.
