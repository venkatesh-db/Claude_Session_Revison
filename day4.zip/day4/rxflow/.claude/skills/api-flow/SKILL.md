---
name: api-flow
description: Trace the end-to-end code flow of an RxFlow API endpoint — router → schema → service → models/clients/tasks — and report the layers, side effects, error mapping, and gaps. Use when asked how an endpoint works, what a route touches, or to review an endpoint before changing it.
---

# API flow trace

Trace one RxFlow endpoint from HTTP request to committed state and background work.

## Input

The user names an endpoint, e.g. `POST /orders`, `orders/refund`, or just `refund`. If the
target is ambiguous, resolve it by grepping `@router.` decorators in `app/api/` and pick the
single match; ask only if two or more genuinely match.

## Steps

1. **Locate the route.** Grep `app/api/` for the path or handler name. Read the whole router
   module, not just the handler — sibling routes often share patterns worth noting.

2. **Record the entry contract.**
   - HTTP method, full path (router `prefix` + route path), `status_code`, `response_model`
   - Request schema from `app/schemas/` — read it and note field constraints
     (`Field(min_length=...)`, `ge=`, optionality). These are the real input validation.
   - Every `Depends(...)`: `get_db`, `get_current_customer` (JWT bearer, `app/core/security.py`),
     `require_staff` / `require_admin` (`app/core/permissions.py`). State the auth level
     explicitly — public, any authenticated customer, staff, or admin.

3. **Follow into the service layer.** Read the called function in `app/services/` in full.
   Walk it in execution order and capture, in order:
   - DB reads and whether they take a row lock (`.with_for_update()`)
   - mutations to ORM objects
   - each `db.flush()` / `db.commit()` / `db.rollback()` — and which layer owns the commit
     (services commit; `payment_service.authorize_and_record_payment` deliberately does not)
   - outbound calls into `app/clients/` (all mocked, but the retry/timeout paths are real)
   - `.delay()` enqueues into `app/tasks/`

4. **Follow one level deeper** into any client or task the flow reaches: read the client's
   timeouts and retry policy, and read the task body (tasks open their own `SessionLocal()`).
   Do not recurse further than this unless the user asks.

5. **Map the errors.** For each service-layer exception the handler catches, give the
   exception → HTTP status → detail string. Also list exceptions the service can raise that the
   handler does *not* catch (those surface as 500s) — this is usually the most useful finding.

6. **Report.** Use the output shape below.

## Output shape

```
POST /orders — place an order
Auth: authenticated customer (JWT bearer)

Flow
  1. app/api/orders.py:20  place_order
     validates OrderCreate (app/schemas/order.py) — idempotency_key 1..128 chars, required
  2. app/services/order_service.py:NN  create_order
     a. idempotency pre-check on (customer_id, idempotency_key)
     b. INSERT + db.flush()  — IntegrityError caught, rollback, re-query winner
     c. per item: reserve_stock() — row lock on Inventory, checks on_hand - reserved
     d. authorize_and_record_payment() -> payment_gateway_client (3 retries, 0.5s backoff)
     e. status = "confirmed", db.commit()
     f. send_order_confirmation.delay(order.id)

Side effects
  DB writes: orders, order_items, payments, inventory.quantity_reserved
  Commit point: order_service.create_order step (e)
  Async: rxflow.send_order_confirmation

Errors
  OrderValidationError        -> 400
  IdempotencyKeyConflictError -> 409
  RuntimeError (gateway down) -> uncaught, 500

Gaps / notes
  <anything that does not do what its name implies; see below>
```

Keep it this dense. No prose paragraphs, no restating the file contents.

## Gaps to look for

RxFlow has real stubs. Flag them when the traced flow touches one, rather than describing the
route as if it were complete:

- `refund_order` and `cancel_order` in `app/api/orders.py` only set `Order.status`. Refund makes
  no gateway call and does not touch the `Payment` row; cancel does not release
  `Inventory.quantity_reserved`, so cancelled orders leak reservations.
- `sync_inventory_levels` is the only thing that decrements `quantity_on_hand`, and nothing in
  `app/` calls it — fulfillment is unwired.
- Redis failures in `app/core/cache.py` are swallowed: a cache-backed read silently becomes a
  DB read, and counters return `-1`. Note this whenever the flow reads through
  `get_product_cached`.
- Sensitive data in logs: `order_tasks.send_order_confirmation` logs customer email and shipping
  address at INFO; `payment_gateway_client` logs the full `card_number` at DEBUG. Call it out if
  the flow passes through either; do not extend the pattern.

## Rules

- Read the files. Never infer a flow from module or function names.
- Cite every step as `path:line` so the reader can jump to it.
- Report what the code does, not what it should do. Keep fixes out of the trace; put concerns
  under "Gaps / notes" and stop there unless the user asks for changes.
