# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

RxFlow is a FastAPI order-management backend: customers register/login, browse products, place orders
against tracked inventory, pay via a mocked payment gateway, and receive confirmation emails sent
asynchronously through Celery. It's a teaching/lab codebase — external integrations (payment gateway,
shipping carrier, tax service, email ESP) are all mocked HTTP clients hitting fake `*.internal` URLs,
not live network calls.

## Commands

```
make install    # pip install -r requirements.txt
make run        # uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
make test       # pytest -q
make lint       # ruff check .
make typecheck  # mypy app
```

- Run a single test: `pytest tests/unit/test_inventory_service.py::test_name -q`
- Tests are split into `tests/unit/` (no DB/HTTP dependencies beyond fakes) and `tests/integration/`
  (spins up the FastAPI app with a SQLite DB via `tests/conftest.py` fixtures `db_session`/`client`).
- Integration tests force `RXFLOW_ENV=test` and `DATABASE_URL=sqlite:///./test_rxflow.db` (set at the
  top of `conftest.py` before app import) and rely on `Base.metadata.create_all`/`drop_all` per test,
  not on Alembic migrations. `tests/integration/test_migrations_apply_live_db.py` is the one test that
  actually exercises the Alembic chain.
- When `RXFLOW_ENV=test`, `celery_app.conf.task_always_eager = True` (see `app/tasks/celery_app.py`), so
  `.delay()` calls run synchronously in-process during tests — no broker/worker needed.
- Local infra (Postgres + Redis) for manual/dev runs: `docker-compose up`. Without it, the app falls
  back to SQLite (`sqlite:///./rxflow.db`) and Redis calls in `app/core/cache.py` fail closed (caching
  becomes a no-op, counters return `-1`) rather than raising.

## Architecture

Layering is `api/` → `services/` → (`models/` via direct ORM queries, `clients/`, `tasks/`). There is
**no repository layer** except `app/repositories/customer_repository.py`, which predates the
services-based pattern and was never extended to orders/products/inventory — don't take it as the
template for new code; direct `db.query(...)` / `db.get(...)` in services is the prevailing style.

- **`app/api/`** — FastAPI routers (`auth`, `customers`, `products`, `orders`), registered in
  `app/main.py`. Routes translate service-layer exceptions to HTTP errors and depend on
  `app/core/security.py` (JWT bearer auth, `get_current_customer`) and `app/core/permissions.py`
  (`require_staff`, `require_admin` role gates on `Customer.role`).
- **`app/services/order_service.py`** — the core workflow, `create_order()`:
  1. Idempotency check by `(customer_id, idempotency_key)` — a DB unique constraint backs this, and a
     concurrent-insert race is handled by catching `IntegrityError` on `db.flush()` and re-querying for
     the winning row (see `_matches_existing` for replay-with-different-payload detection, which raises
     `IdempotencyKeyConflictError`).
  2. Per-item stock reservation via `inventory_service.reserve_stock()`, which takes a row lock
     (`with_for_update()`) on the `Inventory` row before checking `quantity_on_hand - quantity_reserved`.
  3. Payment authorization via `payment_service.authorize_and_record_payment()` → mocked
     `clients/payment_gateway_client.authorize_payment()` (has real retry/backoff logic even though the
     actual gateway call is stubbed).
  4. Order is committed as `confirmed`, then `tasks/order_tasks.send_order_confirmation.delay(order.id)`
     fires the async confirmation email.
- **Inventory model**: `quantity_on_hand` vs `quantity_reserved` are tracked separately. Reservation
  happens at order-creation time (`reserve_stock`); actual decrement of `quantity_on_hand` happens later
  at fulfillment time via `decrement_stock_on_fulfillment` (invoked from the `sync_inventory_levels`
  Celery task, not from `create_order` directly).
- **`app/tasks/`** — Celery tasks against the `rxflow` queue (`celery_app.py`). `order_tasks.py` holds
  `send_order_confirmation`, `sync_inventory_levels`, and `reconcile_payment_webhook`. Tasks open their
  own `SessionLocal()` (they don't use the FastAPI `get_db` dependency) and import service functions
  lazily inside the task body in a couple of spots to avoid import cycles.
- **`app/core/cache.py`** — Redis-backed helpers used for product read caching
  (`inventory_service.get_product_cached`) and in-flight job counters. All Redis errors are swallowed
  (cache/counter failures degrade gracefully rather than breaking requests). `increment_counter` /
  `decrement_counter` use Redis `INCR`/`DECR` specifically to stay atomic under concurrent callers —
  don't reimplement these as a Python-side get/modify/set.
- **`app/core/http_client.py`** — single `build_client()` factory for all outbound `httpx.Client`s;
  clients pass their own connect/read timeouts, falling back to `settings.default_http_timeout_seconds`.
- **`app/clients/`** — one module per external integration (`payment_gateway_client`, `shipping_client`,
  `tax_client`, `email_client`). Each builds its own `httpx.Client` via `build_client()` and calls a
  private `_call_*` function that is mocked (no real network I/O) — real timeout/retry code paths still
  execute, only the actual request/response is stubbed.
- **`app/models/`** — SQLAlchemy 2.0 declarative models (`Mapped`/`mapped_column`) sharing `Base` from
  `app/db.py`. Money fields are stored as integer cents (`Numeric(10, 0)` columns named `*_cents`), not
  floats.
- **Migrations** — Alembic, `migrations/versions/`, applied against Postgres in real deployments (the
  `docker-compose.yml` Postgres/Redis services). Sequential numbered files (`0001`...`0005`); add new
  migrations rather than editing existing ones.
- **Auth** — JWT (`python-jose`), `sub` claim is the customer id, `role` claim mirrors
  `Customer.role` (`customer`/`staff`/`admin`). Passwords hashed with `passlib[bcrypt]`.

## Keeping skills and agents in sync with this file

Whenever a change to this CLAUDE.md introduces or updates a workflow or use case (a new module/layer,
a new integration pattern, a changed lifecycle step, a new command, etc.), the project's `.claude/skills/`
and `.claude/agents/` definitions must be reviewed and updated in the same session, so they stay
consistent with the documented architecture. Concretely: before ending a session that edited this file,
check whether any existing skill or agent description references the part of the system that changed,
and update it; if the new workflow/use case has no corresponding skill or agent, add one. Do not treat
editing this file as sufficient on its own — the skill/agent definitions are what future sessions
actually load, so they must be kept current explicitly, not left to go stale.
