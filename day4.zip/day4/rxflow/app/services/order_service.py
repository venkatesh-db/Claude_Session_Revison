import logging

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.customer import Customer
from app.models.order import Order, OrderItem
from app.models.product import Product
from app.services.inventory_service import InsufficientStockError, reserve_stock
from app.services.payment_service import authorize_and_record_payment
from app.tasks.order_tasks import send_order_confirmation, sync_inventory_levels

logger = logging.getLogger(__name__)

# Statuses an order can be fulfilled from. Anything else is a no-op or an error.
_FULFILLABLE_STATUSES = ("confirmed",)


class OrderValidationError(Exception):
    pass


class IdempotencyKeyConflictError(Exception):
    """Raised when a key is replayed against a different cart/payload."""


class OrderNotFoundError(Exception):
    pass


class OrderStateError(Exception):
    """Raised when an order is not in a state that allows the requested transition."""


def _matches_existing(existing: Order, items: list[dict], shipping_address: str) -> bool:
    if existing.shipping_address != shipping_address:
        return False
    existing_items = sorted(
        ((i.product_id, i.quantity) for i in existing.items), key=lambda pair: pair[0]
    )
    incoming_items = sorted(
        ((i["product_id"], i["quantity"]) for i in items), key=lambda pair: pair[0]
    )
    return existing_items == incoming_items


def create_order(
    db: Session,
    customer: Customer,
    items: list[dict],
    shipping_address: str,
    card_number: str,
    card_last4: str | None,
    idempotency_key: str,
) -> Order:
    existing = (
        db.query(Order)
        .filter(Order.customer_id == customer.id, Order.idempotency_key == idempotency_key)
        .first()
    )
    if existing is not None:
        if not _matches_existing(existing, items, shipping_address):
            raise IdempotencyKeyConflictError(
                f"idempotency_key {idempotency_key!r} was already used for a different order"
            )
        return existing

    if not items:
        logger.error(
            "Order validation failed for customer %s: no items. address=%s",
            customer.id,
            shipping_address,
        )
        raise OrderValidationError("order must contain at least one item")

    total_cents = 0
    order = Order(
        customer_id=customer.id,
        status="pending",
        total_cents=0,
        shipping_address=shipping_address,
        idempotency_key=idempotency_key,
    )
    db.add(order)
    try:
        db.flush()  # assign order.id; also surfaces a concurrent duplicate key here
    except IntegrityError as exc:
        db.rollback()
        winner = (
            db.query(Order)
            .filter(Order.customer_id == customer.id, Order.idempotency_key == idempotency_key)
            .first()
        )
        if winner is not None:
            return winner
        raise OrderValidationError("could not create order") from exc

    for item in items:
        product = db.get(Product, item["product_id"])
        if product is None:
            raise OrderValidationError(f"unknown product {item['product_id']}")

        try:
            reserve_stock(db, product.id, item["quantity"])
        except InsufficientStockError as exc:
            raise OrderValidationError(str(exc)) from exc

        unit_price = int(product.price_cents)
        line_total = unit_price * item["quantity"]
        total_cents += line_total

        db.add(
            OrderItem(
                order_id=order.id,
                product_id=product.id,
                quantity=item["quantity"],
                unit_price_cents=unit_price,
            )
        )

    order.total_cents = total_cents

    authorize_and_record_payment(
        db,
        order_id=order.id,
        amount_cents=total_cents,
        card_number=card_number,
        card_last4=card_last4 or card_number[-4:],
    )

    order.status = "confirmed"
    db.commit()
    db.refresh(order)

    send_order_confirmation.delay(order.id)

    return order


def fulfill_order(db: Session, order_id: int) -> Order:
    """Mark a confirmed order as fulfilled and release its inventory reservation.

    This is the second half of the two-phase inventory flow: `create_order` bumps
    `quantity_reserved` at order time, and the actual `quantity_on_hand` decrement happens
    here, via the `sync_inventory_levels` task, once the goods physically ship.

    Re-fulfilling an already-fulfilled order is a no-op rather than an error, so a retried
    request from a warehouse client cannot double-decrement stock.
    """
    order = db.get(Order, order_id)
    if order is None:
        raise OrderNotFoundError("order not found")

    if order.status == "fulfilled":
        return order

    if order.status not in _FULFILLABLE_STATUSES:
        raise OrderStateError(f"cannot fulfill order in status {order.status!r}")

    order.status = "fulfilled"
    db.add(order)
    db.commit()
    db.refresh(order)

    # Enqueued only after the commit, so the task cannot observe an unfulfilled order.
    sync_inventory_levels.delay(order.id)

    return order
