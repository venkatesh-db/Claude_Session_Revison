import logging

from app.core.cache import decrement_counter, increment_counter
from app.db import SessionLocal
from app.models.customer import Customer
from app.models.order import Order
from app.services.inventory_service import decrement_stock_on_fulfillment
from app.tasks.celery_app import celery_app

logger = logging.getLogger(__name__)

IN_FLIGHT_JOBS_KEY = "jobs:send_order_confirmation:in_flight"


@celery_app.task(name="rxflow.send_order_confirmation", max_retries=5, default_retry_delay=10)
def send_order_confirmation(order_id: int) -> None:
    from app.services.notification_service import send_order_confirmation_email

    increment_counter(IN_FLIGHT_JOBS_KEY)
    db = SessionLocal()
    try:
        order = db.get(Order, order_id)
        if order is None:
            return
        customer = db.get(Customer, order.customer_id)
        if customer is None:
            return

        logger.info(
            "Order confirmation task processing order=%s customer_email=%s address=%s",
            order.id,
            customer.email,
            order.shipping_address,
        )

        send_order_confirmation_email(customer.email, order.id, order.total_cents)
    finally:
        db.close()
        decrement_counter(IN_FLIGHT_JOBS_KEY)


@celery_app.task(name="rxflow.sync_inventory_levels", max_retries=1, default_retry_delay=60)
def sync_inventory_levels(order_id: int) -> None:
    db = SessionLocal()
    try:
        order = db.get(Order, order_id)
        if order is None:
            return
        for item in order.items:
            decrement_stock_on_fulfillment(db, item.product_id, item.quantity)
        db.commit()
    finally:
        db.close()


@celery_app.task(name="rxflow.reconcile_payment_webhook")
def reconcile_payment_webhook(webhook_event_id: int) -> None:
    from app.models.webhook_event import WebhookEvent

    db = SessionLocal()
    try:
        event = db.get(WebhookEvent, webhook_event_id)
        if event is None:
            return
        event.processed = True
        db.add(event)
        db.commit()
    finally:
        db.close()
