from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.permissions import require_staff
from app.core.security import get_current_customer
from app.db import get_db
from app.models.customer import Customer
from app.models.order import Order
from app.schemas.order import OrderCreate, OrderOut
from app.services.order_service import (
    IdempotencyKeyConflictError,
    OrderValidationError,
    create_order,
)

router = APIRouter(prefix="/orders", tags=["orders"])


@router.post("", response_model=OrderOut, status_code=status.HTTP_201_CREATED)
def place_order(
    payload: OrderCreate,
    db: Session = Depends(get_db),
    current_customer: Customer = Depends(get_current_customer),
) -> Order:
    try:
        order = create_order(
            db,
            customer=current_customer,
            items=[item.model_dump() for item in payload.items],
            shipping_address=payload.shipping_address,
            card_number=payload.card_number,
            card_last4=payload.card_last4,
            idempotency_key=payload.idempotency_key,
        )
    except OrderValidationError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except IdempotencyKeyConflictError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    return order


@router.get("", response_model=list[OrderOut])
def list_orders(
    db: Session = Depends(get_db),
    current_customer: Customer = Depends(get_current_customer),
) -> list[Order]:
    return (
        db.query(Order)
        .filter(Order.customer_id == current_customer.id)
        .order_by(Order.id.desc())
        .all()
    )


@router.get("/{order_id}", response_model=OrderOut)
def get_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_customer: Customer = Depends(get_current_customer),
) -> Order:
    order = (
        db.query(Order)
        .filter(Order.id == order_id, Order.customer_id == current_customer.id)
        .first()
    )
    if order is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="order not found")
    return order


@router.post("/{order_id}/cancel", response_model=OrderOut)
def cancel_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_customer: Customer = Depends(get_current_customer),
) -> Order:
    order = (
        db.query(Order)
        .filter(Order.id == order_id, Order.customer_id == current_customer.id)
        .first()
    )
    if order is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="order not found")
    order.status = "cancelled"
    db.commit()
    db.refresh(order)
    return order


@router.post("/{order_id}/refund", response_model=OrderOut)
def refund_order(
    order_id: int,
    db: Session = Depends(get_db),
    _staff: Customer = Depends(require_staff),
) -> Order:
    order = db.get(Order, order_id)
    if order is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="order not found")
    order.status = "refunded"
    db.commit()
    db.refresh(order)
    return order
