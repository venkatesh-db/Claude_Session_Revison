# EVIDENCE — Gap Register

What is missing from this project, derived from the eight-mechanism mapping and from reading the
codebase. Every entry below was checked against the working tree during the session that produced
this file: paths opened, detection rules run against the files they target, gates executed.

Entries marked **UNVERIFIED** are the ones I could not test, and say why. Nothing here is inferred
from a filename.

Companion documents: `CLAUDE.md` (standing standard for Claude sessions), `ONBOARDING.md` (human
onboarding), `EVIDENCE_CHANGE_LOG.md` (per-commit history, once version control exists).

---

## Part A — Mechanism gaps

The eight ways to give Claude a constraint, and which are absent here.

| # | Mechanism | State | Evidence |
|---|---|---|---|
| A1 | A prompt — one-time constraint | in use, ephemeral | build briefs, `/api-new` invocations |
| A2 | `CLAUDE.md` — standing standard | **present** | `CLAUDE.md`, auto-loaded per session |
| A3 | Slash command — typed most days | **MISSING** | no `.claude/commands/` directory exists |
| A4 | Skill — repeatable, needs judgement | **present** | `.claude/skills/api-flow/`, `.claude/skills/api-new/` |
| A5 | Hook — must fire regardless | written, **NOT INSTALLED** | `scripts/hooks/` exists; `core.hooksPath` unset, no `.git` |
| A6 | MCP server — outside the repo | **MISSING** | 10 connectors listed, none authenticated |
| A7 | Sub-agent — bounded, isolated | present, **1 never run** | `.claude/agents/release-readiness.md` defined, never executed |
| A8 | Headless / CI — nobody present | wired, **CANNOT RUN** | `claude -p` in both hooks; `claude` not on PATH; no CI |

### A3 — No slash commands

Three would remove daily typing: `/gates` (lint + typecheck + tests, reporting only deltas),
`/drift` (diff models against the migration chain), `/changelog` (regenerate the log for a range).

### A5 — Hooks are written but inert

`scripts/hooks/pre-commit`, `pre-push`, and `install.sh` exist and pass `bash -n`. Not yet applied:

- `post-commit` — staged in the session scratchpad, not copied in
- `pre-commit` **stage 0** (integrity + protected-path refusal) — staged, not inserted
- `scripts/hooks/seal.sh` and `MANIFEST.sha256` — staged, never generated
- `.github/CODEOWNERS` — staged, not created

These four are staged rather than applied because `.claude/settings.json` now denies writes to
`scripts/hooks/**` and `.github/CODEOWNERS`. That is the constraint working, but it means the set is
incomplete until an owner applies them by hand.

### A8 — Headless is wired but has never executed

Both agent stages call `claude -p`. The CLI is not on PATH in this environment, so both degrade to a
printed notice and `exit 0`. Deliberate — a missing CLI must not cost anyone a commit — but it means
**the release-readiness audit has never actually run.** "Wired" and "proven" are different claims.

---

## Part B — Repository and pipeline gaps

| # | Missing | Impact | Evidence |
|---|---|---|---|
| B1 | **Version control** | blocks A5, A7, A8 and all of Part E | no `.git` in the project root |
| B2 | **CI pipeline** | gates run only where someone installed them | no `.github/` directory |
| B3 | `claude` CLI | headless stages inert | `which claude` → not found |
| B4 | `README.md` | no entry point for a new clone | absent from root |
| B5 | `.env.example` | required env vars undocumented | absent; `config.py` is the only record |
| B6 | Dependency lockfile | transitive deps unpinned | `requirements.txt` pins directs only |
| B7 | `.gitignore` entry for `test_rxflow.db` | 60 KB artifact commits on first `git add .` | `.gitignore` covers `rxflow.db` only |
| B8 | `EVIDENCE_redis_counter_drift.md` | dangling pointer future readers will chase | referenced at `app/core/cache.py:50`, file absent |
| B9 | Branch protection + CODEOWNERS | local layers are removable; nothing is binding | no forge config; `CODEOWNERS` staged only |

**B1 is the highest-value item in this document.** Four of the eight mechanisms are commit- or
push-triggered and cannot fire without it: the hooks have no event, the change log has no commit to
record, CODEOWNERS has no forge to enforce it, and `/code-review` fails for the same reason.

---

## Part C — Gates that are not green

| # | Gate | State | Evidence |
|---|---|---|---|
| C1 | `make typecheck` | **FAILS**, 4 errors | `app/core/cache.py:15,25,54,62` — redis stubs return sync/async unions |
| C2 | `make lint` | **FAILS**, 10 errors | `tests/conftest.py` E402/I001 ×7, `tests/unit/test_security.py` I001 |
| C3 | `make test` | passes | but see Part D — what it does not cover |

`make typecheck` has never been green, so it cannot function as a release gate today. The
`conftest.py` E402s are **deliberate** — the env vars must be set before the app import — so they
need a per-file ignore, not a reorder.

---

## Part D — What the passing test suite does not prove

| # | Untested | Why it matters | Evidence |
|---|---|---|---|
| D1 | The Alembic migration chain | a green suite says nothing about the deployed schema | `tests/integration/test_migrations_apply_live_db.py:5` is `skipif`-guarded on `RXFLOW_LIVE_DB_URL` and skips by default |
| D2 | Every `.with_for_update()` row lock | passing concurrency tests are false confidence | tests run on SQLite, where `SELECT ... FOR UPDATE` is a no-op |
| D3 | The deployed schema | tests build from models, not migrations | integration fixtures use `Base.metadata.create_all` |
| D4 | Postgres behaviour of the integer-division sort | reasoned, not tested | `lenskart-demo/backend/` — noted by its own author |

---

## Part E — Code defects, verified

Ordered by severity.

| # | Defect | Location | Severity |
|---|---|---|---|
| E1 | Full unmasked `card_number` logged at DEBUG | `app/clients/payment_gateway_client.py:22` | **blocker** |
| E2 | `jwt_secret` defaults to `"dev-secret-change-me"` | `app/config.py:18` | **blocker** |
| E3 | `database_url` silently defaults to SQLite | `app/config.py:7` | **blocker** |
| E4 | `refund_order` sets a status string only — no gateway call, no `Payment` update, no stock release | `app/api/orders.py:99` | high |
| E5 | `cancel_order` never releases `quantity_reserved` — cancels strand stock permanently | `app/api/orders.py:84` | high |
| E6 | Model/migration drift: `inventory.reorder_threshold` exists in migration `0003` but not on the model | `migrations/versions/0003_add_reorder_threshold.py:20` vs `app/models/inventory.py` | high |
| E7 | `decrement_stock_on_fulfillment` does read-modify-write with **no row lock**, unlike its siblings — and is now HTTP-reachable | `app/services/inventory_service.py:61-67` | high |
| E8 | Payment retry loops on bare `except Exception` with no idempotency key — would double-charge a real gateway on a post-authorization timeout | `app/clients/payment_gateway_client.py:29` | high (mocked today) |
| E9 | Customer email and shipping address logged at INFO | `app/tasks/order_tasks.py:29-34` | medium |
| E10 | No status validation on any lifecycle transition — `fulfilled → refunded` and repeat cancels are accepted | `app/api/orders.py` | medium |
| E11 | No startup validation of config when `environment != "development"` — a missing env var yields a silently working app, not a failure | `app/config.py` | medium |
| E12 | `/health` returns a static dict; no DB or Redis check | `app/main.py` | low |

E1 and E2 together are why a `blocking` audit will report NO-GO on this repository as it stands.

---

## Part F — Incomplete work from this session

| # | Missing | Detail |
|---|---|---|
| F1 | Four filter facets unwired | `weight`, `collection`, `face_shape`, `occasion` are in the real page's sidebar and were **omitted from the API contract I wrote**. Backend returns counts for them but rejects them as filter params; frontend derives them client-side. Both agents flagged it independently. One line each in `_COLUMN_FILTERS` and the router signature. |
| F2 | No end-to-end test of the demo | Frontend `USE_MOCK` defaults to `true` and its JavaScript was **never executed** (no `node`, no headless browser). Backend CORS is curl-verified only. "The two halves fit" is an inference from a shared contract, not an observed fact. **UNVERIFIED** |
| F3 | Facet counts not selection-narrowed | Catalogue-wide, per the static `/api/filters` contract — a count can overstate results alongside other active filters. |
| F4 | No product detail page | `GET /api/products/{id}` implemented and unconsumed; "3D Try" and "View Similar" inert. |
| F5 | Hooks never tested as hooks | The scripts parse and their detection rules were verified against real files with a no-false-positive control, but no script has run as an actual git hook — there is no repository to commit into. **UNVERIFIED** |
| F6 | Change log trails by one commit | `post-commit` leaves the entry unstaged; committing from inside it would recurse. |
| F7 | No enforcement that commits are logged | `post-commit` cannot block. If logging must be guaranteed, the check belongs in `pre-push`. |
| F8 | Instruction files unprotected locally | Stage 0's protected regex covers hooks, settings, agents and CODEOWNERS — but **not** `CLAUDE.md` or `.claude/skills/`, which is the "developer instructs Claude" vector. Covered by CODEOWNERS review only. **Decision pending.** |

---

## Priority

1. **`git init`** and an initial commit — unblocks B1, A5, A7, A8, E-tracking, and `/code-review`.
2. **E1, E2, E3** — the three security blockers. Cheap fixes, and they are what a first audit will
   halt on.
3. **Apply the staged enforcement files** — stage 0, `seal.sh`, `post-commit`, `CODEOWNERS` — then
   `bash scripts/hooks/install.sh` and `seal.sh`.
4. **B9 branch protection** — the only genuinely binding control. Local layers stop accidental and
   instructed edits; they do not stop a determined developer on their own machine.
5. **C1, C2** — make the gates green so they can be gates. Per-file ignore for `conftest.py`.
6. **D1, D2** — run migrations in CI against Postgres, so the chain and the row locks are actually
   exercised.
7. **E4–E7** — the lifecycle lies and the unlocked write path.
8. **A3, A6, F1–F4** — smallest, last.

---

## What is not missing

Recorded so the register is not read as a verdict on the whole codebase.

- The idempotency design in `order_service.create_order` is genuinely correct: DB unique constraint,
  `IntegrityError` caught on `flush()`, rollback, re-query the winner.
- Money is integer cents throughout, with no float arithmetic on any money path.
- Redis fails closed by design, and `increment_counter`/`decrement_counter` use server-side
  `INCR`/`DECR` for atomicity — with a docstring explaining the drift that motivated it.
- Reservation and fulfillment are correctly separated into two phases, and as of
  `POST /orders/{order_id}/fulfill` the second phase finally has a caller.
- `build_client()` centralises outbound HTTP timeouts, and each client sets its own.
- The new fulfillment endpoint is idempotent: re-fulfilling is a no-op, so a retried warehouse
  client cannot double-decrement stock. 11 tests, ruff clean.
