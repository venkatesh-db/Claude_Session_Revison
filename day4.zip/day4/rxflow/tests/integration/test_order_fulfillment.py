from app.models.customer import Customer
from app.models.inventory import Inventory
from app.models.product import Product


def _register_and_login(client, email="buyer@example.com"):
    client.post(
        "/auth/register",
        json={"email": email, "password": "hunter2pass", "full_name": "Buyer One"},
    )
    resp = client.post("/auth/login", json={"email": email, "password": "hunter2pass"})
    return resp.json()["access_token"]


def _promote_to_staff(client, db_session, email="staff@example.com"):
    _register_and_login(client, email=email)
    customer = db_session.query(Customer).filter(Customer.email == email).first()
    customer.role = "staff"
    db_session.commit()
    # Re-login so the JWT carries the updated role claim.
    resp = client.post("/auth/login", json={"email": email, "password": "hunter2pass"})
    return resp.json()["access_token"]


def _seed_product(db_session, quantity=10):
    product = Product(sku="SKU-FULFILL", name="Fulfillable Thing", price_cents=1000)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=quantity, quantity_reserved=0))
    db_session.commit()
    return product


def _place_order(client, product, token, key):
    return client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 2}],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
            "idempotency_key": key,
        },
        headers={"Authorization": f"Bearer {token}"},
    )


def test_fulfill_confirmed_order_decrements_on_hand_and_clears_reservation(client, db_session):
    buyer_token = _register_and_login(client, email="fulfil-buyer@example.com")
    staff_token = _promote_to_staff(client, db_session)
    product = _seed_product(db_session, quantity=10)

    order_id = _place_order(client, product, buyer_token, "fulfil-1").json()["id"]

    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    db_session.refresh(inventory)
    assert inventory.quantity_reserved == 2
    assert inventory.quantity_on_hand == 10

    resp = client.post(
        f"/orders/{order_id}/fulfill", headers={"Authorization": f"Bearer {staff_token}"}
    )

    assert resp.status_code == 200
    assert resp.json()["status"] == "fulfilled"

    # sync_inventory_levels runs eagerly under RXFLOW_ENV=test.
    db_session.expire_all()
    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    assert inventory.quantity_on_hand == 8
    assert inventory.quantity_reserved == 0


def test_fulfill_is_idempotent_and_does_not_double_decrement(client, db_session):
    buyer_token = _register_and_login(client, email="fulfil-twice@example.com")
    staff_token = _promote_to_staff(client, db_session, email="staff-twice@example.com")
    product = _seed_product(db_session, quantity=10)

    order_id = _place_order(client, product, buyer_token, "fulfil-twice-1").json()["id"]
    headers = {"Authorization": f"Bearer {staff_token}"}

    first = client.post(f"/orders/{order_id}/fulfill", headers=headers)
    second = client.post(f"/orders/{order_id}/fulfill", headers=headers)

    assert first.status_code == 200
    assert second.status_code == 200

    db_session.expire_all()
    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    assert inventory.quantity_on_hand == 8  # not 6


def test_fulfill_rejects_cancelled_order(client, db_session):
    buyer_token = _register_and_login(client, email="fulfil-cancelled@example.com")
    staff_token = _promote_to_staff(client, db_session, email="staff-cancelled@example.com")
    product = _seed_product(db_session)

    order_id = _place_order(client, product, buyer_token, "fulfil-cancelled-1").json()["id"]
    client.post(
        f"/orders/{order_id}/cancel", headers={"Authorization": f"Bearer {buyer_token}"}
    )

    resp = client.post(
        f"/orders/{order_id}/fulfill", headers={"Authorization": f"Bearer {staff_token}"}
    )

    assert resp.status_code == 409


def test_fulfill_unknown_order_returns_404(client, db_session):
    staff_token = _promote_to_staff(client, db_session, email="staff-404@example.com")

    resp = client.post(
        "/orders/999999/fulfill", headers={"Authorization": f"Bearer {staff_token}"}
    )

    assert resp.status_code == 404


def test_fulfill_requires_staff_role(client, db_session):
    buyer_token = _register_and_login(client, email="fulfil-notstaff@example.com")
    product = _seed_product(db_session)

    order_id = _place_order(client, product, buyer_token, "fulfil-notstaff-1").json()["id"]

    resp = client.post(
        f"/orders/{order_id}/fulfill", headers={"Authorization": f"Bearer {buyer_token}"}
    )

    assert resp.status_code == 403


def test_fulfill_requires_authentication(client, db_session):
    resp = client.post("/orders/1/fulfill")
    assert resp.status_code == 401
