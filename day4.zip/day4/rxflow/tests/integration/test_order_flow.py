from app.models.inventory import Inventory
from app.models.order import Order
from app.models.product import Product


def _register_and_login(client, email="buyer@example.com"):
    client.post(
        "/auth/register",
        json={"email": email, "password": "hunter2pass", "full_name": "Buyer One"},
    )
    resp = client.post("/auth/login", json={"email": email, "password": "hunter2pass"})
    return resp.json()["access_token"]


def _seed_product(db_session, quantity=10):
    product = Product(sku="SKU-ORDER", name="Orderable Thing", price_cents=1000)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=quantity, quantity_reserved=0))
    db_session.commit()
    return product


def test_place_order_end_to_end(client, db_session):
    token = _register_and_login(client)
    product = _seed_product(db_session)

    resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 2}],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
            "idempotency_key": "order-e2e-1",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 201
    body = resp.json()
    assert body["status"] == "confirmed"
    assert body["total_cents"] == 2000
    assert len(body["items"]) == 1


def test_place_order_without_items_fails(client, db_session):
    token = _register_and_login(client, email="empty@example.com")

    resp = client.post(
        "/orders",
        json={
            "items": [],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
            "idempotency_key": "order-empty-1",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 400


def test_place_order_insufficient_stock_fails(client, db_session):
    token = _register_and_login(client, email="oversell@example.com")
    product = _seed_product(db_session, quantity=1)

    resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 5}],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
            "idempotency_key": "order-oversell-1",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 400


def test_customer_cannot_fetch_another_customers_order_by_id(client, db_session):
    """GET /orders/{order_id} must filter by ownership, like list/cancel do."""
    token_a = _register_and_login(client, email="a@example.com")
    token_b = _register_and_login(client, email="b@example.com")
    product = _seed_product(db_session)

    create_resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 1}],
            "shipping_address": "A's address",
            "card_number": "4242424242424242",
            "idempotency_key": "order-authz-a-1",
        },
        headers={"Authorization": f"Bearer {token_a}"},
    )
    order_id = create_resp.json()["id"]

    resp = client.get(f"/orders/{order_id}", headers={"Authorization": f"Bearer {token_b}"})
    assert resp.status_code == 404

    own_resp = client.get(f"/orders/{order_id}", headers={"Authorization": f"Bearer {token_a}"})
    assert own_resp.status_code == 200


def test_list_orders_returns_only_own_orders(client, db_session):
    token_a = _register_and_login(client, email="lister-a@example.com")
    token_b = _register_and_login(client, email="lister-b@example.com")
    product = _seed_product(db_session, quantity=10)

    for n in range(2):
        client.post(
            "/orders",
            json={
                "items": [{"product_id": product.id, "quantity": 1}],
                "shipping_address": "A's address",
                "card_number": "4242424242424242",
                "idempotency_key": f"order-lister-a-{n}",
            },
            headers={"Authorization": f"Bearer {token_a}"},
        )
    client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 1}],
            "shipping_address": "B's address",
            "card_number": "4242424242424242",
            "idempotency_key": "order-lister-b-0",
        },
        headers={"Authorization": f"Bearer {token_b}"},
    )

    resp = client.get("/orders", headers={"Authorization": f"Bearer {token_a}"})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 2
    assert all(order["shipping_address"] == "A's address" for order in body)


# --- idempotency: duplicate order on retried submit (T1-T11) ---


def _cart_payload(product, idempotency_key, address="1 Test Way"):
    return {
        "items": [{"product_id": product.id, "quantity": 2}],
        "shipping_address": address,
        "card_number": "4242424242424242",
        "idempotency_key": idempotency_key,
    }


def test_t1_single_submit_creates_one_order(client, db_session):
    token = _register_and_login(client, email="t1@example.com")
    product = _seed_product(db_session)

    resp = client.post(
        "/orders", json=_cart_payload(product, "t1-key"), headers={"Authorization": f"Bearer {token}"}
    )

    assert resp.status_code == 201
    assert db_session.query(Order).count() == 1


def test_t2_retry_with_same_key_returns_original_order_not_a_new_one(client, db_session):
    token = _register_and_login(client, email="t2@example.com")
    product = _seed_product(db_session)
    headers = {"Authorization": f"Bearer {token}"}

    first = client.post("/orders", json=_cart_payload(product, "t2-key"), headers=headers)
    second = client.post("/orders", json=_cart_payload(product, "t2-key"), headers=headers)

    assert first.status_code == 201
    assert second.status_code == 201
    assert first.json()["id"] == second.json()["id"]
    assert db_session.query(Order).count() == 1

    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    assert inventory.quantity_reserved == 2  # not 4


def test_t3_concurrent_duplicate_insert_resolves_to_one_order(client, db_session):
    """Simulates the race directly: two Order rows racing to flush the same
    (customer_id, idempotency_key) must not both land — the DB constraint
    added in migration 0005 is what actually closes this gap, not app logic
    timing."""
    _register_and_login(client, email="t3@example.com")
    _seed_product(db_session)
    from app.models.customer import Customer

    customer_id = db_session.query(Customer).filter(Customer.email == "t3@example.com").first().id

    db_session.add(
        Order(
            customer_id=customer_id,
            status="confirmed",
            total_cents=2000,
            shipping_address="1 Test Way",
            idempotency_key="t3-key",
        )
    )
    db_session.commit()

    from sqlalchemy.exc import IntegrityError

    db_session.add(
        Order(
            customer_id=customer_id,
            status="confirmed",
            total_cents=2000,
            shipping_address="1 Test Way",
            idempotency_key="t3-key",
        )
    )
    raised = False
    try:
        db_session.commit()
    except IntegrityError:
        raised = True
        db_session.rollback()

    assert raised, "unique constraint should reject the second concurrent insert"
    assert db_session.query(Order).filter(Order.idempotency_key == "t3-key").count() == 1


def test_t4_same_key_different_cart_is_rejected(client, db_session):
    token = _register_and_login(client, email="t4@example.com")
    product = _seed_product(db_session)
    headers = {"Authorization": f"Bearer {token}"}

    first = client.post("/orders", json=_cart_payload(product, "t4-key"), headers=headers)
    conflicting = client.post(
        "/orders",
        json=_cart_payload(product, "t4-key", address="A different address"),
        headers=headers,
    )

    assert first.status_code == 201
    assert conflicting.status_code == 409


def test_t7_same_key_across_different_customers_does_not_collide(client, db_session):
    token_a = _register_and_login(client, email="t7a@example.com")
    token_b = _register_and_login(client, email="t7b@example.com")
    product = _seed_product(db_session, quantity=10)

    resp_a = client.post(
        "/orders",
        json=_cart_payload(product, "shared-key"),
        headers={"Authorization": f"Bearer {token_a}"},
    )
    resp_b = client.post(
        "/orders",
        json=_cart_payload(product, "shared-key"),
        headers={"Authorization": f"Bearer {token_b}"},
    )

    assert resp_a.status_code == 201
    assert resp_b.status_code == 201
    assert resp_a.json()["id"] != resp_b.json()["id"]


def test_t8_missing_idempotency_key_is_rejected(client, db_session):
    token = _register_and_login(client, email="t8@example.com")
    product = _seed_product(db_session)

    resp = client.post(
        "/orders",
        json={
            "items": [{"product_id": product.id, "quantity": 1}],
            "shipping_address": "1 Test Way",
            "card_number": "4242424242424242",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 422


def test_t10_retry_does_not_call_payment_gateway_twice(client, db_session, monkeypatch):
    token = _register_and_login(client, email="t10@example.com")
    product = _seed_product(db_session)
    headers = {"Authorization": f"Bearer {token}"}

    calls = []
    from app.services import payment_service

    original = payment_service.authorize_payment

    def counting_authorize(*args, **kwargs):
        calls.append(1)
        return original(*args, **kwargs)

    monkeypatch.setattr(payment_service, "authorize_payment", counting_authorize)

    client.post("/orders", json=_cart_payload(product, "t10-key"), headers=headers)
    client.post("/orders", json=_cart_payload(product, "t10-key"), headers=headers)

    assert len(calls) == 1


def test_t11_retry_does_not_enqueue_confirmation_task_twice(client, db_session, monkeypatch):
    token = _register_and_login(client, email="t11@example.com")
    product = _seed_product(db_session)
    headers = {"Authorization": f"Bearer {token}"}

    calls = []
    from app.services import order_service

    monkeypatch.setattr(
        order_service.send_order_confirmation, "delay", lambda order_id: calls.append(order_id)
    )

    client.post("/orders", json=_cart_payload(product, "t11-key"), headers=headers)
    client.post("/orders", json=_cart_payload(product, "t11-key"), headers=headers)

    assert len(calls) == 1
