"""Regression test for the Redis in-flight counter drift defect.

increment_counter()/decrement_counter() in app/core/cache.py used to be a
non-atomic GET -> modify in Python -> SET. Under concurrency, two callers
could read the same starting value before either wrote it back, silently
losing an increment. See EVIDENCE_redis_counter_drift.md for the original
reproduction (920 of 1000 increments lost) and the fix (Redis INCR/DECR).

This test proves the current implementation does not drift under the same
kind of concurrency, using a shared in-memory fake Redis server driven by
real OS threads with realistic latency injected around each command so the
race window this bug needs is actually exercised.
"""
import threading
import time

import fakeredis
import pytest

import app.core.cache as cache_module


class LatencyInjectedRedis(fakeredis.FakeRedis):
    """Widens the GET/SET window to the size a real network round trip
    would produce, so a non-atomic implementation would reliably drift."""

    def get(self, *args, **kwargs):
        result = super().get(*args, **kwargs)
        time.sleep(0.0005)
        return result


@pytest.fixture
def fake_cache_client(monkeypatch):
    server = fakeredis.FakeServer()
    client = LatencyInjectedRedis(server=server, decode_responses=True)
    monkeypatch.setattr(cache_module, "_client", client)
    return client


def test_increment_counter_does_not_drift_under_concurrency(fake_cache_client):
    key = "jobs:test_counter"
    n_threads = 50
    increments_per_thread = 20
    expected = n_threads * increments_per_thread

    def worker():
        for _ in range(increments_per_thread):
            cache_module.increment_counter(key)

    threads = [threading.Thread(target=worker) for _ in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert int(fake_cache_client.get(key)) == expected


def test_decrement_counter_does_not_drift_under_concurrency(fake_cache_client):
    key = "jobs:test_counter_down"
    n_threads = 50
    decrements_per_thread = 20
    fake_cache_client.set(key, n_threads * decrements_per_thread)

    def worker():
        for _ in range(decrements_per_thread):
            cache_module.decrement_counter(key)

    threads = [threading.Thread(target=worker) for _ in range(n_threads)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert int(fake_cache_client.get(key)) == 0
