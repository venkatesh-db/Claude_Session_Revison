import pytest

from app.models.customer import Customer
from app.models.inventory import Inventory
from app.models.order import Order, OrderItem
from app.models.product import Product
from app.services.order_service import (
    OrderNotFoundError,
    OrderStateError,
    fulfill_order,
)


def _seed_order(db_session, status="confirmed", quantity=2):
    customer = Customer(
        email=f"unit-{status}-{quantity}@example.com",
        hashed_password="x",
        full_name="Unit Buyer",
    )
    product = Product(sku=f"SKU-U-{status}-{quantity}", name="Thing", price_cents=1000)
    db_session.add_all([customer, product])
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=10, quantity_reserved=quantity))

    order = Order(
        customer_id=customer.id,
        status=status,
        total_cents=1000 * quantity,
        shipping_address="1 Test Way",
        idempotency_key=f"unit-{status}-{quantity}",
    )
    db_session.add(order)
    db_session.flush()
    db_session.add(
        OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=quantity,
            unit_price_cents=1000,
        )
    )
    db_session.commit()
    return order


def test_fulfill_order_sets_status_fulfilled(db_session, monkeypatch):
    from app.services import order_service

    monkeypatch.setattr(order_service.sync_inventory_levels, "delay", lambda order_id: None)
    order = _seed_order(db_session)

    result = fulfill_order(db_session, order_id=order.id)

    assert result.status == "fulfilled"


def test_fulfill_order_enqueues_sync_after_commit(db_session, monkeypatch):
    from app.services import order_service

    calls = []
    monkeypatch.setattr(
        order_service.sync_inventory_levels, "delay", lambda order_id: calls.append(order_id)
    )
    order = _seed_order(db_session, quantity=3)

    fulfill_order(db_session, order_id=order.id)

    assert calls == [order.id]


def test_fulfill_order_second_call_is_a_noop(db_session, monkeypatch):
    from app.services import order_service

    calls = []
    monkeypatch.setattr(
        order_service.sync_inventory_levels, "delay", lambda order_id: calls.append(order_id)
    )
    order = _seed_order(db_session, quantity=4)

    fulfill_order(db_session, order_id=order.id)
    fulfill_order(db_session, order_id=order.id)

    assert len(calls) == 1, "already-fulfilled order must not re-enqueue the decrement task"


def test_fulfill_order_rejects_non_fulfillable_status(db_session):
    order = _seed_order(db_session, status="cancelled", quantity=5)

    with pytest.raises(OrderStateError):
        fulfill_order(db_session, order_id=order.id)


def test_fulfill_order_raises_for_unknown_order(db_session):
    with pytest.raises(OrderNotFoundError):
        fulfill_order(db_session, order_id=987654)
