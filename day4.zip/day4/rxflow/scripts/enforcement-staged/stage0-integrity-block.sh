# ============================================================== stage 0: integrity
# FRAGMENT — not a standalone script. Paste into scripts/hooks/pre-commit
# immediately after this line:
#     echo "pre-commit: checking $(printf '%s\n' "$STAGED" | grep -c .) staged file(s)"
# and before the "# ---- 1. secrets" section. It relies on pre-commit's own
# red()/warn() helpers and its $STAGED variable, so it cannot run on its own.
#
# The gate must not be editable by the code it gates. Two checks:
#   (a) no commit may modify the hooks, the permission policy, the agent
#       definitions, or CODEOWNERS;
#   (b) the hooks on disk must still match their sealed checksums, so an
#       out-of-band edit (one made without committing) is caught too.
#
# Sealing a legitimate hook change is a repository-owner action: RXFLOW_HOOK_SEAL=1.

PROTECTED_RE='^(scripts/hooks/|\.claude/settings\.json$|\.claude/agents/|\.github/CODEOWNERS$)'
SEALING="${RXFLOW_HOOK_SEAL:-0}"

PROTECTED_HITS=$(printf '%s\n' "$STAGED" | grep -E "$PROTECTED_RE" || true)
if [ -n "$PROTECTED_HITS" ] && [ "$SEALING" != "1" ]; then
  red "pre-commit REFUSED: this commit modifies the enforcement layer."
  printf '%s\n' "$PROTECTED_HITS" | sed 's/^/         /'
  cat <<'GATEMSG'

These paths are read-only to developers and to Claude by policy: the gate cannot
be weakened by the change it is meant to inspect. Neither a prompt, a CLAUDE.md
edit, nor a project skill can authorise an exception — the deny rules in
.claude/settings.json are enforced by the tool layer, not by instructions.

If a hook genuinely needs to change, that is a repository-owner action:
  RXFLOW_HOOK_SEAL=1 git commit ...     then re-seal: bash scripts/hooks/seal.sh
and it must be reviewed by a CODEOWNER on the pull request.
GATEMSG
  exit 1
fi

MANIFEST="scripts/hooks/MANIFEST.sha256"
if [ -f "$MANIFEST" ] && [ "$SEALING" != "1" ]; then
  if command -v sha256sum >/dev/null 2>&1; then
    if ! sha256sum --quiet --check "$MANIFEST" 2>/dev/null; then
      red "pre-commit REFUSED: hook files no longer match their sealed checksums."
      sha256sum --check "$MANIFEST" 2>&1 | grep -v ': OK$' | sed 's/^/         /'
      echo
      echo "         A hook was altered outside the commit path. Restore it from"
      echo "         the last good revision, or re-seal as owner (RXFLOW_HOOK_SEAL=1)."
      exit 1
    fi
  else
    warn "sha256sum unavailable — hook integrity not verified this run."
  fi
fi

if [ "$SEALING" = "1" ]; then
  yell "  NOTE   RXFLOW_HOOK_SEAL=1 — enforcement-layer changes permitted for this commit."
  warn "This commit alters the gate itself and must be reviewed by a CODEOWNER."
fi
