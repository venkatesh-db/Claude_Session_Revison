# scripts/enforcement-staged/

Enforcement-layer pieces that could not be written to their final locations, because
`.claude/settings.json` denies `Write`/`Edit` on `scripts/hooks/**`, `.claude/agents/**` and
`.github/CODEOWNERS` — the deny rules that make the gate read-only apply to Claude too.

They live here, under version control, rather than in a session scratchpad: an earlier copy was
staged in a temp directory and **was deleted when the scratchpad was cleaned**, which broke the
install instructions in `missingproject.md` M2/M3. Do not move them back to a temp path.

## Applying them (repository owner)

    # 1. stage 0 is a FRAGMENT — paste it into scripts/hooks/pre-commit immediately
    #    after the `echo "pre-commit: checking N staged file(s)"` line.
    cat scripts/enforcement-staged/stage0-integrity-block.sh

    # 2. whole files
    cp scripts/enforcement-staged/post-commit scripts/hooks/post-commit
    cp scripts/enforcement-staged/seal.sh     scripts/hooks/seal.sh
    mkdir -p .github
    cp scripts/enforcement-staged/CODEOWNERS  .github/CODEOWNERS
    sed -i 's/@rxflow-owners/@your-real-team-handle/g' .github/CODEOWNERS
    chmod +x scripts/hooks/*

    # 3. activate and seal
    bash scripts/hooks/install.sh
    bash scripts/hooks/seal.sh

## Verify

    git config core.hooksPath                        # expect scripts/hooks
    sha256sum --check scripts/hooks/MANIFEST.sha256  # expect all OK

Once applied, these staged copies are redundant. Delete this directory in the same commit that
seals the manifest, so there is exactly one source of truth for each file.
