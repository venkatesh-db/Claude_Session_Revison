#!/usr/bin/env bash
# DESTINATION: scripts/hooks/seal.sh
#
# Re-seal the enforcement layer: record the checksums that pre-commit's stage 0
# verifies on every commit. Run this only after a deliberate, reviewed change to
# a hook, the permission policy, or an agent definition.
#
#   bash scripts/hooks/seal.sh
#
# The resulting MANIFEST.sha256 is itself protected, so committing it requires
# RXFLOW_HOOK_SEAL=1 and CODEOWNER review.

set -euo pipefail

cd "$(dirname "$0")/../.."

command -v sha256sum >/dev/null 2>&1 || {
  echo "error: sha256sum not found; cannot seal." >&2
  exit 1
}

MANIFEST="scripts/hooks/MANIFEST.sha256"

# Everything the gate depends on for its own integrity.
FILES=(
  scripts/hooks/pre-commit
  scripts/hooks/pre-push
  scripts/hooks/post-commit
  scripts/hooks/install.sh
  scripts/hooks/seal.sh
  .claude/settings.json
)
while IFS= read -r a; do FILES+=("$a"); done < <(find .claude/agents -type f -name '*.md' 2>/dev/null | sort)

{
  echo "# RxFlow enforcement-layer seal. Verified by pre-commit stage 0."
  echo "# Regenerate ONLY via scripts/hooks/seal.sh after a reviewed change."
  echo "# Sealed: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  for f in "${FILES[@]}"; do
    [ -f "$f" ] && sha256sum "$f"
  done
} > "$MANIFEST"

echo "sealed $(( $(grep -c . "$MANIFEST") - 3 )) file(s) -> $MANIFEST"
grep -v '^#' "$MANIFEST" | sed 's/^/  /'
echo
echo "commit it with:  RXFLOW_HOOK_SEAL=1 git commit -m 'reseal enforcement layer'"
