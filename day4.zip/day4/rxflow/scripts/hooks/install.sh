#!/usr/bin/env bash
# Point this repo's git hooks at scripts/hooks/ so they are version-controlled
# and every developer gets them from a clone, rather than living untracked in
# .git/hooks on one machine.
#
#   bash scripts/hooks/install.sh
#
# Undo with:  git config --unset core.hooksPath

set -euo pipefail

cd "$(dirname "$0")/../.."

if [ ! -d .git ]; then
  echo "error: this directory is not a git repository." >&2
  echo "       run 'git init' and make an initial commit first." >&2
  exit 1
fi

git config core.hooksPath scripts/hooks
chmod +x scripts/hooks/pre-commit scripts/hooks/pre-push 2>/dev/null || true

echo "installed: core.hooksPath -> scripts/hooks"
echo "  pre-commit  stage 1: deterministic gate (secrets, artifacts, drift, ruff)"
echo "              stage 2: release-readiness agent over the staged diff"
echo "  pre-push    release-readiness agent over the whole pushed range"
echo
echo "audit mode via RXFLOW_READINESS: blocking (commit default) | advisory | off"
echo "verify with:  git config core.hooksPath"

if ! command -v claude >/dev/null 2>&1; then
  echo
  echo "note: the 'claude' CLI is not on PATH, so the agent audit stages will"
  echo "      skip with a notice. The deterministic gate still applies."
fi
