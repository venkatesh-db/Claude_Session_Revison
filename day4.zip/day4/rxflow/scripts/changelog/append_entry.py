"""Append a per-commit entry to EVIDENCE_CHANGE_LOG.md.

Every commit is logged, at file granularity, including single-line changes. The
deterministic facts (sha, author, files, line counts, changed line ranges) come
from git and are always recorded. Classification and the plain-language summary
are AI-generated when the `claude` CLI is available, and fall back to a
transparent heuristic when it is not — the entry always states which was used,
so a reader can tell an inferred summary from a generated one.

Invoked automatically by the post-commit hook. Also usable directly:

    python scripts/changelog/append_entry.py                # log HEAD
    python scripts/changelog/append_entry.py --ref abc1234  # log one commit
    python scripts/changelog/append_entry.py --backfill     # log all history
    python scripts/changelog/append_entry.py --range A..B   # log a range

The log is append-only: entries are added at the end so concurrent branches
conflict as rarely as possible, and an already-logged sha is skipped rather
than duplicated.
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

LOG_PATH = Path("EVIDENCE_CHANGE_LOG.md")

# Ordered: the first pattern that matches the subject line wins.
_CLASSIFIERS: list[tuple[str, re.Pattern[str]]] = [
    ("DEFECT", re.compile(r"\b(fix|bug|defect|regress|broken|hotfix|patch|leak|crash)\b", re.I)),
    ("ENHANCEMENT", re.compile(r"\b(add|feat|feature|implement|introduce|support|enable)\b", re.I)),
    ("REFACTOR", re.compile(r"\b(refactor|rename|extract|simplify|tidy|cleanup|clean up)\b", re.I)),
    ("PERFORMANCE", re.compile(r"\b(perf|performance|optimi[sz]e|speed|cache|index)\b", re.I)),
    ("SECURITY", re.compile(r"\b(security|secret|credential|auth|token|redact|mask|pci)\b", re.I)),
    ("TEST", re.compile(r"\b(test|pytest|coverage|fixture)\b", re.I)),
    ("DOCS", re.compile(r"\b(doc|docs|readme|comment|changelog|onboarding)\b", re.I)),
    ("MIGRATION", re.compile(r"\b(migration|alembic|schema|column)\b", re.I)),
    ("CHORE", re.compile(r"\b(chore|bump|pin|deps|dependency|config|lint|format)\b", re.I)),
]

_HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")

_STATUS_LABELS = {
    "A": "added",
    "M": "modified",
    "D": "deleted",
    "R": "renamed",
    "C": "copied",
    "T": "type changed",
}


def git(*args: str) -> str:
    """Run a git command and return stdout, or raise with git's own stderr."""
    result = subprocess.run(
        ["git", *args], capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout


@dataclass
class FileChange:
    path: str
    status: str
    added: int = 0
    removed: int = 0
    old_path: str | None = None
    line_ranges: list[str] = field(default_factory=list)

    @property
    def status_label(self) -> str:
        return _STATUS_LABELS.get(self.status[:1], self.status)

    @property
    def is_single_line(self) -> bool:
        return self.added + self.removed == 1


@dataclass
class Commit:
    sha: str
    short: str
    author: str
    email: str
    date: str
    subject: str
    body: str
    branch: str
    files: list[FileChange]

    @property
    def total_added(self) -> int:
        return sum(f.added for f in self.files)

    @property
    def total_removed(self) -> int:
        return sum(f.removed for f in self.files)


def _changed_line_ranges(ref: str, path: str) -> list[str]:
    """Return the touched line ranges on the new side, e.g. ['22', '40-47']."""
    try:
        diff = git("show", "--format=", "--unified=0", ref, "--", path)
    except RuntimeError:
        return []

    ranges: list[str] = []
    for line in diff.splitlines():
        match = _HUNK_RE.match(line)
        if not match:
            continue
        start = int(match.group(3))
        count = int(match.group(4) or 1)
        if count == 0:  # pure deletion: point at the boundary
            ranges.append(f"{start}~")
        elif count == 1:
            ranges.append(str(start))
        else:
            ranges.append(f"{start}-{start + count - 1}")
    return ranges


def collect(ref: str) -> Commit:
    sep = "\x1f"
    fmt = sep.join(["%H", "%h", "%an", "%ae", "%aI", "%s", "%b"])
    raw = git("show", "--no-patch", f"--format={fmt}", ref)
    sha, short, author, email, date, subject, body = (raw.split(sep) + [""] * 7)[:7]

    try:
        branch = git("rev-parse", "--abbrev-ref", "HEAD").strip()
    except RuntimeError:
        branch = "(unknown)"

    changes: dict[str, FileChange] = {}

    # Status (and rename detection) first.
    status_out = git("show", "--format=", "--name-status", "-M", ref)
    for line in status_out.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        code = parts[0]
        if code.startswith(("R", "C")) and len(parts) >= 3:
            changes[parts[2]] = FileChange(path=parts[2], status=code, old_path=parts[1])
        elif len(parts) >= 2:
            changes[parts[1]] = FileChange(path=parts[1], status=code)

    # Then line counts.
    numstat = git("show", "--format=", "--numstat", "-M", ref)
    for line in numstat.splitlines():
        if not line.strip():
            continue
        added_s, removed_s, path = (line.split("\t") + ["", "", ""])[:3]
        if "=>" in path:  # rename form: old => new
            path = path.split("=>")[-1].strip().strip("}")
        entry = changes.get(path) or FileChange(path=path, status="M")
        entry.added = 0 if added_s == "-" else int(added_s or 0)
        entry.removed = 0 if removed_s == "-" else int(removed_s or 0)
        changes[path] = entry

    # The log records the code, not itself: an entry that lists
    # EVIDENCE_CHANGE_LOG.md is noise, since every commit after the first
    # carries the previous entry. Dropped here so line counts exclude it too.
    changes.pop(str(LOG_PATH), None)
    changes.pop(LOG_PATH.as_posix(), None)

    for path, change in changes.items():
        if change.status[:1] != "D":
            change.line_ranges = _changed_line_ranges(ref, path)

    return Commit(
        sha=sha.strip(),
        short=short.strip(),
        author=author.strip(),
        email=email.strip(),
        date=date.strip(),
        subject=subject.strip(),
        body=body.strip(),
        branch=branch,
        files=sorted(changes.values(), key=lambda f: f.path),
    )


def classify_heuristic(commit: Commit) -> tuple[str, str]:
    """Return (classification, rationale) from the subject and touched paths."""
    text = f"{commit.subject} {commit.body}"
    for label, pattern in _CLASSIFIERS:
        if pattern.search(text):
            return label, f"subject matched /{pattern.pattern}/"

    paths = [f.path for f in commit.files]
    if all(p.startswith("tests/") for p in paths):
        return "TEST", "all changed files are under tests/"
    if all(p.endswith((".md", ".txt")) for p in paths):
        return "DOCS", "all changed files are documentation"
    if any(p.startswith("migrations/") for p in paths):
        return "MIGRATION", "a migration file was touched"
    return "UNCLASSIFIED", "no classifier matched; review manually"


def classify_ai(commit: Commit, diff: str) -> tuple[str, str, str] | None:
    """Ask Claude to classify and summarise. Returns (label, summary, risk)."""
    if not shutil.which("claude"):
        return None

    prompt = f"""Classify and summarise this commit for an engineering change log.

Subject: {commit.subject}
Body: {commit.body or "(none)"}
Files: {", ".join(f.path for f in commit.files)}

Diff (truncated to 12000 chars):
{diff[:12000]}

Reply with exactly three lines and nothing else:
CLASS: one of DEFECT, ENHANCEMENT, REFACTOR, PERFORMANCE, SECURITY, TEST, DOCS, MIGRATION, CHORE
SUMMARY: one sentence on what changed and why it matters, in plain language
RISK: one short clause naming what could break, or "none identified"
"""
    try:
        result = subprocess.run(
            ["claude", "-p", prompt, "--allowedTools", ""],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None

    out = result.stdout
    label = summary = risk = ""
    for line in out.splitlines():
        line = line.strip()
        if line.upper().startswith("CLASS:"):
            label = line.split(":", 1)[1].strip().upper()
        elif line.upper().startswith("SUMMARY:"):
            summary = line.split(":", 1)[1].strip()
        elif line.upper().startswith("RISK:"):
            risk = line.split(":", 1)[1].strip()

    valid = {lbl for lbl, _ in _CLASSIFIERS}
    if label not in valid or not summary:
        return None
    return label, summary, risk or "none identified"


def render(commit: Commit, diff: str, use_ai: bool) -> str:
    ai = classify_ai(commit, diff) if use_ai else None
    if ai:
        label, summary, risk = ai
        source = "AI-generated (`claude -p`)"
    else:
        label, rationale = classify_heuristic(commit)
        summary = commit.subject or "(no commit subject)"
        risk = "not assessed"
        source = f"heuristic — {rationale}"

    single = sum(1 for f in commit.files if f.is_single_line)
    scale = f"{len(commit.files)} file(s), +{commit.total_added} / -{commit.total_removed}"
    if single:
        scale += f", {single} of them a single-line change"

    lines: list[str] = [
        "",
        "---",
        "",
        f"## `{commit.short}` — {label} — {commit.subject or '(no subject)'}",
        "",
        f"- **Commit**: `{commit.sha}`",
        f"- **Author**: {commit.author} <{commit.email}>",
        f"- **Date**: {commit.date}",
        f"- **Branch**: {commit.branch}",
        f"- **Scale**: {scale}",
        f"- **Classification source**: {source}",
        "",
        f"**Summary.** {summary}",
        "",
        f"**Risk.** {risk}",
        "",
    ]

    if commit.body:
        lines += ["**Commit message body.**", "", "```", commit.body, "```", ""]

    lines += [
        "### Files changed",
        "",
        "| File | Change | +/- | Lines touched |",
        "|---|---|---|---|",
    ]
    for f in commit.files:
        ranges = ", ".join(f.line_ranges) if f.line_ranges else "—"
        if len(ranges) > 80:
            ranges = ranges[:77] + "…"
        name = f"`{f.path}`"
        if f.old_path:
            name = f"`{f.old_path}` → `{f.path}`"
        lines.append(f"| {name} | {f.status_label} | +{f.added} / -{f.removed} | {ranges} |")
    lines.append("")

    return "\n".join(lines)


_HEADER = """# EVIDENCE — Change Log

Append-only record of every commit in this repository, at file granularity,
including single-line changes. Generated by `scripts/changelog/append_entry.py`,
invoked from the `post-commit` hook.

Each entry records the commit identity and the deterministic facts from git
(files, statuses, line counts, touched line ranges). The classification and
summary are AI-generated where the `claude` CLI was available and fall back to a
stated heuristic otherwise — every entry names which was used, so an inferred
summary is never mistaken for a generated one.

**Do not edit past entries.** Corrections belong in a new commit, so the log
stays an audit trail rather than a document.

`Lines touched` gives ranges on the new side of the diff; `N~` marks a pure
deletion at that boundary.
"""


def already_logged(sha: str) -> bool:
    if not LOG_PATH.exists():
        return False
    return sha in LOG_PATH.read_text(encoding="utf-8")


def append(commit: Commit, diff: str, use_ai: bool) -> bool:
    if already_logged(commit.sha):
        return False
    if not LOG_PATH.exists():
        LOG_PATH.write_text(_HEADER, encoding="utf-8")
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(render(commit, diff, use_ai))
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ref", default="HEAD", help="commit to log (default HEAD)")
    parser.add_argument("--range", dest="rng", help="log every commit in a range, e.g. A..B")
    parser.add_argument("--backfill", action="store_true", help="log all history, oldest first")
    parser.add_argument("--no-ai", action="store_true", help="skip AI, use the heuristic only")
    args = parser.parse_args()

    try:
        git("rev-parse", "--git-dir")
    except RuntimeError:
        # ASCII only: this goes to a Windows console, which mangles em dashes.
        print("append_entry: not a git repository - nothing to log.", file=sys.stderr)
        return 0

    if args.backfill:
        refs = git("rev-list", "--reverse", "HEAD").split()
    elif args.rng:
        refs = git("rev-list", "--reverse", args.rng).split()
    else:
        refs = [args.ref]

    use_ai = not args.no_ai
    written = skipped = 0
    for ref in refs:
        commit = collect(ref)
        diff = git("show", "--format=", "-M", ref)
        if append(commit, diff, use_ai):
            written += 1
            print(f"change log: recorded {commit.short} [{commit.subject[:60]}]")
        else:
            skipped += 1

    if skipped:
        print(f"change log: {written} recorded, {skipped} already present")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
