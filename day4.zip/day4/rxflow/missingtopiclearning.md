# missingtopiclearning.md — Prompt, execute, learn

A learning companion to `missingproject.md`. That file says *how to build* each missing thing by
hand. This one says **what to type**, **what happens when you do**, and **what you should
understand afterwards** — so closing the gap also teaches the mechanism behind it.

One section per topic, M1–M18, in the order they should be done.

---

## How to use this file

Each topic has four parts:

| Part | What it is |
|---|---|
| **Prompt** | copy-pasteable text to give Claude. Written to be specific enough to act on without a follow-up question. |
| **Execute** | what actually happens, and the command that proves it. |
| **Learn** | the transferable concept — the reason this topic exists, not just its fix. |
| **Check yourself** | a question you should be able to answer afterwards. If you can't, the topic isn't closed. |

### The prompting pattern underneath all of them

Every prompt below follows the same five-part shape. Learn the shape and you stop needing the
prompts:

1. **Name the target precisely** — `app/config.py:18`, not "the config".
2. **State the constraint** — what must stay true, what must not change.
3. **Demand evidence** — "paste the real command output", not "make sure it works".
4. **Bound the scope** — "do not touch `app/`", "one file only".
5. **Ask for the failure mode** — "tell me what you could not verify".

Point 5 is the one people leave out, and it is the one that separates a report you can trust from
one you cannot.

### Before you start

A prompt is **ephemeral** — it dies with the session. That is the right shape for a one-time task
and the wrong shape for anything you will type twice. When you notice yourself reusing a prompt
below, that is the signal to turn it into a slash command or a Skill (M12).

**Read Appendix A first if you only have ten minutes.** It is a transcript of the pass that
verified this file, with the real commands and real output — including the five defects it found
*in this file*. The method it demonstrates matters more than any single topic below.

---

## M1 — Version control

### Prompt

    This project has no .git. Initialise it:
    1. First append test_rxflow.db and lenskart-demo/**/*.db to .gitignore.
    2. git init, then git add -A, then SHOW ME git status BEFORE committing —
       I want to see exactly what would land.
    3. After I approve, commit as "initial commit: RxFlow order-management backend".
    4. Then backfill the change log:
       python scripts/changelog/append_entry.py --backfill --no-ai

    Do not install hooks yet — that is a separate step.

### Execute

    git log --oneline | head
    git status --short              # expect no *.db, no .env
    grep -c '^## `' EVIDENCE_CHANGE_LOG.md

### Learn

**Ordering is a correctness property, not a preference.** `.gitignore` has to land before the
first `git add -A`, because git tracks a file once added and removing it later leaves it in
history forever. This is the same class of mistake as running a migration before its backfill.

Also learn *why* this topic sits first: four of the eight Claude Code mechanisms are triggered by
a git event. Without a repository they are not "partially working" — they cannot fire at all. When
a plan has an item that unblocks five others, that item is not one of six equal priorities.

### Check yourself

Why does the prompt insist on seeing `git status` before the commit rather than after?

---

## M10 — `.env.example` and the gitignore hole

*(Done as part of M1 step 1, but the concept is separate and worth naming.)*

### Prompt

    Create .env.example documenting every environment variable app/config.py reads.
    Read config.py first — do not guess the list. Leave JWT_SECRET empty and mark it
    required outside development. Never put a real secret in the example file.

### Execute

    git check-ignore -v test_rxflow.db     # expect a match

    # Compare the documented vars against the ones config.py actually reads.
    # Match quoted UPPER_SNAKE literals, NOT `os.environ.get("X"` — three of the
    # six calls in config.py wrap across lines, so a single-line pattern silently
    # misses DATABASE_URL, CELERY_BROKER_URL and CELERY_RESULT_BACKEND.
    diff <(grep -oE '^[A-Z][A-Z_]+' .env.example | sort -u)          <(grep -oE '"[A-Z][A-Z_]{2,}"' app/config.py | tr -d '"' | sort -u)

### Learn

**Configuration is an interface, and an undocumented interface is a defect.** Right now the only
record of what RxFlow needs to run is the source of `config.py`. A new developer discovers a
missing variable by hitting a bug, not by reading a file.

The deeper lesson is in the `diff` above: an example file that drifts from the code is worse than
none, because it is trusted. Anything that duplicates a fact needs a check that the copies agree.

### Check yourself

What breaks if `.env.example` lists a variable that `config.py` no longer reads?

---

## M6 — The three security blockers

### Prompt

    Fix three security defects. For each, show me the diff before applying it.

    1. app/clients/payment_gateway_client.py:22 logs the whole payload at DEBUG, and
       the payload contains an unmasked card_number. Remove it. If the diagnostic is
       still wanted, log only order_id, amount_cents and card_last4 by name.
    2. app/config.py:18 — jwt_secret defaults to "dev-secret-change-me".
    3. app/config.py:7 — database_url defaults to SQLite.

    For 2 and 3, add a pydantic model_validator(mode="after") to Settings that raises
    when environment != "development" and the value is still the default. A missing
    env var must be a startup failure, not a silently working app.

    Then run pytest -q and paste the real output. Tell me if any test relied on the
    old defaults.

### Execute

    # Scope to the logging call: the `payload` dict itself is legitimate and stays.
    grep -n 'logger.*payload' app/clients/payment_gateway_client.py   # expect nothing
    RXFLOW_ENV=production python -c "import app.config"        # expect ValueError
    RXFLOW_ENV=test python -c "import app.config; print('ok')" # expect ok
    pytest -q

### Learn

**Fail-open versus fail-closed is the whole lesson here.** `os.environ.get("JWT_SECRET",
"dev-secret-change-me")` fails *open*: a deploy missing the variable does not crash, it runs and
signs tokens with a value published in the repository. Anyone can then mint an admin token. A
crash on startup would have been the safe failure.

The card-number log teaches a second thing: **the sensitive value was never on the logging line.**
It was inside a dict the line happened to log. Any check that greps for `card_number` near
`logger.` misses it entirely — which is exactly what happened when the pre-commit rule was first
written and had to be tightened to block whole-container logging.

### Check yourself

Why is `logger.debug` still dangerous when DEBUG is off in production?

---

## M2 — The staged hook files

### Prompt

    Install the enforcement layer. the pieces are staged at scripts/enforcement-staged/
    because .claude/settings.json denies writes to scripts/hooks/**, so I will apply
    them myself — walk me through it:

    1. Show me the stage-0 block and tell me exactly where in scripts/hooks/pre-commit
       it goes and why it must be first.
    2. Tell me what seal.sh does and why the manifest exists at all when the deny
       rules already block edits.
    3. After I run install.sh and seal.sh, give me a test that proves the gate
       actually refuses a tampered hook — on a throwaway branch.

### Execute

    git config core.hooksPath                        # expect scripts/hooks
    sha256sum --check scripts/hooks/MANIFEST.sha256  # expect all OK

    git checkout -b hook-test
    echo '# tamper' >> scripts/hooks/pre-commit
    git add -A && git commit -m "should be refused"  # expect exit 1 at stage 0
    git checkout -- . && git checkout - && git branch -D hook-test

### Learn

**Defence in depth means each layer covers a different bypass.** Three layers guard the same
files and none is redundant:

| Layer | Stops | Bypassed by |
|---|---|---|
| `.claude/settings.json` deny rules | Claude editing the hooks, however instructed | deleting the settings file |
| stage 0 protected-path refusal | a commit that includes hook changes | `--no-verify` |
| `MANIFEST.sha256` | an edit made *outside* the commit path | re-sealing |
| CODEOWNERS (M3) | a weakened gate reaching main | nothing local |

Stage 0 must run **first** for a cost reason: an obvious blocker should fail the commit before any
tokens are spent on the AI audit in stage 2. Cheap checks precede expensive ones — the same
principle as short-circuit evaluation.

The manifest exists because the deny rules only bind *Claude*. A developer editing a hook in their
editor triggers no tool call at all.

### Check yourself

If the deny rules block edits to `scripts/hooks/**`, why is the checksum manifest not redundant?

---

## M3 — CODEOWNERS and branch protection

### Prompt

    Set up CODEOWNERS and tell me what to configure on the forge. Then answer this
    honestly: after branch protection is on, what can a determined developer with
    write access to their own clone still do to the local gate — and does it matter?

    Include CLAUDE.md and .claude/skills/ in the owned paths, and explain in one
    sentence why instruction files belong there.

### Execute

Open a pull request touching `scripts/hooks/pre-commit` from a non-owner account. It must not be
mergeable without an owner approval.

### Learn

**Only server-side controls are binding.** Everything local is advisory in the end: a developer
can delete the settings file, unset `core.hooksPath`, or use a different git client. That does not
make local layers worthless — they catch accidental and *instructed* modification, which is most
of the real risk — but they are fast feedback, not a guarantee.

The subtle part is why `CLAUDE.md` and `.claude/skills/` are owned paths. They contain
*instructions*. A developer who can rewrite the instructions can tell Claude to weaken the gate,
so protecting the hooks while leaving the instructions open protects nothing. **The threat model
determines the boundary, not the file type.**

### Check yourself

Why can an instruction file never be the thing that enforces a rule on the person who can edit it?

---

## M4 — CI pipeline

### Prompt

    Create .github/workflows/gates.yml with three jobs:

    - static: ruff check ., mypy app, pytest -q
    - migrations: a postgres:15 service, then run
      tests/integration/test_migrations_apply_live_db.py with RXFLOW_LIVE_DB_URL set
    - hooks: bash -n the hook scripts, and sha256sum --check the manifest

    Do NOT mark mypy as a required check — it currently fails with 4 errors, so it
    would block every PR. Tell me which checks are safe to require today and which
    must wait for M7.

### Execute

Push the branch. Confirm three jobs appear, and that `migrations` **runs** the test rather than
reporting it skipped.

### Learn

**A skipped test is not a passing test.** `test_migrations_apply_live_db.py` is `skipif`-guarded
on `RXFLOW_LIVE_DB_URL`, so locally `pytest -q` is green while proving nothing about the Alembic
chain. The `migrations` job exists solely to make that skip impossible.

Same shape elsewhere in this repo: integration tests build schema with `create_all` (so they never
see the deployed schema) and run on SQLite, where `SELECT ... FOR UPDATE` is a **no-op** — so every
row-lock test passes without locking anything. **Ask what a green suite does not cover, not just
whether it is green.**

And note the sequencing: adding a failing check as *required* makes CI a wall instead of a gate.
Make it green first (M7), then require it.

### Check yourself

Name two things this repository's passing test suite does not prove.

---

## M5 — The `claude` CLI

### Prompt

    The claude CLI is not on PATH, so pre-commit stage 2 and pre-push both skip their
    audit with a notice and exit 0. Before I trust the hook path, I want the agent
    proven standalone.

    Give me the exact command to run the release-readiness agent headlessly, then a
    smoke test that shows stage 2 producing a verdict block instead of a skip notice.

### Execute

    claude --version
    claude -p "Use the release-readiness agent to audit this repository. Be brief." \
      --allowedTools "Read,Grep,Glob,Bash"

    RXFLOW_READINESS=advisory git commit --allow-empty -m "audit smoke test"

### Learn

**"Wired" and "proven" are different claims, and conflating them is how false confidence gets
built.** Both hooks contain a correct `claude -p` invocation. Neither has ever executed, because
the CLI is absent and the code takes the graceful-degradation branch every time.

The degradation itself is a deliberate design choice worth copying: a missing dependency in a
*recording* or *advisory* step must never cost someone their commit, so it prints and exits 0. But
graceful degradation has a cost — **a silent skip looks exactly like a pass.** That is why the
notice is printed rather than swallowed.

### Check yourself

Your CI shows green. How would you tell the difference between "the audit passed" and "the audit
never ran"?

---

## M7 — Green the gates

### Prompt

    make lint fails with 10 errors and make typecheck fails with 4. Fix them, but
    read each one before deciding how:

    - The E402s in tests/conftest.py are DELIBERATE — env vars must be set before the
      app import. Do not reorder the imports. Add a per-file ignore with a comment
      explaining why the order is load-bearing.
    - For the 4 mypy errors in app/core/cache.py, narrow the types at the boundary.
      Do not add a blanket module-level ignore.

    Then paste real ruff and mypy output, and confirm the pytest pass count is unchanged.

### Execute

    ruff check .        # expect clean
    mypy app            # expect "Success: no issues found"
    pytest -q           # expect unchanged pass count

### Learn

**Not every lint error is a defect — some are the linter being wrong about your code.** The
`conftest.py` E402 is the clearest example in this repo: the import order is *load-bearing*,
because `RXFLOW_ENV` and `DATABASE_URL` must be set before the app module is imported. "Fixing"
it by reordering would break the test suite. The correct fix is to record the exception, with the
reason, so the next person does not re-fix it.

The mypy fix teaches the counterpart: a blanket `# type: ignore` on the module hides the four
known errors *and* every future one. **Narrow at the boundary; never silence the whole surface.**

And the meta-lesson: `make typecheck` has never been green in this project's life, which means it
has never been a gate. A check nobody can pass is decoration.

### Check yourself

What is the difference in blast radius between a per-file ignore and a module-level `type: ignore`?

---

## M8 — Documentation that is now wrong

### Prompt

    CLAUDE.md now requires skills and agents to be reviewed whenever a documented
    workflow changes. That rule is currently unmet — find and fix the drift:

    .claude/skills/api-flow/SKILL.md:90 says sync_inventory_levels has no caller and
    "fulfillment is unwired". That became false when POST /orders/{order_id}/fulfill
    was added. Replace it with the two gaps that ARE still true.

    Then add the fulfillment step to CLAUDE.md and ONBOARDING.md: staff-only,
    confirmed -> fulfilled, re-fulfilment is a no-op, and it is what finally invokes
    sync_inventory_levels.

    Finish by grepping for 'unwired' and showing me zero hits.

### Execute

    grep -n 'fulfill' CLAUDE.md .claude/skills/api-flow/SKILL.md ONBOARDING.md
    grep -n 'unwired' .claude/skills/api-flow/SKILL.md    # expect no hits

### Learn

**A stale instruction is worse than a missing one, because it is trusted.** A skill that omits a
fact makes the next session go and read the code. A skill that states a *wrong* fact makes the
next session confidently act on it. `api-flow` currently tells every future session that
fulfillment is unwired — and it will believe that instead of checking.

This is the specific reason CLAUDE.md carries a sync rule. Documentation is a **cache** of facts
about the code, and every cache needs an invalidation policy. Shipping the feature is not the end
of the change; the docs and the skills are part of the same change.

### Check yourself

Which is more dangerous to a future session: a skill that omits a fact, or one that asserts a
fact that used to be true?

---

## M9 — README.md

### Prompt

    Write a README.md for a fresh clone. Keep it pointer-shaped — the detail already
    exists elsewhere, do not duplicate it. One paragraph on what RxFlow is, the run
    commands, the three gates, then links to ONBOARDING.md, CLAUDE.md,
    EVIDENCE_GAPS.md, missingproject.md and EVIDENCE_CHANGE_LOG.md, saying who each
    is for. Close with the warning that integrations are mocked.

### Learn

**Documents need an audience each, and a front door.** This repo has four markdown files and no
entry point, so all of them are discovered by already knowing they exist.

The audience split matters more than the count: `CLAUDE.md` is loaded automatically into every
Claude session; `ONBOARDING.md` is for a human joining the team and is **never** auto-loaded.
Duplicating content between them is how they drift apart. A pointer costs nothing to keep true.

### Check yourself

Why is duplicating architecture prose across README, CLAUDE.md and ONBOARDING.md a liability?

---

## M11 — The dangling evidence pointer

### Prompt

    app/core/cache.py:50 points readers at EVIDENCE_redis_counter_drift.md, which does
    not exist. Pick one and do it: either write the file — the get/modify/set counter
    drift reproduction and why INCR fixes it — or delete the reference. Tell me which
    you chose and why.

### Learn

**A reference to a missing artifact costs the reader more than silence.** The docstring is
otherwise excellent: it explains that an earlier version did GET / modify in Python / SET, that it
drifted under concurrency, and that `INCR` is atomic server-side. Then it points at a file that
does not exist, so every reader who wants the detail spends time searching for nothing.

Broken links are a class of defect, not an untidiness. The fix is cheap in both directions — which
is why leaving it is the only wrong answer.

### Check yourself

Why is deleting the reference an acceptable fix, and not a cop-out?

---

## M12 — Slash commands

### Prompt

    Create .claude/commands/ with three commands:

    - /gates — run ruff, mypy and pytest, and report ONLY deltas from the known
      baseline (ruff 10, mypy 4 in cache.py, pytest green). State explicitly when a
      pre-existing failure is now fixed.
    - /drift — compare model columns against what the Alembic chain produces, in both
      directions. Seed it with the known case: inventory.reorder_threshold.
    - /changelog — run append_entry.py --range $ARGUMENTS.

    Keep each one short and fixed. If a command needs judgement at each step, tell me
    and I will make it a Skill instead.

### Execute

Type `/gates` in a session and confirm it resolves.

### Learn

**Match the mechanism to the shape of the work.** This is the whole taxonomy in one decision:

| The work | The mechanism |
|---|---|
| short, fixed, no branching | slash command |
| multi-step, needs judgement at each step | Skill |
| must fire whether or not anyone remembers | hook |
| bounded investigation, own context | sub-agent |

`/gates` is a command because it is three commands and a diff. `api-new` is a Skill because
"write an endpoint in the house style" requires reading a sibling, choosing an auth level, and
deciding whether a migration is needed. Building the first as a Skill would be over-engineering;
building the second as a command would produce generic FastAPI code.

The `--baseline` detail is the real craft here: a command that prints 14 pre-existing failures
every time trains you to ignore its output.

### Check yourself

`/gates` versus a Skill that runs the gates — what makes the command the right choice?

---

## M13 — An MCP server

### Prompt

    Ten claude.ai connectors are listed for this session and none is authenticated.
    Explain what I have to do outside this session to authorise one, and then tell me
    concretely where an MCP connection would improve something that already exists in
    this repo. Do not ask me for a token or a callback URL.

### Learn

**MCP is for state that lives outside the working tree.** Everything else here — the code, the
migrations, the hooks — is in the repo, so file tools reach it. The issue tracker, the error
monitor and the deploy log are not, and no amount of reading files will produce them.

The concrete payoff in this project is the change log. It classifies each commit as DEFECT or
ENHANCEMENT by regex-matching the commit *message* — so "fix" means defect and "add" means
enhancement. That is a guess dressed as a fact. A tracker connection would let it cite the actual
ticket.

Also learn the boundary: authorisation is interactive by design. A session that cannot run an
OAuth flow should say so and stop, not ask you to paste a credential into a chat.

### Check yourself

Why can a fetch tool read a public page without being MCP? What is MCP giving you that it isn't?

---

## M14 — Run the release-readiness agent

### Prompt

    Use the release-readiness agent to audit this repository.

    Afterwards, compare its findings against EVIDENCE_GAPS.md Part E and tell me:
    what did it find that the register missed, what did the register have that it
    missed, and did any of its checks misfire?

### Execute

Expect **NO-GO**, on the M6 blockers at minimum. That is the agent working correctly.

### Learn

**An unrun agent is an untested one.** The definition has existed for a while, has a detailed
checklist and a fixed output format, and has never executed once. Every claim in it is a
hypothesis: the greps might not match, the baseline counts might be stale, a check might fire on
every commit and get ignored.

The comparison step is the actual lesson. Two independent passes over the same codebase — a
handwritten register and an agent's audit — will disagree, and **the disagreements are the
findings**. Anything only the agent saw is a gap in your understanding; anything only you saw is a
gap in its checklist.

### Check yourself

Why is "the agent reported NO-GO" evidence that it works, rather than evidence of a problem?

---

## M15 — Close out the demo build

### Prompt

    lenskart-demo/frontend/ and lenskart-demo/backend/ each pass their own gates but
    have never run together. Close it out:

    1. Add weight, collection, face_shape and occasion as real filter params — they
       were omitted from the API contract, so the backend returns counts for them but
       rejects them as filters.
    2. Start both servers, set USE_MOCK = false, and verify the field names the page
       expects match what the API actually emits.
    3. Tell me anything you still could not verify and why.

### Learn

**A shared contract makes parallel work possible and makes integration failure invisible.** Two
agents built these halves concurrently from one written contract. Both passed their own tests.
Neither has ever spoken to the other, so "the halves fit" is an *inference from the contract*, not
an observation.

The four missing facets show the failure mode precisely. They were absent from the contract, so
each side improvised — the backend counts them but won't filter on them; the frontend derives them
client-side. Both are individually reasonable. Together they are a feature that silently does
nothing. **When you parallelise, the contract becomes the single point of failure, and a gap in it
appears as two correct halves that do not compose.**

Both agents flagged it independently, which is the useful signal: when isolated workers report the
same gap, the gap is in the brief.

### Check yourself

Two components each pass their own tests. What have you actually proven about the system?

---

## M16 — Enforcement decisions still open

### Prompt

    Five decisions are open in missingproject.md M16. For each, give me the argument
    on both sides and your recommendation — do not just implement your preference.

    Pay attention to 4 and 5: releasing quantity_reserved on cancel, and adding a row
    lock to decrement_stock_on_fulfillment. Both change existing behaviour. Tell me
    what would break if you are wrong.

### Learn

**Some things are not gaps to close but trade-offs to own.** Whether the audit blocks commits or
only advises is not a technical question — it depends on how much friction ten developers will
tolerate before they start using `--no-verify`, and nobody outside your team can answer that.

Items 4 and 5 teach the sharper version: they are *correct* fixes that change behaviour other code
may depend on. Cancelling currently strands stock forever; releasing it is obviously better, and
also a change in what a cancel does. Raising the concern and deferring the change is the right
move — quietly changing semantics because the fix is one line is not.

This is also the lesson recorded from earlier in this project: a cost or latency concern is worth
raising in a sentence, but it is the owner's trade-off to make, not something to resolve by
silently scaling the request down.

### Check yourself

Which of the five is genuinely a judgement call, and which are just unfinished work wearing a
question mark?

---

## M17 — Webhook ingestion is entirely unwired

### Prompt

    Something in this repo is a complete vertical slice with no entry point. Confirm it
    first, do not take my word for it:

      grep -rn 'reconcile_payment_webhook' app/
      grep -rn 'webhook' app/api/

    You should find a WebhookEvent model, a migration that creates the table, and a
    Celery task that marks events processed — and no route, and no caller.

    Then use the api-new skill to add POST /webhooks/payment. Before writing code, tell
    me how you will handle: (a) auth, given a gateway cannot send our JWT; (b) replay,
    given gateways retry and the table has no gateway-event-id column; (c) a payload
    larger than payload_raw's String(4000).

### Execute

    grep -rn 'reconcile_payment_webhook' app/     # expect a caller, not just the decorator
    grep -rn 'webhook' app/api/                   # expect a route
    pytest tests/integration/test_webhooks.py -q

### Learn

**An unreachable feature looks finished from every angle except the one that matters.** The model
is well formed, the migration applies, the task is written, the tests pass. Nothing is broken.
There is simply no way in.

Two habits find this class of defect, and both are cheap:

1. **For every model, ask what writes a row.** For every task, ask what enqueues it. A definition
   with no producer is dead code wearing a feature's clothes.
2. **Grep for callers, not for definitions.** `grep -rn 'reconcile_payment_webhook' app/` matching
   only its own decorator line is the whole finding, in one command.

The honest part of this topic: it was **absent from the first version of all three gap documents**,
including the one that claimed full coverage. I had already found and fixed the identical defect —
`sync_inventory_levels` had no caller — and then did not check whether the other two tasks had the
same problem. Finding a bug is not the same as finding its class.

### Check yourself

`sync_inventory_levels` and `reconcile_payment_webhook` had the same defect. What should have been
done after fixing the first one?

---

## M18 — Float arithmetic on a money value

### Prompt

    CLAUDE.md, ONBOARDING.md and the api-new skill all state that money in this project
    is integer cents, never floats. Find every place that rule is actually broken:

      grep -rn 'cents *[/*]' app/ | grep -v '//'

    That grep finds TWO sites, not one:
      - app/services/notification_service.py:16 — total_cents / 100 in an f-string
        (display only). Fix with divmod and integer formatting. It also hardcodes a
        dollar sign while this project quotes rupees — tell me which is correct first.
      - app/clients/tax_client.py:13 — int(subtotal_cents * 0.08). This one COMPUTES a
        money value through a float and truncates. Redo it in integers and tell me
        explicitly which rounding rule you chose and who it favours.

    Then tell me: what would have caught this that the three documents did not?

### Execute

    grep -rn 'cents *[/*]' app/ | grep -v '//'     # expect no float division
    pytest -q

### Learn

**A stated invariant is only real if something enforces it.** "Money is integer cents" is written
in three places in this project and was still violated in **two** files — and the second was
found only by running the grep, after the first version of this section confidently named one.
Documentation records an intention; it does not apply it. Neither does a fix you did not verify
was complete.

The defect is also instructive in its smallness. `total_cents / 100` is display-only — no stored
value is corrupted — so it never causes a test failure. But `/ 100` produces a binary float and
`:.2f` rounds half-to-even, so some totals render a cent away from what the customer was actually
charged. **The bug is invisible in aggregate and infuriating in individual cases**, which is the
worst combination for getting it prioritised.

The answer to the prompt's last question is a one-line grep in the pre-commit gate. Rules that
matter belong in the mechanism that fires whether or not anyone remembers (M2) — not only in the
document that describes them.

### Check yourself

Why did no test fail on this? `tests/unit/test_tax_client.py` exists — what must it be asserting
for `int(subtotal_cents * 0.08)` to pass it?

---

## What the eighteen topics teach together

Ordered by how often the mistake recurs, not by topic number.

1. **Ordering can be a correctness property.** `.gitignore` before `git add`; green a check before
   requiring it; cheap gates before expensive ones. (M1, M2, M4)
2. **Fail closed, not open.** A missing config value should stop the app, not produce a working
   one signed with a public secret. (M6)
3. **A skipped or degraded step looks exactly like a passing one.** Skipped tests, absent CLIs,
   swallowed Redis errors. Always ask what green does not cover. (M4, M5)
4. **Stale beats missing, and not in a good way.** A wrong instruction is acted on; an absent one
   sends the reader to the source. (M8, M10, M11)
5. **Only server-side controls bind.** Local layers are fast feedback. Know which is which. (M3)
6. **Match the mechanism to the shape of the work.** Command, Skill, hook, sub-agent, MCP — each
   has one shape it fits. (M12, M13)
7. **The contract is the single point of failure when you parallelise.** Two correct halves that
   do not compose. (M15)
8. **Raise the trade-off; do not resolve it silently.** (M16)
9. **Untested tooling is a hypothesis.** Including tooling that guards your code. (M2, M14)
10. **Fixing a bug is not finding its class.** After fixing one orphaned task, check the others.
    Not doing so is why M17 was missed by three documents in a row. (M17)
11. **A stated invariant needs a mechanism, not a paragraph.** Three documents said money is
    integer cents; one file divided by 100 anyway. (M18)

The most transferable habit across all sixteen: **ask what you have not verified, and say it out
loud.** Six of these topics were only findable because something claimed to work and had never
been run.

---

# Appendix A — The verification pass, as actually executed

This file originally covered sixteen topics and closed by asserting it was complete. It was then
challenged: *"all prompts work if I execute it? are you sure it covers all topics?"*

The honest answer was **no**. The pass below found **five defects in this document** and added two
missing topics. What follows is that pass, with the real commands and their real output, so you
can run the same method on any plan document — including this one, after you change it.

Six passes, cheapest first. Each answers a different question, and each one found something.

---

## Pass 1 — Do the cited line references still point at what they claim?

A document that cites `file.py:18` is making a checkable claim. Check it mechanically, not by eye.

```bash
for ref in "app/config.py:18:jwt_secret" \
           "app/config.py:7:database_url" \
           "app/clients/payment_gateway_client.py:22:payload" \
           "app/core/cache.py:50:EVIDENCE_redis" \
           ".claude/skills/api-flow/SKILL.md:90:unwired"; do
  f="${ref%%:*}"; rest="${ref#*:}"; ln="${rest%%:*}"; pat="${rest#*:}"
  got=$(sed -n "${ln}p" "$f" 2>/dev/null)
  if echo "$got" | grep -q "$pat"; then
    echo "  OK    $f:$ln contains '$pat'"
  else
    echo "  WRONG $f:$ln -> got: $(echo "$got" | head -c 70)"
  fi
done
```

Real output:

```
OK    app/config.py:18 contains 'jwt_secret'
OK    app/config.py:7 contains 'database_url'
OK    app/clients/payment_gateway_client.py:22 contains 'payload'
OK    app/core/cache.py:50 contains 'EVIDENCE_redis'
OK    .claude/skills/api-flow/SKILL.md:90 contains 'unwired'
```

**Result: clean.** Run it anyway — line numbers rot the moment anyone edits above them, and the
loop costs two seconds. A document full of stale references teaches distrust of all of them.

---

## Pass 2 — Do the files the instructions depend on actually exist?

```bash
SP=".../scratchpad"     # the path the docs told readers to copy from
for f in stage0-integrity-block.sh seal.sh CODEOWNERS post-commit; do
  [ -f "$SP/$f" ] && echo "  OK    $f present" || echo "  GONE  $f MISSING"
done
```

Real output:

```
GONE  stage0-integrity-block.sh MISSING
GONE  seal.sh MISSING
GONE  CODEOWNERS MISSING
GONE  post-commit MISSING

$ ls -la "$SP"
total 0
drwxr-xr-x 1 Administrator 197121 0 Sep  9 17:05 .
drwxr-xr-x 1 Administrator 197121 0 Sep  9 17:05 ..

$ find ".../Temp/2/claude" -name 'CODEOWNERS' -o -name 'seal.sh' 2>/dev/null
(nothing)
```

### DEFECT 1 — every M2 and M3 install path was dead

Four enforcement files had been staged in a **session scratchpad** — a temporary directory — and it
had since been wiped. Both documents instructed the reader to copy from a path containing nothing.
The wider `find` confirmed they were gone, not moved.

**Fix:** regenerated all four into `scripts/enforcement-staged/` — inside the repository, under
version control, with a README carrying the apply sequence. Both documents repointed. The old
hedge ("if the scratchpad has been cleaned, regenerate from the descriptions") was replaced with
what actually happened, because a hedge is not a fix.

**Learn:** *instructions inherit the durability of what they point at.* A perfect command that
references a temp path is a broken command on a delay. Anything a document tells a reader to copy
must live where the document lives.

---

## Pass 3 — Will the commands even run in this environment?

```bash
for c in git python ruff mypy pytest sha256sum grep sed printf; do
  command -v "$c" >/dev/null 2>&1 && echo "  OK    $c" || echo "  ABSENT $c"
done

for f in scripts/changelog/append_entry.py scripts/hooks/install.sh \
         scripts/hooks/pre-commit scripts/hooks/pre-push; do
  [ -f "$f" ] && echo "  OK    $f" || echo "  MISS  $f"
done
```

Real output: all nine commands present, all four scripts present.

**Result: clean.** Note what this pass is *not* — it proves the commands exist, not that they do
the right thing. That is Pass 5.

---

## Pass 4 — Is anything in the project absent from the document entirely?

The pass that catches what the other five cannot: a topic nobody thought of. The technique is to
look for **definitions with no consumers**, then check the document for the word.

```bash
# For every Celery task, ask what enqueues it.
grep -rn 'reconcile_payment_webhook' app/ --include='*.py'
grep -rn 'webhook' app/api/
```

Real output:

```
app/tasks/order_tasks.py:56:@celery_app.task(name="rxflow.reconcile_payment_webhook")
app/tasks/order_tasks.py:57:def reconcile_payment_webhook(webhook_event_id: int) -> None:
  (no route)
```

Then: was it ever mentioned?

```bash
for t in webhook reconcile notification_service seed_db diagrams.html alembic.ini; do
  printf "  %-20s GAPS=%s PROJECT=%s LEARNING=%s\n" "$t" \
    "$(grep -ci "$t" EVIDENCE_GAPS.md)" \
    "$(grep -ci "$t" missingproject.md)" \
    "$(grep -ci "$t" missingtopiclearning.md)"
done
```

Real output:

```
webhook              GAPS=0 PROJECT=0 LEARNING=0
reconcile            GAPS=0 PROJECT=0 LEARNING=0
notification_service GAPS=0 PROJECT=0 LEARNING=0
seed_db              GAPS=0 PROJECT=0 LEARNING=0
diagrams.html        GAPS=0 PROJECT=0 LEARNING=0
alembic.ini          GAPS=0 PROJECT=0 LEARNING=0
```

### DEFECT 2 — a complete unwired feature, missing from all three documents

`grep -rn 'reconcile_payment_webhook' app/` matches **only its own decorator and signature**.
There is a `WebhookEvent` model, a migration that creates the table, and a task that processes
events — and nothing that writes a row, nothing that enqueues the task, and no route under
`app/api/`. A whole vertical slice with no front door.

The damning part: the identical defect had **already been found and fixed** earlier in the same
session — `sync_inventory_levels` had no caller until `POST /orders/{order_id}/fulfill` was added.
Having fixed one orphaned task, nobody checked the other two.

**Fix:** added as topic **M17**, with the design questions it raises — a gateway cannot send our
JWT; gateways retry and the table has no event-id column; `payload_raw` is `String(4000)`.

**Learn:** *fixing a bug is not finding its class.* After you fix one instance, the very next
command should be the grep that finds its siblings. Three documents missed this because all three
were written from the same incomplete mental model.

---

## Pass 5 — Run the verification commands the document recommends

Not "read them and agree they look right" — run them, and check the output means what the document
says it means.

```bash
grep -rn 'cents *[/*]' app/ | grep -v '//'
```

Real output:

```
app/clients/tax_client.py:13:    return int(subtotal_cents * 0.08)
app/services/notification_service.py:16:    body = f"...Total: ${total_cents / 100:.2f}"
```

### DEFECT 3 — the float-money topic named one site; there were two

`CLAUDE.md`, `ONBOARDING.md` and the `api-new` skill all state money is integer cents, never
floats. The document's own recommended grep found **two** violations after the section had
confidently named one:

| Site | Code | Severity |
|---|---|---|
| `notification_service.py:16` | `total_cents / 100:.2f` | display only — but `/ 100` is a binary float and `:.2f` rounds half-to-even, so some totals render a cent from what was charged |
| `tax_client.py:13` | `int(subtotal_cents * 0.08)` | **computes** money through a float, then truncates toward zero — tax systematically under-collected |

**Fix:** topic **M18** now documents both, marks the tax site as the more serious, and gives
integer replacements for each: `divmod` for display, `(subtotal_cents * 8 + 50) // 100` for the
tax, with the rounding rule stated explicitly.

---

```bash
grep -oE 'os\.environ\.get\("([A-Z_]+)' app/config.py | grep -oE '[A-Z_]+$' | sort
```

Real output — three variables:

```
JWT_SECRET
REDIS_URL
RXFLOW_ENV
```

But `config.py` reads six:

```
$ sed -n '7,16p' app/config.py
    database_url: str = os.environ.get(
        "DATABASE_URL", "sqlite:///./rxflow.db"
    )
    redis_url: str = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    celery_broker_url: str = os.environ.get(
        "CELERY_BROKER_URL", "redis://localhost:6379/0"
    )
    ...
```

### DEFECT 4 — a verification command that verified the wrong thing

Three of the six `os.environ.get` calls **wrap across lines**, so the single-line pattern silently
missed `DATABASE_URL`, `CELERY_BROKER_URL` and `CELERY_RESULT_BACKEND`. A reader following M10
would have produced a `.env.example` missing half the variables, run the recommended `diff`, seen
it agree, and concluded the file was complete.

**This is the worst of the five**, because it does not fail — it passes incorrectly.

**Fix:** match quoted UPPER_SNAKE literals instead, which is line-agnostic:

```bash
grep -oE '"[A-Z][A-Z_]{2,}"' app/config.py | tr -d '"' | sort -u
```

Re-run output — all six:

```
CELERY_BROKER_URL CELERY_RESULT_BACKEND DATABASE_URL JWT_SECRET REDIS_URL RXFLOW_ENV
```

**Learn:** *a green check proves the check ran, not that the property holds.* Test your
verification commands against a case you know should fail. A grep that cannot see multi-line calls
reports clean forever.

---

```bash
grep -n 'payload' app/clients/payment_gateway_client.py   # documented as "expect no logger line"
```

Real output — five hits, and four of them stay after the fix:

```
14:    payload = {
22:    logger.debug("Authorizing payment with gateway payload=%s", payload)
28:            return _call_gateway(client, payload)
36:def _call_gateway(client, payload: dict) -> dict:
41:        "gateway_reference": f"MOCK-{payload['order_id']}",
```

### DEFECT 5 — a check whose passing condition was impossible

The `payload` dict is legitimate and must stay; only the logging line goes. So "expect no logger
line" from a grep matching five unrelated lines gives the reader nothing to compare against.

**Fix:** scope it to the logging call, so the expected output after the fix is *nothing*:

```bash
grep -n 'logger.*payload' app/clients/payment_gateway_client.py   # expect nothing
```

**Learn:** *a verification step needs an unambiguous passing state.* "Expect no logger line" among
five hits requires the reader to interpret. "Expect nothing" does not.

---

## Pass 6 — Does the document still hang together after the edits?

Two topics and five fixes later, re-check the structure mechanically.

```bash
# every topic in the build guide has a section in the learning file
for m in $(grep -oE '^## M[0-9]+' missingproject.md | grep -oE 'M[0-9]+'); do
  grep -qE "^## $m " missingtopiclearning.md && echo "  ok   $m" || echo "  MISS $m"
done

# every section still has its four parts
for h in Prompt Execute Learn 'Check yourself'; do
  printf '%-16s %s\n' "$h" "$(grep -c "^### $h" missingtopiclearning.md)"
done
```

Real output: `ok` for M1 through M18, and Prompt 18 / Execute 13 / Learn 18 / Check yourself 18.

`Execute` is 13 rather than 18 deliberately: five topics (M9, M11, M13, M14, M16) have no shell
command, being a document, a decision, or an interactive authorisation. **Omit the heading rather
than invent a verification step** — a fake check is worse than a missing one.

---

## What the pass could not verify

Stated plainly, because this is the part most reports leave out. Four things remain **UNVERIFIED**,
all for the same reason — there is no `.git` yet:

| Topic | Unverifiable step | Why |
|---|---|---|
| M1 | `git status` before the first commit | no repository |
| M2 | the tamper test that proves stage 0 refuses | nothing to commit into |
| M4 | the three CI jobs | no forge, no workflows |
| M5 | the audit smoke test | `claude` not on PATH |

The hook scripts parse, and their detection rules were tested against real files with a
no-false-positive control. **No hook has ever run as a hook.** `git init` is what tests them.

---

## The reusable method

Six passes, cheapest first. Run them in order on any plan document you did not write today.

| Pass | Question | Typical finding |
|---|---|---|
| 1 | Do cited line references still resolve? | stale `file.py:NN` after edits above |
| 2 | Do the files the instructions depend on exist? | a path outside the repo, since deleted |
| 3 | Do the commands exist in this environment? | a tool assumed present |
| 4 | Is anything in the project absent from the document? | a whole feature nobody listed |
| 5 | Do the recommended checks actually check the property? | a grep that passes incorrectly |
| 6 | Does the structure still hold after edits? | a topic added to one file, not the other |

### The prompt to run this pass

    Verify this plan document against the working tree. Do not take its claims at face
    value. Six passes, in order:

    1. Check every cited file:line reference actually contains what the document says.
    2. Check every file the instructions tell a reader to copy from still exists.
    3. Check every command the document invokes is available here.
    4. Find definitions with no consumers — models nothing writes, tasks nothing
       enqueues, routes nothing calls — and tell me whether the document mentions them.
    5. RUN the verification commands the document recommends and tell me whether their
       output means what it claims. Test them against a case that should fail.
    6. Re-check the document's own structure after any edits.

    Report defects found IN THE DOCUMENT separately from defects in the code. End by
    listing what you could not verify and why. Do not tell me it is complete unless
    every pass came back clean.

The last two sentences are the ones that matter. A verification pass that cannot return "I could
not check this" is not a verification pass.

### The single habit

**Ask what you have not verified, and say it out loud.** Six of the eighteen topics in this file
exist only because something claimed to work and had never been run — and five defects in the file
itself exist only because it claimed coverage without checking.
