"""Characterization tests for app.services.order_service.create_order().

These pin down the function's *current* behavior (including quirks that are not
necessarily desirable) so a future refactor can be checked against them. They call
create_order() directly against a real session-backed DB, bypassing the HTTP layer
that tests/integration/test_order_flow.py exercises.
"""

from app.models.customer import Customer
from app.models.inventory import Inventory
from app.models.order import Order
from app.models.payment import Payment
from app.models.product import Product
from app.services.order_service import (
    IdempotencyKeyConflictError,
    OrderValidationError,
    create_order,
)


def _seed_customer(db_session, email="char@example.com"):
    customer = Customer(
        email=email, hashed_password="not-a-real-hash", full_name="Char Buyer", role="customer"
    )
    db_session.add(customer)
    db_session.flush()
    return customer


def _seed_product(db_session, sku="SKU-CHAR", quantity=10, price_cents=1000):
    product = Product(sku=sku, name="Characterized Thing", price_cents=price_cents)
    db_session.add(product)
    db_session.flush()
    db_session.add(Inventory(product_id=product.id, quantity_on_hand=quantity, quantity_reserved=0))
    db_session.commit()
    return product


def test_create_order_confirms_reserves_stock_and_records_payment(db_session):
    customer = _seed_customer(db_session)
    product = _seed_product(db_session, quantity=10, price_cents=1000)

    order = create_order(
        db_session,
        customer,
        items=[{"product_id": product.id, "quantity": 3}],
        shipping_address="1 Test Way",
        card_number="4242424242424242",
        card_last4=None,
        idempotency_key="char-key-1",
    )

    assert order.status == "confirmed"
    assert order.total_cents == 3000
    assert len(order.items) == 1

    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    assert inventory.quantity_reserved == 3
    assert inventory.quantity_on_hand == 10  # on_hand is untouched until fulfillment

    payment = db_session.query(Payment).filter(Payment.order_id == order.id).first()
    assert payment is not None
    assert payment.card_last4 == "4242"  # derived from card_number since card_last4 was None


def test_create_order_uses_explicit_card_last4_over_derived_one(db_session):
    """card_last4, when given, is trusted verbatim -- it is not cross-checked
    against card_number even if they disagree."""
    customer = _seed_customer(db_session)
    product = _seed_product(db_session)

    order = create_order(
        db_session,
        customer,
        items=[{"product_id": product.id, "quantity": 1}],
        shipping_address="1 Test Way",
        card_number="4242424242424242",
        card_last4="9999",
        idempotency_key="char-key-2",
    )

    payment = db_session.query(Payment).filter(Payment.order_id == order.id).first()
    assert payment.card_last4 == "9999"


def test_create_order_replay_with_same_key_and_payload_returns_existing_order(db_session):
    customer = _seed_customer(db_session)
    product = _seed_product(db_session, quantity=10)
    items = [{"product_id": product.id, "quantity": 2}]

    first = create_order(
        db_session, customer, items, "1 Test Way", "4242424242424242", None, "char-key-3"
    )
    second = create_order(
        db_session, customer, items, "1 Test Way", "4242424242424242", None, "char-key-3"
    )

    assert first.id == second.id
    assert db_session.query(Order).count() == 1

    inventory = db_session.query(Inventory).filter(Inventory.product_id == product.id).first()
    assert inventory.quantity_reserved == 2  # not double-reserved on replay


def test_create_order_replay_with_different_shipping_address_raises_conflict(db_session):
    customer = _seed_customer(db_session)
    product = _seed_product(db_session, quantity=10)
    items = [{"product_id": product.id, "quantity": 1}]

    create_order(db_session, customer, items, "1 Test Way", "4242424242424242", None, "char-key-4")

    try:
        create_order(
            db_session, customer, items, "A different address", "4242424242424242", None, "char-key-4"
        )
        assert False, "expected IdempotencyKeyConflictError"
    except IdempotencyKeyConflictError:
        pass


def test_create_order_replay_with_same_items_in_different_order_is_not_a_conflict(db_session):
    """_matches_existing() sorts items by product_id before comparing, so cart item
    order does not matter for idempotency matching."""
    customer = _seed_customer(db_session)
    product_a = _seed_product(db_session, sku="SKU-CHAR-A", quantity=10)
    product_b = _seed_product(db_session, sku="SKU-CHAR-B", quantity=10)

    items_order_1 = [
        {"product_id": product_a.id, "quantity": 1},
        {"product_id": product_b.id, "quantity": 1},
    ]
    items_order_2 = [
        {"product_id": product_b.id, "quantity": 1},
        {"product_id": product_a.id, "quantity": 1},
    ]

    first = create_order(
        db_session, customer, items_order_1, "1 Test Way", "4242424242424242", None, "char-key-5"
    )
    second = create_order(
        db_session, customer, items_order_2, "1 Test Way", "4242424242424242", None, "char-key-5"
    )

    assert first.id == second.id
    assert db_session.query(Order).count() == 1


def test_create_order_empty_items_raises_without_creating_a_row(db_session):
    customer = _seed_customer(db_session)

    try:
        create_order(db_session, customer, [], "1 Test Way", "4242424242424242", None, "char-key-6")
        assert False, "expected OrderValidationError"
    except OrderValidationError:
        pass

    assert db_session.query(Order).count() == 0


def test_create_order_unknown_product_raises_but_leaves_pending_order_row_committed(db_session):
    """Current behavior: the Order row is flushed (and gets an id) before items are
    validated, and there is no rollback/cleanup on an unknown product id -- the
    order is left behind in 'pending' status once the surrounding session commits
    elsewhere. This is a characterization of existing behavior, not a spec."""
    customer = _seed_customer(db_session)

    try:
        create_order(
            db_session,
            customer,
            [{"product_id": 999999, "quantity": 1}],
            "1 Test Way",
            "4242424242424242",
            None,
            "char-key-7",
        )
        assert False, "expected OrderValidationError"
    except OrderValidationError:
        pass

    order = db_session.query(Order).filter(Order.idempotency_key == "char-key-7").first()
    assert order is not None
    assert order.status == "pending"
    assert order.total_cents == 0


def test_create_order_insufficient_stock_on_second_item_leaves_first_items_reservation_in_place(
    db_session,
):
    """Current behavior: reserve_stock() is called per item in a loop with no
    compensating rollback -- if a later item fails, stock already reserved for
    earlier items in the same cart stays reserved."""
    customer = _seed_customer(db_session)
    product_ok = _seed_product(db_session, sku="SKU-CHAR-OK", quantity=10)
    product_short = _seed_product(db_session, sku="SKU-CHAR-SHORT", quantity=1)

    try:
        create_order(
            db_session,
            customer,
            [
                {"product_id": product_ok.id, "quantity": 2},
                {"product_id": product_short.id, "quantity": 5},
            ],
            "1 Test Way",
            "4242424242424242",
            None,
            "char-key-8",
        )
        assert False, "expected OrderValidationError"
    except OrderValidationError:
        pass

    inventory_ok = db_session.query(Inventory).filter(Inventory.product_id == product_ok.id).first()
    assert inventory_ok.quantity_reserved == 2  # reservation from the first item was not undone
