# Day 5 revision — session log

A record of what was built and found in this session, working against the RxFlow codebase
(`c:\Users\Administrator\day4\rxflow`). Written as a revision note, not a spec — every claim below
reflects something actually read, run, or created during the session, not an assumption.

## 1. New skill: `defect-triage` (project-scoped)

Created `.claude/skills/defect-triage/SKILL.md`. Read-only skill for triaging a new defect (bug
report, stack trace, log excerpt) the way a support/site-reliability engineer would:
- Extract evidence from what's given, quoting rather than paraphrasing.
- Locate the emitting code and trace it through RxFlow's real layering (`api/` → `services/` →
  `models/`/`clients/`/`tasks/`).
- Classify every root-cause claim as **CONFIRMED** (directly shown by evidence) or **PLAUSIBLE**
  (consistent with the code, not proven) — never blur the two.
- Name a fix location and its class of change, but never write the diff. Never edits code.

## 2. New agent: `bug-analyst` (drafted, not installed)

Drafted `.claude/agents/bug-analyst.md` — a senior-software-engineer-role agent for analyzing new
Jira tickets: reads `CLAUDE.md` and project docs first for grounding, applies the `defect-triage`
method, traces real code with `path:line` citations, and separates CONFIRMED from PLAUSIBLE.
Read-only (`tools: Read, Grep, Glob, Bash`).

**Status: not actually saved into the project.** `.claude/settings.json` denies
`Edit(./.claude/agents/**)` and `Write(./.claude/agents/**)`, so the file was handed to the user as
text to save manually rather than written by the assistant. It does not exist on disk as of this
writing.

## 3. Diagrams / artifacts published

Two Artifacts were published this session (both are real, live pages, not just described):

- **Incident Triage Map** — https://claude.ai/code/artifact/9851155b-86ae-40ef-b483-2124ac892496
  Maps the "SSE" (support/site-reliability) incident-triage role's habits to concrete project
  mechanisms: ticket input → `defect-triage` skill's evidence discipline → read-only tools tracing
  the layered code → `CLAUDE.md` as grounding → `bug-analyst`/`release-readiness` agents packaging
  the report. Explicitly flags that `bug-analyst` is drafted, not active.

- **RxFlow System Map** — https://claude.ai/code/artifact/ea0e695e-931e-47ae-b616-19a1146cd034
  Broader map covering the runtime architecture (`app/api` → `services` → `models`/`clients`/
  `tasks`) *and* the git-hook dev workflow (`scripts/hooks/pre-commit` two-stage gate, `pre-push`
  advisory audit, both invoking `claude -p` headlessly to run `release-readiness`), the three
  project skills, both agents, and the project's doc set (`CLAUDE.md`, `ONBOARDING.md`,
  `EVIDENCE_GAPS.md`, `missingproject.md`, `missingtopiclearning.md`). Notes explicitly that CI is
  absent and that the hook pipeline was read from source, not executed.

## 4. Discovery: existing git hooks

Read `scripts/hooks/pre-commit`, `scripts/hooks/pre-push`, `scripts/hooks/install.sh` (pre-existing
in the repo, not created this session). Summary of what they actually do:
- `pre-commit`: stage 1 is fast deterministic checks (secrets/PII in logs, stray DB/key artifacts,
  debugger breakpoints, model/migration drift, `ruff` on staged files); stage 2 shells out to
  `claude -p` to run the `release-readiness` agent over the staged diff. Blocking by default
  (`RXFLOW_READINESS=blocking`).
- `pre-push`: runs `release-readiness` over the full pushed commit range. Advisory by default.
- Both require the `claude` CLI on PATH; otherwise stage 2 / the whole audit is skipped with a
  notice, and stage 1 (pre-commit only) still applies.

## 5. New global skills (apply to every project, not just RxFlow)

Created under `C:\Users\Administrator\.claude\skills\`:

- **`project-architecture`** — read-only mapping of any codebase's real architecture: ground truth
  from the tree first (stack, layers, entry points, persistence/integration boundaries), then
  reconcile against the project's own docs (code wins on conflict), then inventory the tooling
  wrapped around the code (CI, git hooks, existing Claude skills/agents). Reports with `file:line`
  citations; can hand off to `artifact-diagramming`/`artifact-design` for a visual.
- **`architecture-design`** — the forward-looking counterpart: designs a *new* feature/service from
  stated requirements, grounds the proposal in the current codebase's conventions when one exists,
  forces explicit trade-offs tied to real constraints, and produces an Artifact diagram of the
  proposed shape. Never implements.
- **`pycrt`** — scaffolds a brand-new Python project (`/pycrt <name>`): src layout, `pyproject.toml`
  (hatchling), a real test, venv creation, `git init`, and — the key rule — it must actually run
  `pytest` and a smoke import through the new venv and paste the real output before it's allowed to
  report success. Not yet invoked in this session (the user tried `/pycrt my-project` but it hit the
  same "just-created skill not yet picked up" timing gap noted below).

**Known friction**: newly created global skills reported "Unknown command" the very first time they
were invoked in the same session they were created, then appeared correctly in the next system
skill-list refresh. Not a bug in the skill files — an enumeration/timing gap between file write and
harness pickup. Retrying a turn later, or in a fresh session, resolved it.

## 6. `/debug` sessions

Ran `/debug` three times this session. Each time: no debug log existed
(`~/.claude/debug/<session-id>.txt` was absent), no daemon log existed, and no specific issue was
described, so there was nothing to diagnose from logs. Findings were reported honestly as "nothing
present" rather than invented.

At the user's request, added persistent debug logging to `~/.claude/settings.json`:
```json
{
  "model": "sonnet",
  "effortLevel": "low",
  "env": {
    "CLAUDE_CODE_DEBUG_LOGS_DIR": "C:\\Users\\Administrator\\.claude\\debug"
  }
}
```
Caveat given at the time and still true: this env var is read once at process start, so it will not
take effect for an already-running session — a fresh `claude` process is needed before `/debug`
will find anything to read. The debug skill itself cannot be invoked programmatically by the
assistant (`disable-model-invocation`); it must be run by the user directly.

## 7. RxFlow project gates — actually run, not assumed

Ran `ruff check .`, `mypy app`, `pytest -q` for real (backgrounded, ~195s for the full test run).
Results, checked against the pre-existing baseline documented in `CLAUDE.md` / the
`release-readiness` agent:

- **`ruff check .`** — FAIL, 9 errors: `tests/conftest.py:6-13` (`E402`, deliberate — env vars must
  be set before the app import) and `tests/unit/test_security.py:1` (`I001`). Matches the known
  baseline; nothing new.
- **`mypy app`** — FAIL, 4 errors, all in `app/core/cache.py:15,25,54,62` (redis stub sync/async
  union). Matches the known baseline; `make typecheck` has never been green.
- **`pytest -q`** — PASS: 44 passed, 1 skipped, 196 warnings, 194.76s. The skip is
  `test_migrations_apply_live_db.py` (guarded on `RXFLOW_LIVE_DB_URL`) — the Alembic chain remains
  unverified by this run, as already documented.

**New observation, not in the prior baseline**: the test run's warnings show paths under
`C:\Users\Administrator\day2\rxflow\.venv\...` — the `pytest`/`ruff`/`mypy` on PATH during this run
were resolving to a **different sibling project's virtualenv** (`day2/rxflow`), not one scoped to
`day4/rxflow`. Tests still passed, but the gate results aren't provably pinned to this project's own
`requirements.txt`; a version drift between the two projects' dependencies could mask or fabricate a
result. Flagged as a real risk, not yet fixed — no `day4/rxflow`-local `.venv` was created this
session. Also noted as low-priority noise: 196 warnings, mostly `datetime.utcnow()` deprecations
(`app/core/security.py:26` and SQLAlchemy's own default) and a Pydantic v1-style config deprecation
from a dependency.

## Open items carried forward

1. `.claude/agents/bug-analyst.md` still needs to be saved manually (assistant writes to that path
   are denied by project settings) if the drafted agent is to actually be usable.
2. `day4/rxflow` has no project-local virtualenv — gate runs are currently borrowing `day2/rxflow`'s
   `.venv`, which is a latent risk for trustworthy CI-equivalent results.
3. Per `CLAUDE.md`'s own "keep skills and agents in sync" rule: `CLAUDE.md` itself was updated
   externally this session (a new note was added about `test_order_service_characterization.py`
   pinning current `create_order()` quirks). That edit did not originate from this assistant, and no
   corresponding skill/agent review has been done against it yet — worth doing before it's treated
   as fully synced.
