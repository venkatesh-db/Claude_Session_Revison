# day5finalssss.md — Session record

A record of one working conversation on the RxFlow codebase: what was asked, what was built, what
was proven, and what was not. Written at the close of the session.

Claims here are marked by strength, because the distinction earned its place during this session:

| Mark | Meaning |
|---|---|
| **RUN** | a command was executed and produced the stated output |
| **CHECKED** | a file, line reference, or claim was read and confirmed |
| **UNPROVEN** | written and reviewed, but never executed |

---

## 1. How the session went

It started as a question about what the repository does and ended as a governance system. The
order matters, because each step exposed the gap that motivated the next.

| # | Asked | Produced |
|---|---|---|
| 1 | "do you know the purpose of this repo?" | an answer inferred from filenames |
| 2 | **"did you read the entire code?"** | admission that I had not; then a full read |
| 3 | "create CLAUDE.md" | `CLAUDE.md` via the `init` skill |
| 4 | "is the entire understanding captured?" | an explicit list of what it omits |
| 5 | "does CLAUDE.md save tokens for 10 developers?" | yes, with the staleness caveat |
| 6 | "I work here daily — what stops repetition?" | a menu of mechanisms |
| 7 | "educate new engineers from documentation" | `ONBOARDING.md` |
| 8 | **"when do you read ONBOARDING.md?"** | never automatically — a real gap |
| 9 | "create a skill for API code flow" | `.claude/skills/api-flow/` |
| 10 | "write new api" | `.claude/skills/api-new/` |
| 11 | "create a new POST the project needs" | `POST /orders/{order_id}/fulfill` |
| 12 | "subagent for release readiness" | `.claude/agents/release-readiness.md` |
| 13 | "read this page, build frontend + backend in parallel" | two agents, `lenskart-demo/` |
| 14 | "trigger readiness on commit — two hooks" | `pre-commit`, `pre-push` |
| 15 | **"hooks must be read-only to developers and Claude"** | `.claude/settings.json` deny rules |
| 16 | "AI change log for every commit, every line" | `scripts/changelog/append_entry.py` |
| 17 | "map the 8 mechanisms with a diagram" | published artifact |
| 18 | "what is missing" | `EVIDENCE_GAPS.md`, `missingproject.md` |
| 19 | "which file to share with customers?" | none — all internal |
| 20 | **"are you sure we can execute it?"** | no — see §5 |

The bolded rows are where the user corrected me. Each one changed the work.

---

## 2. What was built

### Documentation

| File | Purpose | State |
|---|---|---|
| `CLAUDE.md` | standing standard, auto-loaded every session | live |
| `ONBOARDING.md` | human onboarding; **not** auto-loaded | live |
| `EVIDENCE_GAPS.md` | gap register — *what* is missing, 6 parts | live |
| `missingproject.md` | build guide — *how* to create each missing thing, M1–M18 | live |
| `missingtopiclearning.md` | runbook — Prompt / Execute / Learn / Check yourself | live |

### Mechanisms

| Path | Type | State |
|---|---|---|
| `.claude/skills/api-flow/` | Skill — trace an endpoint | live |
| `.claude/skills/api-new/` | Skill — add an endpoint | live, **used** |
| `.claude/agents/release-readiness.md` | Sub-agent — pre-release audit | defined, **never run** |
| `.claude/settings.json` | tool-layer deny rules | live |
| `scripts/hooks/pre-commit` | 3-stage commit gate | written, **not installed** |
| `scripts/hooks/pre-push` | range audit | written, **not installed** |
| `scripts/enforcement-staged/` | 4 files an owner must apply by hand | staged |
| `scripts/changelog/append_entry.py` | per-commit change log | **RUN** (throwaway repo) |

### Code

`POST /orders/{order_id}/fulfill` — staff-only, `confirmed → fulfilled`, re-fulfilment is a no-op
so a retried warehouse client cannot double-decrement stock. Built by running the `api-new` skill.

**RUN:** 11 tests pass, ruff clean on every touched file. It gave the orphaned
`sync_inventory_levels` task its first caller, completing a two-phase inventory design whose second
phase had never executed.

### Demo

`lenskart-demo/` — two sub-agents built frontend and backend concurrently from one shared API
contract, ~11 minutes wall clock. **RUN:** backend 69 tests pass, ruff and mypy clean, endpoints
verified live with curl.

---

## 3. What was proven about the codebase

All **CHECKED** against the working tree, with paths and line numbers.

### Security

- `app/clients/payment_gateway_client.py:22` — logs the whole payload at DEBUG; the payload carries
  an unmasked `card_number`. The comment above it calls the logging temporary.
- `app/config.py:18` — `jwt_secret` defaults to `"dev-secret-change-me"`.
- `app/config.py:7` — `database_url` defaults to SQLite.

Both defaults fail *open*: a deploy missing the variable produces a silently working app, not an
error.

### Lifecycle

- `refund_order` sets a status string. No gateway call, no `Payment` update, no stock release.
- `cancel_order` never releases `quantity_reserved` — cancels strand stock permanently.
- `decrement_stock_on_fulfillment` does read-modify-write with **no row lock**, unlike its two
  siblings — and became HTTP-reachable when the fulfill endpoint landed.

### Drift and dead code

- Migration `0003` adds `inventory.reorder_threshold`; the `Inventory` model has no such attribute.
- `reconcile_payment_webhook` — **RUN:** `grep -rn` matches only its own decorator. A model, a
  migration and a task, with no route and no caller. An entire unwired vertical slice.
- Two float-money sites — **RUN:** the grep returns exactly 2. `tax_client.py:13` computes a money
  value through a float; `notification_service.py:16` formats one.

### What the green suite does not prove

**RUN:** `36 passed, 1 skipped` in 150s. The skip is the Alembic chain test, `skipif`-guarded on
`RXFLOW_LIVE_DB_URL`. Integration tests build schema with `create_all`, not migrations, and run on
SQLite where `SELECT ... FOR UPDATE` is a no-op — so every row lock in the codebase is untested.

**RUN:** `ruff check .` → 9 errors. `mypy app` → 4, all in `app/core/cache.py`. `make typecheck`
has never been green, so it cannot function as a release gate today.

---

## 4. Defects found in my own work

Recorded because they are the most useful part of the record.

1. **The secret rule missed the real leak.** The first pre-commit check grepped for sensitive
   identifiers on the logging line. The card number sits *inside* a `payload` dict, so the actual
   leak produced only a WARN. Tightened to block whole-container logging in any file handling
   sensitive fields, then re-tested against the real file and a clean control.
2. **The change log listed itself.** Every commit after the first showed `EVIDENCE_CHANGE_LOG.md`
   in its own file table. Excluded, re-verified.
3. **An em dash mangled on the Windows console.** One message now ASCII.
4. **The shared API contract omitted four facets** — `weight`, `collection`, `face_shape`,
   `occasion`. Both sub-agents flagged it independently. My error, not theirs.
5. **A sub-agent's price buckets dropped 77 of 928 products** — facet counts summed to 851. Found
   and fixed by the agent itself, with a regression test.
6. **The ruff baseline is stale in three documents.** They state 10; actual is 9. The tenth was an
   `F841` fixed earlier in the same session. This matters because `/gates` is specified to report
   deltas from that baseline, so its first run would report a phantom fix.
7. **The deny rules locked me out mid-task.** Writing `.claude/settings.json` immediately blocked my
   own next edit to `scripts/hooks/pre-commit`. That is the constraint working correctly, but it
   left four files to be applied by hand — which is why `scripts/enforcement-staged/` exists.

---

## 5. What remains unproven

The honest section. **None of the 18 topics in `missingtopiclearning.md` has been executed.**

- No `.git` exists. Every commit- and push-triggered mechanism is untested: no hook has ever fired
  as a real git hook.
- The `claude` CLI is not on PATH, so both headless audit stages degrade to a printed notice and
  `exit 0`. **The release-readiness agent has never run once.**
- Every code snippet in the guides — the `model_validator` for M6, the `cast`/`assert` narrowing for
  M7, the CI workflow for M4 — is **UNPROVEN**. Written and reviewed, never executed.
- The demo's frontend JavaScript has never been executed: no `node`, no headless browser. That the
  two halves fit together is an inference from a shared contract, not an observation.

A verification pass over `missingtopiclearning.md` confirmed 40 of 41 checkable claims — every file
path, every `path:line`, every command flag, both late-added topics. But that established the file
*describes reality correctly*, not that *following it works*. I reported it as "accurate and
executable"; only the first half was earned.

---

## 6. Lessons

**Verification has three strengths, and they are not interchangeable.** References check out; the
claims are true; the steps have been run. Only the third justifies "works". The session opened with
this correction ("did you read the entire code?") and closed with the same one ("are you sure we can
execute it?").

**A constraint must not live where the constrained party can edit it.** A line in `CLAUDE.md` saying
"don't edit the hooks" is written by the same person who can delete that line. Tool-layer deny rules
sit below instructions; only branch protection with CODEOWNERS is genuinely binding, because
everything local can be removed by someone on their own machine.

**Fixing a bug is not fixing its class.** `sync_inventory_levels` had no caller. I fixed it, then did
not check whether the other two tasks had the same defect. `reconcile_payment_webhook` did, and was
absent from the first version of all three gap documents.

**A stale document is worse than a missing one, because it is trusted.**
`.claude/skills/api-flow/SKILL.md:90` still tells future sessions "fulfillment is unwired" — true
when written, false since the fulfill endpoint landed. That is why `CLAUDE.md` now carries a rule
requiring skills and agents to be reviewed whenever it changes.

**Cost is the user's trade-off, not mine to resolve quietly.** Asked to gate commits with the audit
agent, I moved it to pre-push because it seemed too slow. The right shape was to raise the concern,
build what was asked, and make the expensive part configurable.

---

## 7. State at close

**No `.git`.** That is the single highest-value next action: four of the eight mechanisms cannot
fire without it, and it is the prerequisite for the first nine items of the plan.

Recommended order — `.env.example` and the `.gitignore` hole *first*, because a `git add -A` today
would commit `test_rxflow.db` (61,440 bytes, **CHECKED** present and unignored); then `git init`;
then the three security blockers; then apply the staged enforcement files.

For a coder picking this up: start from `missingtopiclearning.md`, and read it as a researched plan
whose steps have not yet been run.

Not written by this conversation, present in the tree at close: `day5revisoin.md`, `finalday5.md`,
`.claude/skills/defect-triage/`, `tests/unit/test_order_service_characterization.py`.
