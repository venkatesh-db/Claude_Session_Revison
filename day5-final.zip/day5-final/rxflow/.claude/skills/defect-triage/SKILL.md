---
name: defect-triage
description: Triage a new defect (bug report, stack trace, or log excerpt) the way a site reliability / support engineer would — trace the evidence in the logs back to the exact RxFlow code path, and report the likely root cause and fix location with citations. Read-only: never edits code. Use when a new bug, incident, error log, or exception is reported and needs root-cause analysis before anyone touches code.
---

# Defect triage (read-only)

Given a new defect — a bug report, exception, stack trace, or raw log excerpt — investigate it the
way an SRE handles an incident: start from the evidence, not from a guess, and follow it to a
specific line of code. This skill never edits files. It produces a findings report a developer can
act on; it does not apply the fix.

## Input

The user supplies one or more of: a log excerpt, a stack trace, an error message, a ticket
description, or just a symptom ("orders are failing intermittently"). If nothing concrete is
given, ask for the actual log lines or error text before proceeding — do not speculate about a
defect that hasn't been shown to you.

## Steps

1. **Extract the evidence.** Pull out of the report: exception type and message, the log
   logger name / module, any request id, customer id, or order id, and the timestamp or sequence
   of events. Quote the exact lines you're relying on — every claim in the final report must trace
   back to a quoted line or a `path:line` in the code, not to inference.

2. **Locate the emitting code.** Grep for the exact log message, exception class, or logger name
   in `app/`. Read the surrounding function in full — do not guess behavior from the function name.
   If the trace crosses layers (api → services → clients/tasks), follow it through each layer named
   in CLAUDE.md's architecture section (`app/api/` → `app/services/` → `app/models/` /
   `app/clients/` / `app/tasks/`).

3. **Reconstruct the failing sequence.** State, in order, what the code actually did up to the
   point of failure: which branch was taken, what values were read, what lock (if any) was held,
   what commit/rollback boundary was in play. Use the log's own data (ids, values) to confirm each
   step where possible — don't assume a step happened if the log doesn't show it.

4. **Form a root-cause hypothesis, graded by evidence strength.** Separate what the logs prove
   from what is inferred:
   - **Confirmed** — directly shown by a quoted log line or an exception traceback.
   - **Plausible** — consistent with the code and the log, but not directly observed (e.g. a race
     window that's structurally possible but not proven by this one log).
   Never present a plausible hypothesis as confirmed. If multiple hypotheses fit equally well, list
   all of them rather than picking one arbitrarily.

5. **Point to the fix location, not the fix.** Name the exact `path:line` where a change would
   need to happen and describe *what class* of change it is (e.g. "missing row lock", "unhandled
   exception from the gateway client", "stale cache read"). Do not write or propose the actual code
   diff, and do not edit any file — this skill's output is an investigation report, not a patch.
   If the user wants the fix implemented, tell them to say so explicitly as a separate step.

6. **Report.** Use the output shape below.

## Output shape

```
Defect: <one-line symptom>

Evidence
  "<quoted log/exception line>"     <- source: <where this came from, e.g. pasted log, ticket>
  "<quoted log/exception line>"

Code path
  app/api/orders.py:42        place_order
  app/services/order_service.py:118   create_order — reserve_stock() call
  app/services/inventory_service.py:57  reserve_stock — with_for_update() row lock

Root cause
  CONFIRMED: <claim>, evidenced by <the quoted line/traceback>
  PLAUSIBLE: <claim>, because <code reasoning>, but not directly shown in the log

Fix location
  app/services/inventory_service.py:63 — <class of fix needed, no diff written>

Open questions / what would confirm PLAUSIBLE items
  <what additional log/metric/repro would turn a plausible item into confirmed>
```

## Rules

- **Read-only.** Do not use Edit or Write on any file in the repo during this skill. If you find
  yourself wanting to "just fix it while you're in there," stop — report the finding instead.
- Every line in "Evidence" must be a direct quote from what the user gave you, not paraphrased.
- Every line in "Code path" must be a real `path:line` you actually read, not inferred from a
  filename or function name — this echoes CLAUDE.md's own logging-sensitivity notes (e.g.
  `order_tasks.send_order_confirmation` logs email/address at INFO, `payment_gateway_client` logs
  full card numbers at DEBUG) — check whether the defect's own logs are exposing sensitive data
  and call that out separately if so.
- Keep CONFIRMED and PLAUSIBLE strictly separate, per this project's standing rule that a claim
  about code behavior must be backed by something actually observed (a log line, a run), not
  merely by references checking out or the code reading as though it should behave that way.
- If the investigation reveals the defect needs a fix, end by asking whether the user wants a
  follow-up (non-read-only) step to implement it — do not slide into editing within this skill.
