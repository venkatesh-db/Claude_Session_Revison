# my-project

A minimal Python project scaffold.

## Install

```
python -m venv .venv
.venv/Scripts/pip install -e .[dev]
```

## Test

```
.venv/Scripts/python -m pytest -q
```
